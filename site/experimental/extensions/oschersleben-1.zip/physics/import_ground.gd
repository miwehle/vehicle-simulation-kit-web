@tool
extends EditorScenePostImport
## Build only the selected ground colliders at import time; rendering meshes stay unchanged.
## Keep vertex compression disabled on the track import: rounding adjacent surfaces
## independently opens centimetre-sized gaps in the colliders built from these vertices.

const GroundProbeScript = preload("res://physics/ground_probe.gd")
const SURFACES := {
	"Additional asphalt | First corner": {"OS | Asphalt": "asphalt"},
	"Motorcycle track | Image boundaries": {"OS | Asphalt": "asphalt", "OS | Markierungen": "asphalt"},
	"Pit lane | Motorcycle junctions": {"OS | Boxengasse": "asphalt"},
	"Terrain interface | Grandstand foundation bed": {"OS | Gruenflaeche": "grass"},
	"Terrain | Scene grandstand cutout": {"OS | Gruenflaeche": "grass", "Gravel | Warm beige": "gravel"},
}

func _post_import(scene: Node) -> Object:
	var found := {}
	for mesh_node in scene.find_children("*", "MeshInstance3D", true, false):
		for source_name in SURFACES:
			# The GLB importer replaces Blender's numeric .001 suffix with _001.
			if mesh_node.name != source_name and not String(mesh_node.name).begins_with(source_name + "_"):
				continue
			found[source_name] = true
			var faces_by_type := {}
			for surface in mesh_node.mesh.get_surface_count():
				var material: Material = mesh_node.mesh.surface_get_material(surface)
				var kind: String = SURFACES[source_name].get(material.resource_name if material else "", "")
				if kind.is_empty():
					push_error("Unclassified ground material on " + mesh_node.name)
					return null
				var arrays: Array = mesh_node.mesh.surface_get_arrays(surface)
				var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
				var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
				var faces: PackedVector3Array = faces_by_type.get(kind, PackedVector3Array())
				if indices.is_empty():
					faces.append_array(vertices)
				else:
					for index in indices:
						faces.append(vertices[index])
				faces_by_type[kind] = faces
			for kind in faces_by_type:
				var body := StaticBody3D.new()
				body.name = "Ground_" + kind
				body.collision_layer = GroundProbeScript.ASPHALT_LAYER if kind == "asphalt" else GroundProbeScript.TERRAIN_LAYER
				body.collision_mask = 0
				body.set_meta("surface_type", kind)
				mesh_node.add_child(body)
				body.owner = scene
				var shape := ConcavePolygonShape3D.new()
				shape.set_faces(faces_by_type[kind])
				var collision := CollisionShape3D.new()
				collision.name = "GroundShape"
				collision.shape = shape
				body.add_child(collision)
				collision.owner = scene
	if found.size() != SURFACES.size():
		push_error("Ground import is missing expected meshes: " + str(SURFACES.keys()) + "; found: " + str(found.keys()))
		return null
	return scene
