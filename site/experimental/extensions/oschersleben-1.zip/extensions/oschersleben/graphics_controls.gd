extends VBoxContainer
const Options = preload("res://extensions/oschersleben/graphics_options.gd")
const SettingsMenu = preload("res://ui/dialogs/settings_menu.gd")
var menu: SettingsMenu
var line_filter_button: OptionButton
var shadow_mode_button: OptionButton
var placeholder_button: OptionButton
var marking_button: OptionButton
var asphalt_button: OptionButton
var grass_button: OptionButton

func build(settings_menu) -> void:
	menu = settings_menu
	var details = self
	var filter_row = menu.add_responsive_row(details)
	filter_row.add_child(menu.make_label("Linienfilter (Fahrbahnrand)", 20))
	line_filter_button = menu.add_option_button(filter_row, ["Aus", "An"])
	line_filter_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"line_filter", index == 1))
	var shadow_mode_row = menu.add_responsive_row(details)
	shadow_mode_row.add_child(menu.make_label("Statische Schatten", 20))
	shadow_mode_button = menu.add_option_button(shadow_mode_row, ["Aus", "An (Lightmaps)"])
	shadow_mode_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"shadows", ["off", "lightmaps"][index]))
	details.add_child(menu.make_label("Lightmaps: vorberechnete Beleuchtung auf der gesamten Rennstrecke.", 18, menu.MUTED))

	var grass_row = menu.add_responsive_row(details)
	grass_row.add_child(menu.make_label("Wiesenoberfläche", 20))
	var grass_labels: Array[String] = []
	for option in Options.GrassOptions.OPTIONS.values(): grass_labels.append(option[0])
	grass_button = menu.add_option_button(grass_row, grass_labels)
	grass_button.fit_to_longest_item = false
	grass_button.clip_text = true
	grass_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"grass", Options.GrassOptions.OPTIONS.keys()[index]))
	var asphalt_row = menu.add_responsive_row(details)
	asphalt_row.add_child(menu.make_label("Asphaltoberfläche", 20))
	var asphalt_labels: Array[String] = []
	for option in Options.ASPHALT_OPTIONS.values(): asphalt_labels.append(option[0])
	asphalt_button = menu.add_option_button(asphalt_row, asphalt_labels)
	asphalt_button.fit_to_longest_item = false
	asphalt_button.clip_text = true
	asphalt_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"asphalt", Options.ASPHALT_OPTIONS.keys()[index]))
	var marking_row = menu.add_responsive_row(details)
	marking_row.add_child(menu.make_label("Fahrbahnmarkierung", 20))
	var marking_labels: Array[String] = []
	marking_labels.assign(Options.MARKING_OPTIONS.values())
	marking_button = menu.add_option_button(marking_row, marking_labels)
	marking_button.fit_to_longest_item = false
	marking_button.clip_text = true
	marking_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"marking", Options.MARKING_OPTIONS.keys()[index]))
	var placeholder_row = menu.add_responsive_row(details)
	placeholder_row.add_child(menu.make_label("Gebäude-Platzhalter", 20))
	var placeholder_labels: Array[String] = []
	for option in Options.PLACEHOLDER_OPTIONS.values(): placeholder_labels.append(option[0])
	placeholder_button = menu.add_option_button(placeholder_row, placeholder_labels)
	placeholder_button.item_selected.connect(func(index):
		menu.display_tab.set_graphics_option(&"placeholder", Options.PLACEHOLDER_OPTIONS.keys()[index]))
	menu.display_tab.graphics_draft_changed.connect(refresh)
	refresh()

func refresh() -> void:
	var graphics: Dictionary = menu.display_tab.graphics_snapshot()
	line_filter_button.select(1 if graphics.line_filter else 0)
	shadow_mode_button.select(1 if graphics.shadows == "lightmaps" else 0)
	placeholder_button.select(Options.PLACEHOLDER_OPTIONS.keys().find(graphics.placeholder))
	marking_button.select(Options.MARKING_OPTIONS.keys().find(graphics.marking))
	asphalt_button.select(Options.ASPHALT_OPTIONS.keys().find(graphics.asphalt))
	grass_button.select(Options.GrassOptions.OPTIONS.keys().find(graphics.grass))
