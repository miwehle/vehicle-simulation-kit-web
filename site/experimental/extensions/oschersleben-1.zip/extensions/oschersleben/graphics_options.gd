extends RefCounted
## Oschersleben appearance and migration of existing preferences.
const MODE_KEYS := ["line_filter", "shadows"]
const GrassOptions = preload("res://materials/grass_options.gd")
const ASPHALT_TRACK = preload("res://assets/textures/asphalt/asphalt_track.jpg")
# Display name, color texture, tile size in metres, albedo multiplier, random tile rotation, optional gray blend.
const ASPHALT_OPTIONS := {
	"none": ["Ohne Textur", null, 2.0, 1.0, false],
	"asphalt_track_light_5_fine_gray70_rotated": ["Asphalt Track · Warmgrau", ASPHALT_TRACK, 1.5, 2.55, true, 0.70],
	"asphalt_track_light_6_fine_gray70_rotated": ["Asphalt Track · Warmgrau hell", ASPHALT_TRACK, 1.5, 3.10, true, 0.70],
	"asphalt_track_light_6_fine_gray100_rotated": ["Asphalt Track · Neutralgrau hell", ASPHALT_TRACK, 1.5, 3.10, true, 1.0],
	"clean_asphalt_rotated": ["Clean Asphalt", preload("res://assets/textures/asphalt/clean_asphalt.jpg"), 2.1, 1.0, true],
	"asphalt025a_rotated": ["Asphalt 025 A", preload("res://assets/textures/asphalt/asphalt025a.jpg"), 2.0, 1.0, true],
}
const MARKING_GRAIN := {
	"asphalt_track_light_6_fine_rotated": 3.10,
}
const MARKING_OPTIONS := {
	"original": "Weiß",
	"off_white": "Gebrochenes Weiß",
	"asphalt_track_light_6_fine_rotated": "Weiß mit Körnung",
}
const DEFAULT_PLACEHOLDER := "light_85"
const PLACEHOLDER_OPTIONS := {
	"light_85": ["Halbtransparentes Weiß", Color(0.98, 0.98, 0.98, 0.85)],
	"off_white_100": ["Weiß", Color(0.98 * 0.83, 0.98 * 0.83, 0.98 * 0.83, 1.0)],
}
const PRESETS := {
	"mobile": {"line_filter": false, "scale": 0.75, "msaa": 0, "shadows": "off", "grass": GrassOptions.DEFAULT, "asphalt": "none", "marking": "original", "placeholder": DEFAULT_PLACEHOLDER},
	"desktop": {"line_filter": false, "scale": 1.0, "msaa": 4, "shadows": "lightmaps", "grass": "leafy_grass", "asphalt": "asphalt_track_light_6_fine_gray100_rotated", "marking": "asphalt_track_light_6_fine_rotated", "placeholder": DEFAULT_PLACEHOLDER},
}
const TABLET_PRESET := {"line_filter": true, "scale": 1.0, "msaa": 0, "shadows": "lightmaps", "grass": "leafy_grass", "asphalt": "asphalt_track_light_6_fine_gray100_rotated", "marking": "asphalt_track_light_6_fine_rotated", "placeholder": "off_white_100"}

func preset(mode: String, device: String) -> Dictionary:
	return (TABLET_PRESET if mode == "mobile" and device == "Tablet" else PRESETS[mode]).duplicate()

static func valid(state: Variant) -> bool:
	return state is Dictionary and state.get("line_filter", false) is bool and state.get("shadows") in ["off", "lightmaps"] and state.get("grass", GrassOptions.DEFAULT) in GrassOptions.OPTIONS and state.get("asphalt", "none") in ASPHALT_OPTIONS and state.get("marking", "original") in MARKING_OPTIONS and state.get("placeholder", DEFAULT_PLACEHOLDER) in PLACEHOLDER_OPTIONS

func decode_state(parsed: Dictionary, device_type: String) -> Dictionary:
	parsed.erase("shadow_distance")
	parsed.erase("shadow_opacity_percent")
	if parsed is Dictionary:
		if parsed.get("msaa") is float: parsed.msaa = int(parsed.msaa)
		# Retired dynamic variants become static shadows; keep resolution and MSAA.
		var old = parsed.get("shadows")
		if old is bool or old in ["standard", "soft", "fine", "fine_soft", "softer", "gradient_medium", "gradient_strong", "smooth_medium", "smooth_strong", "smooth_medium_two", "standard_cascades", "economy_cascades", "extra_fine", "standard_lighter", "smooth_medium_far", "smooth_medium_far_two", "smooth_medium_far_lighter"]:
			parsed.shadows = "off" if old is bool and not old else "lightmaps"
		if parsed.get("grass") in ["grass001_soft", "grass004", "grass_ground_aerial", "grass_path_2", "grass_ground", "withered_grass", "polyscan_sparse", "poliigon_flat", "poliigon_flat_soft25", "poliigon_flat_soft50", "poliigon_flat_soft75"]:
			parsed.grass = GrassOptions.DEFAULT
		if parsed.get("grass") == "leafy_grass_random":
			parsed.grass = "leafy_grass"
		if parsed.get("grass") in ["grass001", "grass001_soft1", "grass001_soft3"]:
			parsed.grass = "grass001_soft2"
		if parsed.get("grass") in ["grass005", "grass005_soft1", "grass005_soft3"]:
			parsed.grass = "grass005_soft2"
		if parsed.get("grass") == "grass008":
			parsed.grass = "grass008_soft"
		if parsed.get("asphalt") in ["asphalt_track", "asphalt_track_light_1", "asphalt_track_light_2", "asphalt_track_light_3", "asphalt_track_light_4", "asphalt_track_light_5", "asphalt_track_light_5_rotated", "asphalt_track_light_5_fine_rotated", "asphalt_track_light_5_finer_rotated"]:
			parsed.asphalt = "asphalt_track_light_5_fine_gray70_rotated"
		elif parsed.get("asphalt") in ["asphalt_track_light_6", "asphalt_track_light_6_rotated", "asphalt_track_light_6_fine_rotated", "asphalt_track_light_6_finer_rotated", "asphalt_track_light_6_fine_gray35_rotated"]:
			parsed.asphalt = "asphalt_track_light_6_fine_gray70_rotated"
		elif parsed.get("asphalt") == "clean_asphalt":
			parsed.asphalt = "clean_asphalt_rotated"
		elif parsed.get("asphalt") == "asphalt_pit_lane":
			parsed.asphalt = "none"
		elif parsed.get("asphalt") == "asphalt025a":
			parsed.asphalt = "asphalt025a_rotated"
		if parsed.get("marking") == "asphalt_track_light_5_fine_rotated":
			parsed.marking = "asphalt_track_light_6_fine_rotated"
		var placeholder = parsed.get("placeholder", DEFAULT_PLACEHOLDER)
		if placeholder in ["medium_50", "medium_70", "medium_85", "dark_50", "dark_70", "dark_85"]:
			placeholder = "light_85"
		if placeholder in ["light_50", "light_70"]:
			placeholder = "light_85"
		elif placeholder == "light_100":
			placeholder = "off_white_100"
		var state = {"line_filter": parsed.get("line_filter", device_type == "Tablet"), "scale": parsed.get("scale"), "msaa": parsed.get("msaa"), "shadows": parsed.get("shadows"), "grass": parsed.get("grass", GrassOptions.DEFAULT), "asphalt": parsed.get("asphalt", "none"), "marking": parsed.get("marking", "original"), "placeholder": placeholder}
		if valid(state): return state
	return {}
