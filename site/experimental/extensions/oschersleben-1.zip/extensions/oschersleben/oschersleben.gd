extends BaseScene
## Oschersleben owns its track, baked lighting and appearance controls.
const GrassOptions = preload("res://materials/grass_options.gd")
var grass_material: ShaderMaterial
var grass_variant := ""
var baked_scene: Node3D
var placeholder_material: ShaderMaterial = preload("res://materials/building_placeholder.tres").duplicate()
var baked_data: LightmapGIData

const LINE_DATA = {
	"Motorcycle_track_Image_boundaries0": preload("res://materials/Motorcycle_track_Image_boundaries0.res"),
	"Motorcycle_track_Image_boundaries1": preload("res://materials/Motorcycle_track_Image_boundaries1.res"),
}
var asphalt_variant := ""
var marking_variant := ""
var applied_line_filter := false

const Options = preload("res://extensions/oschersleben/graphics_options.gd")
var controls: Control

func _ready() -> void:
	add_child(preload("res://assets/oschersleben.glb").instantiate())
	get_child(get_child_count() - 1).name = "Track"
	_apply_building_placeholders($Track)
	RenderQuality.changed.connect(_apply)
	_apply()
	controls = preload("res://extensions/oschersleben/graphics_controls.gd").new()
	var menu = get_parent().get_node("Player/HUD/SettingsMenu")
	menu.display_tab.add_graphics_control(controls)
	controls.build(menu)

func _exit_tree() -> void:
	if is_instance_valid(controls): controls.queue_free()

func create_route(_definition: Dictionary) -> RefCounted:
	var route = preload("res://route_model.gd").new()
	route.load_file("res://assets/hover-route.json")
	return route

func _apply() -> void:
	placeholder_material.shader = preload("res://materials/building_placeholder_opaque.gdshader") if Options.PLACEHOLDER_OPTIONS[RenderQuality.snapshot().placeholder][1].a == 1.0 else preload("res://materials/building_placeholder.gdshader")
	placeholder_material.set_shader_parameter("tint", Options.PLACEHOLDER_OPTIONS[RenderQuality.snapshot().placeholder][1])
	if asphalt_variant != RenderQuality.snapshot().asphalt or marking_variant != RenderQuality.snapshot().marking or applied_line_filter != RenderQuality.snapshot().line_filter:
		asphalt_variant = RenderQuality.snapshot().asphalt
		marking_variant = RenderQuality.snapshot().marking
		applied_line_filter = RenderQuality.snapshot().line_filter
		_apply_asphalt($Track)
		if baked_scene != null: _apply_asphalt(baked_scene)
	if grass_variant != RenderQuality.snapshot().grass:
		grass_variant = RenderQuality.snapshot().grass
		grass_material = GrassOptions.material_for(grass_variant)
		_apply_grass($Track)
		if baked_scene != null: _apply_grass(baked_scene)
	var use_lightmaps: bool = RenderQuality.snapshot().shadows == "lightmaps"
	if use_lightmaps and baked_scene == null:
		if OS.has_feature("web"):
			JavaScriptBridge.eval("window.OscherslebenStartup?.mark('lightmaps_start_ms')")
		baked_scene = load("res://lighting/tower_pit.scn").instantiate()
		baked_scene.get_node("BakeSun").free()
		baked_data = baked_scene.get_node("LightmapGI").light_data
		add_child(baked_scene)
		_apply_building_placeholders(baked_scene)
		_apply_asphalt(baked_scene)
		_apply_grass(baked_scene)
		if OS.has_feature("web"):
			JavaScriptBridge.eval("window.OscherslebenStartup?.mark('lightmaps_end_ms')")
	if baked_scene != null:
		baked_scene.visible = use_lightmaps
		baked_scene.get_node("LightmapGI").light_data = baked_data if use_lightmaps else null
		for path in baked_scene.get_meta("replaced"):
			$Track.get_node(path).visible = not use_lightmaps
	$Sun.light_bake_mode = Light3D.BAKE_STATIC if use_lightmaps else Light3D.BAKE_DISABLED

func _apply_building_placeholders(scene: Node3D) -> void:
	for node in scene.find_children("*", "MeshInstance3D"):
		for surface in node.mesh.get_surface_count():
			var material = node.mesh.surface_get_material(surface)
			if material != null and material.resource_name in ["OS | Gebaeude", "OS | Dach"]:
				node.set_surface_override_material(surface, placeholder_material)

func _apply_grass(scene: Node3D) -> void:
	for node in scene.find_children("*", "MeshInstance3D"):
		for surface in node.mesh.get_surface_count():
			var material = node.mesh.surface_get_material(surface)
			if material != null and material.resource_name in ["OS | Gruenflaeche", "Grandstand | Buried terrain cover"]:
				node.set_surface_override_material(surface, grass_material)

func _apply_asphalt(scene: Node3D) -> void:
	var option: Array = Options.ASPHALT_OPTIONS[asphalt_variant]
	for node in scene.find_children("*", "MeshInstance3D"):
		var road := str(node.name).begins_with("Motorcycle track | Image boundaries")
		for s in node.mesh.get_surface_count():
			var source = node.mesh.surface_get_material(s)
			if not road and source.resource_name not in ["OS | Asphalt", "OS | Boxengasse"]: continue
			var filter_lines := road and applied_line_filter
			var material: ShaderMaterial
			var is_paint: bool = road and s == 1
			if filter_lines or (is_paint and marking_variant != "original") or (option[1] != null and source.resource_name != "OS | Markierungen"):
				material = ShaderMaterial.new()
				material.shader = preload("res://materials/line_test.gdshader")
				material.set_shader_parameter("asphalt", node.mesh.surface_get_material(0).albedo_color)
				material.set_shader_parameter("use_texture", option[1] != null)
				material.set_shader_parameter("surface_texture", option[1])
				material.set_shader_parameter("tile_metres", option[2])
				material.set_shader_parameter("texture_brightness", option[3])
				material.set_shader_parameter("random_rotation", option[4])
				if option.size() > 5:
					material.set_shader_parameter("gray_blend", option[5])
				material.set_shader_parameter("filter_lines", filter_lines)
				if filter_lines or is_paint:
					var paint: Color = node.mesh.surface_get_material(1).albedo_color
					if marking_variant != "original":
						paint = paint.darkened(0.17)
					material.set_shader_parameter("paint", paint)
					material.set_shader_parameter("is_paint", is_paint)
					if Options.MARKING_GRAIN.has(marking_variant):
						material.set_shader_parameter("paint_texture", Options.ASPHALT_TRACK)
						material.set_shader_parameter("paint_tile_metres", 1.5)
						material.set_shader_parameter("paint_texture_brightness", Options.MARKING_GRAIN[marking_variant])
				if filter_lines:
					var tag = str(node.name).replace(" | ", "_").replace(" ", "_") + str(s)
					material.set_shader_parameter("vertex_distances", node.get_meta("line_texture_%d" % s, LINE_DATA[tag]))
			node.set_surface_override_material(s, material)
