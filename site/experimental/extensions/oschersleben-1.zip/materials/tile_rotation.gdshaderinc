float hash_cell(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec2 quarter_turn(vec2 p, float turn) {
	if (turn < 1.0) return p;
	if (turn < 2.0) return vec2(-p.y, p.x);
	if (turn < 3.0) return -p;
	return vec2(p.y, -p.x);
}

vec3 sample_rotated_tile(sampler2D surface, vec2 uv, bool rotate_tiles) {
	// Derivatives before wrapping avoid incorrect mip levels at tile boundaries.
	vec2 dx = dFdx(uv);
	vec2 dy = dFdy(uv);
	if (rotate_tiles) {
		float turn = floor(hash_cell(floor(uv)) * 4.0);
		uv = quarter_turn(fract(uv) - vec2(0.5), turn) + vec2(0.5);
		dx = quarter_turn(dx, turn);
		dy = quarter_turn(dy, turn);
	}
	return textureGrad(surface, uv, dx, dy).rgb;
}
