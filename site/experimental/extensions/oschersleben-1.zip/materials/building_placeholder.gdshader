shader_type spatial;
render_mode depth_draw_always;

uniform vec4 tint : source_color = vec4(0.98, 0.98, 0.98, 0.7);
uniform sampler2D backdrop : hint_screen_texture, repeat_disable, filter_nearest;

void fragment() {
	// Mix each facade with the opaque scene. Depth selects the closest facade
	// even when the drawing order changes during a fly-by.
	// Keep most of the white independent of scene lighting, while retaining
	// some facade shading. The backdrop keeps the selected transparency.
	vec3 facade = tint.rgb * tint.a;
	ALBEDO = facade * 0.35;
	EMISSION = facade * 0.65 + textureLod(backdrop, SCREEN_UV, 0.0).rgb * (1.0 - tint.a);
	ROUGHNESS = 0.85;
	SPECULAR = 0.2 * tint.a * 0.35;
	ALPHA = 1.0;
}
