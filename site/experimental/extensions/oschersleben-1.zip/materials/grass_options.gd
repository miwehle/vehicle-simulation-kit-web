extends RefCounted
## Stable preference IDs; only grass surfaces receive these materials.
const DEFAULT = "forest_ground"
const OPTIONS = {
	"none": ["Ohne Textur", null, 1.4],
	"grass001_soft2": ["Grass001", preload("res://assets/textures/grass/grass001-color.jpg"), 1.4],
	"forest_ground": ["Forest Ground 01", preload("res://assets/textures/grass/forest-ground-01-color.jpg"), 2.0],
	"leafy_grass": ["Leafy Grass", preload("res://assets/textures/grass/leafy-grass-color.jpg"), 2.0],
	"grass005_soft2": ["Grass005", preload("res://assets/textures/grass/grass005-color.jpg"), 1.4],
	"grass008_soft": ["Grass008", preload("res://assets/textures/grass/grass008-color.jpg"), 1.4],
}

static func material_for(id: String) -> ShaderMaterial:
	if id == "none": return null
	var material = preload("res://materials/grass.tres").duplicate()
	material.set_shader_parameter("grass", OPTIONS[id][1])
	material.set_shader_parameter("repeat_m", OPTIONS[id][2])
	material.set_shader_parameter("approach", 0.5 if id in ["grass001_soft2", "grass005_soft2", "grass008_soft"] else 0.0)
	return material
