shader_type spatial;
render_mode cull_disabled;
uniform sampler2D vertex_distances : filter_nearest, repeat_disable;
uniform vec4 asphalt : source_color;
uniform vec4 paint : source_color;
uniform sampler2D paint_texture : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float paint_tile_metres = 1.5;
uniform float paint_texture_brightness = 0.0;
uniform bool is_paint;
uniform bool filter_lines;
uniform bool use_texture;
uniform sampler2D surface_texture : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float tile_metres = 2.0;
#include "res://materials/tile_rotation.gdshaderinc"
uniform bool random_rotation = false;
uniform float texture_brightness = 1.0;
uniform float gray_blend : hint_range(0.0, 1.0) = 0.0;
varying vec2 world_xz;
varying vec4 distances;
void vertex() {
	world_xz = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xz;
	distances = vec4(0.0);
	if (filter_lines) distances = texelFetch(vertex_distances, ivec2(VERTEX_ID % 128, VERTEX_ID / 128), 0);
}
float covered(vec2 d, vec2 pixel_width) {
	vec2 area = clamp(0.5 + d / max(pixel_width, vec2(0.0001)), 0.0, 1.0);
	return area.y - area.x;
}
void fragment() {
	vec3 surface_color = use_texture ? sample_rotated_tile(surface_texture, world_xz / tile_metres, random_rotation) * texture_brightness : asphalt.rgb;
	if (gray_blend > 0.0) {
		float luminance = dot(surface_color, vec3(0.2126, 0.7152, 0.0722));
		surface_color = mix(surface_color, vec3(luminance), gray_blend);
	}
	vec3 marking = paint.rgb;
	if (paint_texture_brightness > 0.0) {
		vec3 grain = sample_rotated_tile(paint_texture, world_xz / paint_tile_metres, true);
		marking = mix(marking, clamp(grain * paint_texture_brightness, vec3(0.0), vec3(1.0)), 0.16);
	}
	ALBEDO = is_paint ? marking : surface_color;
	if (filter_lines) {
		vec4 footprint = fwidth(distances);
		float coverage = clamp(covered(distances.xy, footprint.xy) + covered(distances.zw, footprint.zw), 0.0, 1.0);
		if ((abs(distances.x) + footprint.x < 0.0001) || (abs(distances.z) + footprint.z < 0.0001)) {
			coverage = is_paint ? 1.0 : 0.0;
		}
		ALBEDO = mix(surface_color, marking, coverage);
	}
	ROUGHNESS = 0.85;
}
