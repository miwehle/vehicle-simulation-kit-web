shader_type spatial;

uniform vec4 tint : source_color = vec4(0.98, 0.98, 0.98, 1.0);

void fragment() {
	// No screen texture or ALPHA: use the opaque render path for comparison.
	ALBEDO = tint.rgb;
	ROUGHNESS = 0.85;
	SPECULAR = 0.2;
}
