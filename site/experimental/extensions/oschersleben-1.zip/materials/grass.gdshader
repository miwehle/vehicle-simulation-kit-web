shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;

uniform sampler2D grass : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float repeat_m = 1.4;
uniform bool random_rotation = true;
uniform bool reduce_tiling = false;
uniform bool softer_green = false;
uniform bool aerial_tint = false;
// Original untextured meadow colour; same target as the local comparison.
uniform vec4 target_color : source_color = vec4(0.5838, 0.68, 0.4845, 1.0);
uniform float approach = 0.0;
varying vec3 world_position;

#include "res://materials/tile_rotation.gdshaderinc"

float broad_noise(vec2 p) {
	vec2 cell = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash_cell(cell), hash_cell(cell + vec2(1.0, 0.0)), f.x),
		mix(hash_cell(cell + vec2(0.0, 1.0)), hash_cell(cell + vec2(1.0)), f.x), f.y);
}

void vertex() {
	world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 uv = world_position.xz / repeat_m;
	vec3 color = sample_rotated_tile(grass, uv, random_rotation);
	if (reduce_tiling) {
		float fade = smoothstep(8.0, 45.0, distance(CAMERA_POSITION_WORLD, world_position));
		color = mix(color, textureLod(grass, vec2(0.5), 10.0).rgb, fade * 0.95);
		float variation = 0.65 * broad_noise(world_position.xz / 18.0)
			+ 0.35 * broad_noise(world_position.xz / 43.0 + vec2(17.3, 6.1));
		color *= mix(vec3(0.88, 0.95, 0.88), vec3(1.12, 1.05, 1.03), variation);
	}
	if (aerial_tint) {
		float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
		color = mix(vec3(luminance), color, 0.45) * vec3(0.88, 1.02, 1.08);
	}
	if (softer_green) {
		float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
		color = mix(vec3(luminance), color, 0.65);
	}
	if (approach > 0.0) {
		vec3 mean_color = textureLod(grass, vec2(0.5), 10.0).rgb;
		vec3 weights = vec3(0.2126, 0.7152, 0.0722);
		float detail = dot(color, weights) / max(dot(mean_color, weights), 0.001);
		color = mix(color, target_color.rgb * detail, approach);
	}
	ALBEDO = color;
	ROUGHNESS = 1.0;
	SPECULAR = 0.0;
}
