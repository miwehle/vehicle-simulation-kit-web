# Meadow surfaces

`materials/grass_options.gd` defines the six selectable surfaces and stable preference IDs. The table records the original sources and our modifications; short UI names omit those implementation details.

| UI name | Original source | Our modification | Tile size |
| --- | --- | --- | --- |
| Ohne Textur | Original grass materials in the project model | Restores the original materials; no image texture or colour adjustment | — |
| Grass001 | [ambientCG Grass001](https://ambientcg.com/view?id=Grass001) | Deterministic quarter turns; 50% colour adjustment described below | 1.4 m |
| Forest Ground 01 | [Poly Haven, Rob Tuytel](https://polyhaven.com/a/forrest_ground_01) | Deterministic quarter turns; no colour adjustment | 2 m |
| Leafy Grass | [Poly Haven, Charlotte Baglioni](https://polyhaven.com/a/leafy_grass) | Deterministic quarter turns; no colour adjustment | 2 m |
| Grass005 | [ambientCG Grass005](https://ambientcg.com/view?id=Grass005) | Deterministic quarter turns; 50% colour adjustment described below | 1.4 m (trial scale) |
| Grass008 | [ambientCG Grass008](https://ambientcg.com/view?id=Grass008) | Deterministic quarter turns; 50% colour adjustment described below | 1.4 m (trial scale) |

All five original colour maps are stored as unmodified 1K JPG assets. Rendering uses world-space mapping, mipmaps and anisotropic filtering. Each tile receives a deterministic pseudorandom rotation of 0°, 90°, 180° or 270° in `materials/grass.gdshader`; the image files themselves are not rotated or recoloured. The earlier "weniger Muster" modification is disabled for these choices.

For Grass001, Grass005 and Grass008, the shader blends 50% toward the original meadow colour (source-colour RGB 0.5838, 0.68, 0.4845). The target is multiplied by each texel's luminance relative to the texture's average luminance, preserving brightness detail while reducing colour intensity. This is the accepted former "dezenter" variant, not the original appearance. No additional image assets are needed.

The original images are CC0. License information: [ambientCG](https://docs.ambientcg.com/license/) and [Poly Haven](https://polyhaven.com/license).

`ui/scene_graphics.gd` overrides only `OS | Gruenflaeche` and `Grandstand | Buried terrain cover` in the original track and lightmap scene. Buildings, concrete, paving, geometry, collisions and existing lightmaps remain unchanged. All six choices support graphics draft/apply/cancel and confirmed persistence; switching mobile/desktop presets preserves the choice.

Stable preference IDs retain their earlier names (`grass001_soft2`, `grass005_soft2`, `grass008_soft`). Removed original Grass001/005/008 selections migrate to the corresponding retained variant, as do the retired 25%/75% trials. Removed Grass Ground and Withered Grass selections migrate to Forest Ground 01. Migration is implemented in `ui/render_quality.gd`.

Poliigon Flat Grass and PolyScan Sparse Grass on Dry Soil were local trials and are not shipped. Their saved selections migrate to the default meadow. The user-provided Poliigon image and its 50% hue-preserving brightness trial remain only under ignored `work/tmp/grass-texture-trial/poliigon/`, outside the Godot project, for the local comparison app. They must not be committed or exported.
