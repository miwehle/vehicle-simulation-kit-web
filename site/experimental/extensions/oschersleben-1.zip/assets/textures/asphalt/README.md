# Asphalt

Die Originale sind kachelbare 1K-Farbtexturen unter CC0. Alle Varianten entstehen beim Zeichnen in Godot aus denselben drei JPGs.

| Datei im Repository | Original | SHA-256 des JPG |
|---|---|---|
| `asphalt_track.jpg` | [Poly Haven · Asphalt Track](https://polyhaven.com/a/asphalt_track), Diffuse, 1K, JPG | `05c4e79cd99160075969d37bfc6ef72be262153a410bb45510b2c23f7303894c` |
| `clean_asphalt.jpg` | [Poly Haven · Clean Asphalt](https://polyhaven.com/a/clean_asphalt), Diffuse, 1K, JPG | `ddf9224e9cfa3eb2998d9097e4cd34bd3630c85e0e6798e5a0a000415a684083` |
| `asphalt025a.jpg` | [ambientCG · Asphalt 025 A](https://ambientcg.com/view?id=Asphalt025A), Color-JPG aus dem 1K-JPG-Paket | `937906797e5ba8b550b4997fe37b20e517d208c15a93972f073aa4452e11e80c` |

## Rezepte der auswählbaren Fahrbahnoberflächen

| Auswahl im Spiel | Quelldatei | Kachelbreite | Drehung je Kachel | Helligkeitsfaktor | Grauanteil |
|---|---|---:|---|---:|---:|
| Ohne Textur | Asphaltfarbe aus dem Streckenmodell | – | – | – | – |
| Asphalt Track · Warmgrau | `asphalt_track.jpg` | 1,5 m | zufällig | 2,55 | 70 % |
| Asphalt Track · Warmgrau hell | `asphalt_track.jpg` | 1,5 m | zufällig | 3,10 | 70 % |
| Asphalt Track · Neutralgrau hell | `asphalt_track.jpg` | 1,5 m | zufällig | 3,10 | 100 % |
| Clean Asphalt | `clean_asphalt.jpg` | 2,1 m | zufällig | 1,00 | 0 % |
| Asphalt 025 A | `asphalt025a.jpg` | 2,0 m | zufällig | 1,00 | 0 % |

1. **Auf die Strecke legen.** Die X- und Z-Weltkoordinaten in Metern durch die Kachelbreite teilen. Das ergibt die Texturkoordinate `uv`. Eine Bildwiederholung bedeckt ein Quadrat der angegebenen Breite.
2. **Kachel drehen.** Für `p = floor(uv)` ist die Anzahl der Vierteldrehungen `floor(4 * fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453))`. Die lokale Koordinate `fract(uv)` um die Kachelmitte (0,5; 0,5) drehen. Eine Vierteldrehung bildet den zentrierten Vektor (x, y) auf (−y, x) ab. Damit bleibt die Drehung am selben Ort während der Fahrt konstant.
3. **Farbe abtasten.** Godot importiert das JPG mit der zugehörigen `.jpg.import`-Datei. Der Shader verwendet `source_color`, Wiederholung und lineare anisotrope Mipmap-Filterung. Für `textureGrad` die Ableitungen der ursprünglichen Koordinate vor dem Kacheln bestimmen und um denselben Winkel drehen. [Kachelung im Shader](../../../materials/tile_rotation.gdshaderinc)
4. **Aufhellen, dann vergrauen.** Den abgetasteten RGB-Wert mit dem Helligkeitsfaktor multiplizieren. Aus diesem aufgehellten Wert `C` die Helligkeit `Y = dot(C, vec3(0.2126, 0.7152, 0.0722))` bilden. Die Asphaltfarbe ist `mix(C, vec3(Y), Grauanteil / 100)`. Sie geht als Albedo mit Rauheit 0,85 in die Beleuchtung ein. Die Lightmap bleibt davon unabhängig. [Farbmischung im Shader](../../../materials/line_test.gdshader)

## Fahrbahnmarkierung

Die Markierung ist separat wählbar. **Wie bisher** verwendet die Markierungsfarbe aus dem Streckenmodell. **Gebrochenes Weiß** verwendet dieselbe Farbe, in Godot mit `darkened(0.17)` um 17 % abgedunkelt.

Für **Gekörnt · Hell 5 · fein** und **Gekörnt · Hell 6 · fein** bildet gebrochenes Weiß die Basis. Dazu `asphalt_track.jpg` mit 1,5 m Kachelbreite und derselben Vierteldrehung abtasten, mit 2,55 bzw. 3,10 multiplizieren und jeden Farbkanal auf [0, 1] begrenzen. Der Shader mischt 84 % gebrochenes Weiß mit 16 % dieser Körnung. Die Körnung der Markierung hat keinen Grauanteil. Bei eingeschaltetem Linienfilter bestimmt die berechnete Linienabdeckung den Übergang zwischen Asphalt und Markierung.

Die Menüwerte stehen in [render_quality.gd](../../../ui/render_quality.gd), die Materialzuordnung in [scene_graphics.gd](../../../ui/scene_graphics.gd).
