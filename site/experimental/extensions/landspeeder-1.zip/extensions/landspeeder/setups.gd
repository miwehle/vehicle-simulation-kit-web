extends RefCounted
## Built-in and personal driving presets shared by desktop and web.
const DRIFT := {
	"grip_g": 1.10, "slide_band_g": 0.60,
	"front_residual_percent": 88.0, "rear_residual_percent": 97.0,
	"electric_front_drive_percent": 15.0, "front_brake_percent": 70.0,
}
const CURVES := {
	"steering_exponent": 1.0, "throttle_exponent": 1.0,
	"brake_exponent": 1.0, "steer_deg_at_100_kmh": 3.0,
}

## Built-ins are reconstructed from vehicle defaults; only personal setups go on disk.
const SINGLE_TRACK := "Nichtlineares Einspurmodell"
const CLASSIC := "Beschleunigungsmodell"
const PRACTICE := "Driftübung"
const FLIGHT := "Erkundungsflug"
const FLIGHT_DEFAULTS = preload("res://physics/exploration_flight_model.gd").DEFAULT_LIMITS
const ASSIST_DEFAULTS := {"steering_rate": 10.0, "vertical_steering_rate": 10.0, "fast_horizontal_rate": 50.0, "fast_vertical_rate": 50.0, "hold_entry_seconds": 0.2}
const FLIGHT_PATH := "user://erkundungsflug.cfg"
var flight_values: Dictionary = {}
const VehicleConfiguration = preload("res://physics/vehicle_configuration.gd")

const PATH := "user://fahrsetups.cfg"

var active := ""
var personal := {}
var factory := {}

var temporary := false

func default_flight_values() -> Dictionary:
	return FLIGHT_DEFAULTS.merged(preload("res://vehicles/controllers/gamepad_controller.gd").FLIGHT_DEFAULTS).merged(ASSIST_DEFAULTS)

func configure() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "--fahrsetup=drift-uebung":
			temporary = true
		elif arg.begins_with("--fahrsetup"):
			push_error("Unbekanntes Fahrsetup: %s (verfügbar: --fahrsetup=drift-uebung)" % arg)
			Engine.get_main_loop().quit(2)
			return

func initialize(baseline: Dictionary, previous: Dictionary, has_saved_settings: bool) -> void:
	var classic := baseline.duplicate(true)
	classic.merge({"road_model": 0, "mode": 8, "electric_drive": false}, true)
	var road := baseline.duplicate(true)
	road.merge({"road_model": 1, "mode": 9, "electric_drive": true, "automatic": true,
		"upshift_rpm": 12500.0, "downshift_rpm": 6500.0}, true)
	road.drift.merge({"grip_g": 1.30, "slide_band_g": 0.30, "front_residual_percent": 88.0,
		"rear_residual_percent": 82.0, "electric_front_drive_percent": 50.0,
		"pc40_front_drive_percent": 0.0, "front_brake_percent": 70.0}, true)
	road.drift.merge({"front_stiffness": 209.0, "rear_stiffness": 242.0}, true)
	road.v5.merge(CURVES, true)
	road.v5.steer_deg_at_100_kmh = 2.0
	road.v5.grip_factors = Vector3(0.5, 1.3, 1.3)
	var practice := baseline.duplicate(true)
	practice.merge({"road_model": 1, "mode": 9, "electric_drive": true}, true)
	practice.drift.merge(DRIFT, true)
	practice.v5.merge(CURVES, true)
	factory = {CLASSIC: classic, SINGLE_TRACK: road}
	active = ""
	personal = {}
	var config := ConfigFile.new()
	var saved := FileAccess.file_exists(PATH) and config.load(PATH) == OK
	flight_values = default_flight_values()
	var flight_config := ConfigFile.new()
	if flight_config.load(FLIGHT_PATH) == OK:
		for key in flight_values:
			var value = flight_config.get_value("flight", key, flight_values[key])
			if (value is float or value is int) and is_finite(value): flight_values[key] = value
	var removed_flight_setups := false
	for scene in SimulationLibrary.scenes.values(): scene.erase("flight")
	if saved:
		personal = config.get_value("setups", "personal", {})
		active = config.get_value("setups", "active", "")
		# Preserve personal presets that now share a title with a built-in.
		for title in personal.keys():
			if personal[title].has("flight"):
				personal.erase(title)
				removed_flight_setups = true
				continue
			for builtin in factory:
				if title.nocasecmp_to(builtin) == 0:
					var renamed := _unused_name(title + " · Persönlich")
					personal[renamed] = personal[title]
					personal.erase(title)
					if active == title: active = renamed
					break
		if not personal.has(active):
			active = {"Beschleunigungsmodell · V5": CLASSIC, "Einspurmodell · Elektro": SINGLE_TRACK}.get(active, active)
	if not config.get_value("setups", "practice_initialized", false):
		personal.get_or_add(PRACTICE, practice)
	# Older versions stored a separate unnamed snapshot, even when a named setup was active.
	var migrate_previous := config.has_section_key("setups", "current") or (not saved and has_saved_settings)
	if migrate_previous:
		var old: Dictionary = config.get_value("setups", "current", previous)
		var imported := _import_previous(previous if old.has("flight") else old)
		if active in ["", "Aktuelle Abstimmung"]: active = imported
	for setup in personal.values():
		for section in ["drift", "powertrain", "v5"]:
			var values: Dictionary = setup.get_or_add(section, {})
			values.merge(baseline[section])
	if not personal.has(active) and not factory.has(active):
		active = SINGLE_TRACK
	if temporary:
		personal[PRACTICE] = practice
		active = PRACTICE
	# Writing the current format removes the legacy snapshot and completes migration.
	if migrate_previous or not saved or removed_flight_setups: persist()

func persist_flight() -> void:
	if temporary: return
	var config := ConfigFile.new()
	for key in flight_values: config.set_value("flight", key, flight_values[key])
	if config.save(FLIGHT_PATH) != OK:
		push_error("Erkundungsflug-Einstellungen konnten nicht gespeichert werden.")

func _unused_name(base: String) -> String:
	var title := base
	var number := 2
	while personal.has(title) or factory.has(title):
		title = "%s (%d)" % [base, number]
		number += 1
	return title

func _import_previous(setup: Dictionary) -> String:
	for title in factory.keys() + personal.keys():
		var candidate: Dictionary = factory.get(title, personal.get(title, {}))
		if recursive_equal_approx(setup, candidate): return title
	var base: String = "Einspurmodell" if setup.road_model == 1 else "Beschleunigungsmodell"
	var title := _unused_name(base + " · Persönlich")
	personal[title] = setup.duplicate(true)
	return title

func recursive_equal_approx(left: Dictionary, right: Dictionary) -> bool:
	if left.size() != right.size(): return false
	for key in left:
		if not right.has(key): return false
		if left[key] is Dictionary:
			if not right[key] is Dictionary or not recursive_equal_approx(left[key], right[key]): return false
		elif left[key] is float and right[key] is float:
			if not is_equal_approx(left[key], right[key]): return false
		elif left[key] != right[key]: return false
	return true

func persist() -> void:
	if temporary: return
	var config := ConfigFile.new()
	config.load(PATH)
	if config.has_section_key("setups", "current"): config.erase_section_key("setups", "current")
	config.set_value("setups", "ids", SimulationLibrary.vehicle_ids)
	config.set_value("setups", "practice_initialized", true)
	config.set_value("setups", "personal", personal)
	config.set_value("setups", "active", active)
	if config.save(PATH) != OK: push_error("Fahrsetups konnten nicht gespeichert werden.")
	SimulationLibrary.persist()

func vehicle_id(title: String) -> String:
	return SimulationLibrary.vehicle_id(title)

func vehicles(personal_values: Dictionary) -> Array:
	var result: Array = []
	for title in factory.merged(personal_values):
		var record = ExtensionManager.vehicles[ExtensionManager.default_vehicle_id].duplicate(true)
		record.id = vehicle_id(title)
		record.title = title
		record.parameters = factory.get(title, personal_values.get(title, {}))
		record.model_id = record.road_models[record.parameters.road_model]
		result.append(record)
	return result

func library_snapshot() -> Dictionary:
	return {"personal": personal.duplicate(true), "active": active, "flight": flight_values.duplicate()}

func restore_library(saved: Dictionary) -> void:
	personal = saved.personal.duplicate(true)
	active = saved.active
	flight_values = saved.flight.duplicate()
