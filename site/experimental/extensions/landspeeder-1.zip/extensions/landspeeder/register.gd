extends RefCounted
## Vehicle offers are available before the world and its settings are created.
static func register(manager: Node, provider: Node) -> void:
	manager.add_vehicle_model(provider, &"landspeeder.acceleration", func(): return AccelerationModel.new())
	manager.add_vehicle_model(provider, &"landspeeder.single_track", func(): return SingleTrackModel.new())
	manager.add_vehicle_model(provider, &"landspeeder.exploration", func(): return ExplorationFlightModel.new())
	var definition = preload("res://physics/vehicle_configuration.gd").new()
	definition.title = "Landspeeder"
	definition.editor_script = load("res://extensions/landspeeder/vehicles_tab.gd")
	definition.setups_script = load("res://extensions/landspeeder/setups.gd")
	definition.extension_id = "landspeeder"
	definition.model_id = &"landspeeder.acceleration"
	definition.road_models.assign([&"landspeeder.acceleration", &"landspeeder.single_track"])
	definition.exploration_model = &"landspeeder.exploration"
	definition.powertrain_models.assign([preload("res://physics/engine_model.gd"), preload("res://physics/electric_drive.gd")])
	definition.instruments_script = preload("dashboard.gd")
	definition.visual_scene = preload("landspeeder.tscn")
	definition.bounds = preload("geometry.gd").bounds()
	manager.add_vehicle(provider, &"landspeeder", definition)
