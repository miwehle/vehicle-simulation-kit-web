extends Control
## Compact central overlay for engine speed and selected gear.

const ElectricDrive = preload("res://physics/electric_drive.gd")
const MAX_RPM := 15500.0
const REDLINE_RPM := 12000.0
const MUTED := Color(0.48, 0.62, 0.72)
const ACTIVE := Color(0.2, 0.78, 1.0)
const WARNING := Color(1.0, 0.35, 0.2)

const STAGE_COLORS: Array[Color] = [
	Color("#777777"), Color.BLACK, Color("#681100"), Color("#c11b1b"),
	Color("#e9582c"), Color("#ffcf61"), Color.WHITE,
]

var electric := false
var compact := false
var speed_kmh := 0.0

var gear := 1
var rpm := 1800.0
var crashed := false
var automatic_upshift := false
var auto_upshift_rpm := 12500.0
var auto_downshift_rpm := 6500.0


func set_values(new_gear: int, new_rpm: float, new_crashed: bool, new_automatic_upshift: bool, new_auto_upshift_rpm: float, new_auto_downshift_rpm: float) -> void:
	gear = new_gear
	rpm = new_rpm
	crashed = new_crashed
	automatic_upshift = new_automatic_upshift
	auto_upshift_rpm = new_auto_upshift_rpm
	auto_downshift_rpm = new_auto_downshift_rpm
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var number_position := Vector2(0, 45 if compact else 57)
	var number_size := 42 if compact else 51
	if electric:
		var stage := ElectricDrive.stage_at_speed(speed_kmh)
		var color := STAGE_COLORS[stage]
		if stage == 1 or stage == 2:
			draw_string_outline(font, number_position, str(stage), HORIZONTAL_ALIGNMENT_CENTER, size.x, number_size, 1, Color("#c4bebb"))
		draw_string(font, number_position, str(stage), HORIZONTAL_ALIGNMENT_CENTER, size.x, number_size, color)
		return
	var rpm_ratio := clampf(rpm / MAX_RPM, 0.0, 1.0)
	var redline_ratio := REDLINE_RPM / MAX_RPM
	var rpm_color := WARNING if crashed or rpm >= REDLINE_RPM else ACTIVE
	var margin := 16.0 if compact else 24.0
	var bar := Rect2(margin, 53.0 if compact else 69.0, size.x - 2 * margin, 6.0 if compact else 7.5)
	var shift_x := bar.position.x + bar.size.x * clampf(auto_upshift_rpm / MAX_RPM, 0.0, 1.0)
	var downshift_x := bar.position.x + bar.size.x * clampf(auto_downshift_rpm / MAX_RPM, 0.0, 1.0)

	draw_string(font, number_position, str(gear), HORIZONTAL_ALIGNMENT_CENTER, size.x, number_size, rpm_color)
	draw_string(font, Vector2(margin, 16.0 if compact else 20.0), "AUTO" if automatic_upshift else "TEILAUTO", HORIZONTAL_ALIGNMENT_LEFT, 100.0, 11, ACTIVE if automatic_upshift else MUTED)
	draw_rect(bar, Color(0.18, 0.28, 0.35, 0.9), true)
	draw_rect(Rect2(bar.position + Vector2(bar.size.x * redline_ratio, 0.0), Vector2(bar.size.x * (1.0 - redline_ratio), bar.size.y)), Color(0.55, 0.12, 0.08, 0.9), true)
	if rpm_ratio > 0.0:
		draw_rect(Rect2(bar.position, Vector2(bar.size.x * rpm_ratio, bar.size.y)), rpm_color, true)
	for index in 8:
		var x := bar.position.x + bar.size.x * index / 7.0
		draw_line(Vector2(x, bar.position.y - 3.0), Vector2(x, bar.end.y + 3.0), Color(0.8, 0.9, 0.95, 0.62), 1.5, true)
	draw_line(Vector2(downshift_x, bar.position.y - 5.0), Vector2(downshift_x, bar.end.y + 3.0), Color(0.9, 0.94, 0.96, 0.8), 2.0, true)
	draw_line(Vector2(shift_x, bar.position.y - 7.0), Vector2(shift_x, bar.end.y + 5.0), ACTIVE if automatic_upshift else MUTED, 2.5, true)

