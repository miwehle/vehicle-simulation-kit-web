extends "res://ui/dialogs/vehicles_tab.gd"
## Vehicle selection with replaceable model controls. Saving remains dialog-wide.


const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
var sliders: Dictionary[StringName, HSlider] = {}

var road_controls := VBoxContainer.new()
var _road_model := 0
var setup_management := VBoxContainer.new()
var model_profiles := [8, 9]
var automatic_button: CheckButton
var drive_button: OptionButton
var gearbox_options: VBoxContainer = VBoxContainer.new()
var road_model_button: OptionButton
var open_powertrain: Button
var open_drift: Button
var open_curves: Button
# Stable variant numbers, independent of device filtering and persisted mode IDs.


func build(settings_menu) -> void:
	setups.free()
	setups = preload("setup_picker.gd").new()
	menu = settings_menu
	for group in [model_content, road_controls]:
		group.add_theme_constant_override("separation", 14)
	add_child(setups)
	setups.build(menu)
	var model_row: BoxContainer = menu.add_responsive_row(self)
	model_row.add_child(menu.make_label("Fahrzeugmodell", 20))
	var model_names: Array[String] = [SimulationLibrary.vehicle_setups.CLASSIC, SimulationLibrary.vehicle_setups.SINGLE_TRACK]
	road_model_button = menu.add_option_button(model_row, model_names)
	road_model_button.fit_to_longest_item = false
	road_model_button.clip_text = true
	road_model_button.item_selected.connect(_select_model)
	open_drift = _details_button(model_row, 0)
	add_child(model_content)
	model_content.add_child(road_controls)
	var control_row: BoxContainer = menu.add_responsive_row(road_controls)
	control_row.add_child(menu.make_label("Steuerung", 20))
	var control_names: Array[String] = ["Erweiterte Tastatursteuerung", "Vier Pfeiltasten"]
	control_mode_button = menu.add_option_button(control_row, control_names)
	control_mode_button.fit_to_longest_item = false
	control_mode_button.clip_text = true
	control_mode_button.item_selected.connect(func(_index): control_options_changed.emit())
	open_curves = _details_button(control_row, 1)
	var drive_row: BoxContainer = menu.add_responsive_row(road_controls)
	drive_row.add_child(menu.make_label("Antriebsmodell", 20))
	var drive_names: Array[String] = ["PC40", "Elektro-Direktantrieb"]
	drive_button = menu.add_option_button(drive_row, drive_names)
	drive_button.fit_to_longest_item = false
	drive_button.clip_text = true
	open_powertrain = _details_button(drive_row, 2)
	drive_button.item_selected.connect(func(index):
		gearbox_options.visible = index == 0
		setups.show_drive(index == 1))
	drive_button.item_selected.connect(func(_index): control_options_changed.emit())
	road_controls.add_child(gearbox_options)
	menu.add_section(gearbox_options, "GETRIEBE")
	automatic_button = CheckButton.new()
	automatic_button.text = "Vollautomatik"
	menu.style_action_button(automatic_button)
	gearbox_options.add_child(automatic_button)
	menu.add_section(gearbox_options, "SCHALTDREHZAHLEN")
	_add_slider(gearbox_options, &"upshift_rpm", "Hochschalten (Teilgas)", 9000.0, 13500.0, 500.0)
	_add_slider(gearbox_options, &"downshift_rpm", "Runterschalten", 4000.0, 8500.0, 500.0)
	setup_management.add_theme_constant_override("separation", 14)
	add_child(setup_management)
	setups.build_management(setup_management)


func _details_button(row: BoxContainer, panel_index: int) -> Button:
	var button: Button = menu.add_action_button(row, "Parameter", setups.open_panel.bind(panel_index))
	button.autowrap_mode = TextServer.AUTOWRAP_OFF
	button.size_flags_horizontal = Control.SIZE_SHRINK_END
	return button

## The extension mounts its panel through add_dialog_control before registering it here.



func _refresh_model_choices() -> void:
	_road_model = ground_model()
	road_model_button.clear()
	road_model_button.add_item(SimulationLibrary.vehicle_setups.CLASSIC)
	road_model_button.add_item(SimulationLibrary.vehicle_setups.SINGLE_TRACK)
	var added: Array[StringName] = []
	for definition in extension_vehicles():
		if definition.model_id in added: continue
		added.append(definition.model_id)
		road_model_button.add_item(definition.title)
		road_model_button.set_item_metadata(road_model_button.item_count - 1, definition.model_id)
	_show_vehicle_selection()
	setups._refresh_choices()

func select_extension_vehicle(id: StringName) -> void:
	if extension_vehicle_id.is_empty() and not id.is_empty() and not menu.original.is_empty():
		setups._store_current()
		setups.selected_setup = setups.ground_title
	extension_vehicle_id = id
	_show_vehicle_selection()
	setups._refresh_choices()
	menu.simulation_scene_tree.refresh()

func _show_vehicle_selection() -> void:
	var definition = ExtensionManager.vehicles.get(extension_vehicle_id)
	var panel: Control = model_panels.get(definition.model_id) if definition != null else null
	road_model_button.select(_road_model)
	if panel != null:
		for index in range(2, road_model_button.item_count):
			if road_model_button.get_item_metadata(index) == definition.model_id:
				road_model_button.select(index)
	show_model_panel(panel)
	setup_management.visible = panel == null

func _select_model(index: int) -> void:
	if index < 2:
		extension_vehicle_id = &""
		_select_road_model(index)
		_show_vehicle_selection()
		setups._refresh_choices()
		return
	var id: StringName = road_model_button.get_item_metadata(index)
	for definition in extension_vehicles():
		if definition.model_id == id:
			select_extension_vehicle(definition.id)
			return

## Preserve the road editor independently while another vehicle is being inspected.
func ground_model() -> int:
	return road_model_button.selected if road_model_button.selected in [0, 1] else _road_model

## Mount extension panels with ExtensionManager.add_dialog_control into model_content;
## its callbacks handle changes, saving and discarding. Null selects the road controls.
func show_model_panel(panel: Control = null) -> void:
	assert(panel == null or panel.get_parent() == model_content)
	if is_instance_valid(_model_panel):
		_model_panel.tree_exiting.disconnect(_panel_exiting)
	_model_panel = panel
	if panel != null:
		panel.tree_exiting.connect(_panel_exiting)
	for child in model_content.get_children():
		if child is Control:
			child.visible = child == (panel if panel != null else road_controls)
	refresh_options()

func _panel_exiting() -> void:
	if is_inside_tree(): show_model_panel()

func control_profiles() -> Array:
	var profiles := model_profiles.duplicate()
	profiles[ground_model()] = control_mode_button.get_selected_id()
	return profiles

func _select_road_model(index: int) -> void:
	_road_model = index
	model_profiles[1 - index] = control_mode_button.get_selected_id()
	menu.configure_controls(menu.touch_device, menu.tilt_available, menu.tilt_requestable)
	var mode := available_mode(model_profiles[index])
	control_mode_button.select(control_mode_button.get_item_index(mode))
	control_options_changed.emit()

func restore_model_selection(draft: Dictionary) -> void:
	drive_button.select(1 if draft.electric_drive else 0)
	gearbox_options.visible = not draft.electric_drive
	model_profiles = draft.profiles.duplicate()
	_road_model = draft.road_model
	extension_vehicle_id = draft.get("extension_vehicle", "")
	_show_vehicle_selection()

func configure_controls(touch: bool, tilt_ready: bool) -> void:
	var previous := control_mode_button.get_selected_id()
	touch_device = touch
	control_mode_button.clear()
	var modes: Array = [9] if ground_model() == 1 else [4, 5, 8]
	if touch:
		modes.push_front(3)
	elif ground_model() == 0:
		modes = [0, 1] + modes
	if touch and tilt_ready:
		modes.push_front(2)
	for mode in modes:
		control_mode_button.add_item(CONTROL_NAMES[mode], mode)
	control_mode_button.select(control_mode_button.get_item_index(available_mode(previous)))

func available_mode(mode: int) -> int:
	if control_mode_button.get_item_index(mode) >= 0:
		return mode
	if ground_model() == 1 and (not touch_device or mode in [4, 5, 8]):
		return 9
	return 3 if touch_device else 1

func refresh_options() -> void:
	automatic_button.disabled = control_mode_button.get_selected_id() != 0
	open_powertrain.visible = true
	open_drift.visible = _model_panel == null and ground_model() == 1
	open_curves.visible = control_mode_button.get_selected_id() == 9

var vehicle: Vehicle
var curve_panel
var drift_panel
var powertrain_panel

func initialize_vehicle(player: Vehicle) -> void:
	vehicle = player
	curve_panel = preload("res://ui/dialogs/gamepad_curve_panel.gd").new()
	powertrain_panel = preload("powertrain_panel.gd").new()
	drift_panel = preload("drift_panel.gd").new()
	curve_panel.model = vehicle.gamepad
	powertrain_panel.pc40 = vehicle.powertrains[0]
	powertrain_panel.electric_drive = vehicle.powertrains[1]
	powertrain_panel.picker = setups
	drift_panel.model = vehicle.road_models[1]
	drift_panel.mass_changed.connect(func(value):
		for engine in vehicle.powertrains: engine.mass_kg = value)
	for panel in [curve_panel, powertrain_panel, drift_panel]:
		panel.managed_by_setups = true
		menu.hud.add_child(panel)
	vehicle.drive_changed.connect(func(electric):
		powertrain_panel.set_electric_drive(electric)
		drift_panel.set_electric_drive(electric)
		menu.hud.update_layout.call_deferred())
	menu.setting_changed.connect(func(key, value):
		if key == &"upshift_rpm": vehicle.auto_upshift_rpm = value
		elif key == &"downshift_rpm": vehicle.powertrains[0].auto_downshift_rpm = value)

func device_defaults() -> void:
	vehicle.powertrains[0].auto_downshift_rpm = 7000.0

func sync_values(values: Dictionary) -> void:
	values[&"upshift_rpm"] = vehicle.auto_upshift_rpm
	values[&"downshift_rpm"] = vehicle.powertrains[0].auto_downshift_rpm

func initialize_setups(has_saved: bool) -> void:
	setups.initialize_setups([drift_panel, curve_panel, powertrain_panel], has_saved)
	vehicle.flight.limits.merge(SimulationLibrary.vehicle_setups.flight_values, true)
	vehicle.gamepad.flight_settings.merge(SimulationLibrary.vehicle_setups.flight_values, true)
	if SimulationLibrary.temporary: menu.get_window().title += " · Driftübung"

func snapshot() -> Dictionary:
	var draft := super().merged({"electric_drive": drive_button.selected == 1, "road_model": ground_model(), "profiles": control_profiles(), "automatic": automatic_button.button_pressed})
	for key in sliders: draft.values[key] = sliders[key].value
	return draft

func apply(draft: Dictionary) -> void:
	vehicle._on_road_model_changed(int(draft.road_model))
	vehicle.select_powertrain(1 if draft.electric_drive else 0)
	vehicle._on_automatic_changed(draft.automatic)

func set_values(values: Dictionary, automatic: bool, mode: int) -> void:
	super(values, automatic, mode)
	for key in sliders: sliders[key].value = float(values[key])
	automatic_button.button_pressed = automatic
	automatic_button.disabled = mode != 0

func hide_panels() -> void:
	for panel in [curve_panel, drift_panel, powertrain_panel]: panel.hide()

func select_vehicle(entry: Resource) -> void:
	if entry.road_models.is_empty(): select_extension_vehicle(entry.id)
	elif setups.ground_title != entry.title or not extension_vehicle_id.is_empty(): setups._choose_setup(entry.title)

func details(entry: Resource) -> Dictionary:
	if entry.road_models.is_empty(): return super(entry)
	var values: Dictionary = setups._ground_setup() if setups.ground_title == entry.title else entry.parameters
	var powertrain: Dictionary = values.powertrain
	var kw: float = powertrain.traction_n * powertrain.base_speed_kmh / 3600.0 if values.electric_drive else powertrain.pc40_peak_ps * 0.73549875
	return {"Fahrzeugmodell": "Nichtlineares Einspurmodell" if values.road_model == 1 else "Beschleunigungsmodell",
		"Antriebsmodell": "Elektro-Direktantrieb" if values.electric_drive else "Honda CBR 600",
		"Spitzenleistung am Rad": UiNumbers.display("%.1f kW / %.1f PS" % [kw, kw / 0.73549875]),
		"Masse": UiNumbers.display("%.0f kg" % values.drift.get("mass_kg", 260))}

func restore_saved(saved: Dictionary, draft: Dictionary) -> void:
	super(saved, draft)
	for key in sliders:
		var value: Variant = saved.values.get(key)
		if (value is float or value is int) and is_finite(float(value)):
			draft.values[key] = clampf(float(value), sliders[key].min_value, sliders[key].max_value)
	draft.electric_drive = saved.electric_drive if saved.get("electric_drive") is bool else false
	var model_id: Variant = saved.get("road_model")
	if (model_id is float or model_id is int) and (model_id == 0 or model_id == 1):
		draft.road_model = int(saved.road_model)
		if saved.get("profiles") is Array and saved.profiles.size() == 2:
			for i in 2:
				var profile: Variant = saved.profiles[i]
				if (profile is float or profile is int) and int(profile) in [0, 1, 2, 3, 4, 5, 8, 9]:
					draft.profiles[i] = int(profile)
	elif draft.mode == 8 and FileAccess.file_exists("user://gamepad_curves.cfg"):
		# The interim test version used V5's ID for the editable profile.
		draft.road_model = 1
		draft.mode = 9
		draft.profiles = [8, 9]
	if saved.get("automatic") is bool: draft.automatic = saved.automatic

func handle_gamepad(event: InputEventJoypadButton) -> bool:
	var openers := [open_drift, open_curves, open_powertrain]
	var all_panels: Array = setups.panels + setups.flight_panels
	for i in range(all_panels.size() - 1, -1, -1):
		if all_panels[i].visible:
			if event.pressed and event.button_index == JOY_BUTTON_B:
				all_panels[i].hide()
				if i < openers.size(): openers[i].grab_focus()
				else: menu.focus_active_page()
			return true
	return false

func _add_slider(parent: VBoxContainer, key: StringName, title: String, minimum: float, maximum: float, step: float) -> void:
	sliders[key] = UiNumbers.add_labeled_slider(menu.add_responsive_row(parent), title, minimum, maximum, step, "%d/min")
