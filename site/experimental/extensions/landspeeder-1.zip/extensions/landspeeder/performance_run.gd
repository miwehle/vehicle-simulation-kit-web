extends RefCounted
## Straight-line full-throttle test using separate instances of the driving models.

const STEP := 1.0 / 60.0
var drive
var road
var elapsed := 0.0
var time_100 := -1.0
var time_200 := -1.0
var top_kmh := 0.0
var finished := false
var converged := false
var checkpoint_speed := 0.0
var checkpoint_time := 0.0

func _init(setup: Dictionary) -> void:
	if setup.electric_drive:
		drive = preload("res://physics/electric_drive.gd").new()
		drive.traction_n = setup.powertrain.traction_n
		drive.base_speed_kmh = setup.powertrain.base_speed_kmh
	else:
		drive = preload("res://physics/engine_model.gd").new()
		drive.pc40_peak_ps = setup.powertrain.pc40_peak_ps
	drive.mass_kg = setup.drift.mass_kg
	drive.auto_downshift_rpm = setup.downshift_rpm
	if setup.road_model == 1:
		road = preload("res://physics/single_track_model.gd").new()
		for key in setup.drift:
			road.set(key, setup.drift[key])
	else:
		road = preload("res://physics/acceleration_model.gd").new()

func advance() -> void:
	var before: float = road.speed_mps * 3.6
	drive.update_gearbox(road.speed_mps, true, 0.0, true, true)
	road.advance(Vector3.ZERO, 1.0, 0.0, 0.0, false, drive, STEP)
	drive.update_vehicle_state(road.speed_mps, road.crashed, STEP, 1.0)
	var after: float = road.speed_mps * 3.6
	if time_100 < 0 and before < 100 and after >= 100:
		time_100 = elapsed + STEP * inverse_lerp(before, after, 100.0)
	if time_200 < 0 and before < 200 and after >= 200:
		time_200 = elapsed + STEP * inverse_lerp(before, after, 200.0)
	elapsed += STEP
	top_kmh = maxf(top_kmh, after)
	if elapsed - checkpoint_time >= 3.0:
		converged = absf(after - checkpoint_speed) < 0.001
		checkpoint_speed = after
		checkpoint_time = elapsed
	finished = converged or road.crashed or elapsed >= 600.0
