extends "res://ui/dialogs/tuning_panel.gd"
const PARAMETERS := [
	["yaw_inertia", "Gierträgheit", 60, 500, 1, "%.0f kg·m²"],
	["front_stiffness", "Seitensteifigkeit vorn", 80, 400, 0, "%.0f N/°"],
	["rear_stiffness", "Seitensteifigkeit hinten", 80, 400, 0, "%.0f N/°"],
	["mass_kg", "Masse", 150, 650, 1, "%.0f kg"],
	["wheelbase_m", "Radstand", 1.0, 2.5, 0.01, "%.2f m"],
	["front_load_percent", "Statische Achslast", 25, 75, 1, "%.0f %%"],
	["grip_g", "Haftgrenze", 0.8, 1.8, 0.01, "%.2f g"],
	["slide_band_g", "Breite des Grenzbereichs", 0.1, 0.8, 0.01, "%.2f g"],
	["front_residual_percent", "Resthaftung vorne", 20, 100, 1, "%.0f %%"],
	["rear_residual_percent", "Resthaftung hinten", 20, 100, 1, "%.0f %%"],
	["pc40_front_drive_percent", "Antriebsbalance · PC40", 0, 100, 1, "%.0f %%"],
	["electric_front_drive_percent", "Antriebsbalance · Elektro", 0, 100, 1, "%.0f %%"],
	["front_brake_percent", "Bremsbalance", 0, 100, 1, "%.0f %%"],
]

signal mass_changed(value: float)

var geometry := Label.new()
var threshold := Label.new()
var axle_status := Label.new()

func _ready() -> void:
	save_path = "user://drift.cfg"
	section = "drift"
	build_panel("Parameter des Fahrmodells", PARAMETERS, Vector2(16, 112))
	set_electric_drive(false)

func set_electric_drive(electric: bool) -> void:
	slider_rows.pc40_front_drive_percent.visible = not electric
	slider_rows.electric_front_drive_percent.visible = electric
	reset_size.call_deferred()

func _update_readout(key: String, label: Label, value: float) -> void:
	if key == "mass_kg": mass_changed.emit(value)
	geometry.text = UiNumbers.display("Schwerpunktabstand v/h  %.2f / %.2f m" % [model.front_arm_m, model.rear_arm_m])
	if key in ["front_load_percent", "front_brake_percent", "pc40_front_drive_percent", "electric_front_drive_percent"]:
		label.text = "%% vorn / %.0f %% hinten" % (100 - value)
	threshold.text = UiNumbers.display("Je Achse: volles Rutschen ab %.2f g" % (model.grip_g + model.slide_band_g))

func _add_details(rows: VBoxContainer) -> void:
	var sections := {
		"Einlenkverhalten": ["yaw_inertia", "front_stiffness", "rear_stiffness"],
		"Reifenhaftung": ["grip_g", "slide_band_g", "front_residual_percent", "rear_residual_percent"],
		"Kraftverteilung": ["pc40_front_drive_percent", "electric_front_drive_percent", "front_brake_percent"],
		"Masse & Geometrie": ["mass_kg", "wheelbase_m", "front_load_percent"],
	}
	var buttons := ButtonGroup.new()
	buttons.allow_unpress = true
	for title in sections:
		var button := Button.new()
		button.text = title
		button.toggle_mode = true
		button.button_group = buttons
		rows.add_child(button)
		var content := VBoxContainer.new()
		rows.add_child(content)
		for key in sections[title]:
			slider_rows[key].reparent(content, false)
			if key == "slide_band_g": content.add_child(threshold)
		if title == "Reifenhaftung": content.add_child(axle_status)
		if title == "Masse & Geometrie": content.add_child(geometry)
		button.toggled.connect(func(open):
			content.visible = open
			reset_size.call_deferred()
			_fit.call_deferred())
		content.hide()
		button.button_pressed = title == "Einlenkverhalten"

func _process(_delta: float) -> void:
	if visible:
		var radius := "—"
		if model.speed_mps > 0.5:
			radius = "gerade" if absf(model.course_rate) < 0.001 else "%.1f m" % (model.speed_mps / absf(model.course_rate))
		axle_status.text = UiNumbers.display("Driftwinkel %.1f°   ·   Radius %s" % [rad_to_deg(model.slip_angle), radius]) + "\nRutschen   vorn %.0f %%   ·   hinten %.0f %%" % [100 * model.front_slide, 100 * model.rear_slide]
