extends "res://ui/instruments/dashboard.gd"

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
## Bottom driving instruments for speed and acceleration.

const MAX_SPEED_KMH := 300.0
const MUTED := Color(0.48, 0.62, 0.72)
const ACTIVE := Color(0.2, 0.78, 1.0)
const WARNING := Color(1.0, 0.35, 0.2)

var speed_kmh := 0.0
var longitudinal := 0.0
var steering := 0.0
var automatic := false
var grip_g := 1.3
var sliding := false
var crashed := false
var relative_altitude := 0.0
var nhn_altitude := 0.0
var height_datum := "NHN"
var altitude_reference := ""
var flying := false
var compact := false
var heading_degrees := 0.0
var flight_position := Vector3.ZERO
var flight_ground_height: Variant = null

func set_altitude(relative: float, nhn: float, reference: String, flight: bool) -> void:
	relative_altitude = relative
	nhn_altitude = nhn
	altitude_reference = reference
	flying = flight
	queue_redraw()


func set_flight_position(world_position: Vector3, ground_height: Variant, yaw: float = 0.0) -> void:
	heading_degrees = fposmod(-rad_to_deg(yaw), 360.0)
	flight_position = world_position
	flight_ground_height = ground_height
	flying = true
	queue_redraw()


func position_rows() -> Array:
	# Godot (X,Y,Z) corresponds to Blender (X,-Z,Y); no NHN offset here.
	return [
		["%.0f m" % absf(flight_position.x), "westlich" if flight_position.x < 0 else "östlich"],
		["%.0f m" % absf(flight_position.z), "nördlich" if flight_position.z < 0 else "südlich"],
		["%.0f m" % flight_position.y, "über Nullpunkt"],
		["%.0f m" % (flight_position.y - float(flight_ground_height)) if flight_ground_height != null else "—", "über Grund"],
	]


func _draw_position(x: float, width: float, small: bool) -> void:
	var font := ThemeDB.fallback_font
	var font_size := 9 if small else 14
	var center := x + width / 2
	var heading := int(round(heading_degrees)) % 360
	draw_string(font, Vector2(x, 10 if small else 18), "RICHTUNG" + (" %d°" % heading if small else ""), HORIZONTAL_ALIGNMENT_CENTER, width, 9 if small else 13, MUTED)
	var tape_y := 22.0 if small else 43.0
	var tape_width := width - 28
	# A continuous 90-degree window, including the transition through north.
	for tick in range(int(floor((heading_degrees - 45) / 5)), int(ceil((heading_degrees + 45) / 5)) + 1):
		var degrees := tick * 5
		var px := center + (degrees - heading_degrees) * tape_width / 90
		if px < x + 14 or px > x + width - 14: continue
		var cardinal := posmod(degrees, 45) == 0
		draw_line(Vector2(px, tape_y), Vector2(px, tape_y - (5 if cardinal else 2)), Color.WHITE, 1)
		if cardinal:
			var label: String = ["N", "NO", "O", "SO", "S", "SW", "W", "NW"][posmod(degrees / 45, 8)]
			draw_string(font, Vector2(px - 12, tape_y + (9 if small else 13)), label, HORIZONTAL_ALIGNMENT_CENTER, 24, 8 if small else 11, Color.WHITE)
	draw_colored_polygon(PackedVector2Array([Vector2(center - 3, tape_y - 10), Vector2(center + 3, tape_y - 10), Vector2(center, tape_y - 5)]), ACTIVE)
	if not small:
		draw_string(font, Vector2(x, 72), "%d°" % heading, HORIZONTAL_ALIGNMENT_CENTER, width, 18, ACTIVE)
	draw_line(Vector2(x + 4, 34 if small else 79), Vector2(x + width - 4, 34 if small else 79), MUTED, 1)
	draw_string(font, Vector2(x, 44 if small else 96), "POSITION", HORIZONTAL_ALIGNMENT_CENTER, width, 9 if small else 13, MUTED)
	var rows := position_rows()
	var label_width := font.get_string_size("über Nullpunkt", HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var number_width := width - label_width - 4
	for i in 4:
		var row: Array = rows[[3, 0, 1, 2][i]]
		var y := (53.0 + i * 9) if small else (117.0 + i * 19)
		draw_string(font, Vector2(x, y), row[0], HORIZONTAL_ALIGNMENT_RIGHT, number_width, font_size + (3 if i == 0 and not small else 0), ACTIVE)
		draw_string(font, Vector2(x + number_width + 4, y), row[1], HORIZONTAL_ALIGNMENT_LEFT, label_width, font_size, Color.WHITE)


func set_values(new_speed_kmh: float, new_longitudinal: float, new_steering: float, new_automatic: bool, new_crashed: bool) -> void:
	speed_kmh = new_speed_kmh
	longitudinal = new_longitudinal
	steering = new_steering
	automatic = new_automatic
	crashed = new_crashed
	queue_redraw()


func _draw() -> void:
	if compact:
		_draw_compact()
		return
	var font := ThemeDB.fallback_font
	var center := Vector2(90.0, 94.0)
	var radius := 68.0
	var start_angle := deg_to_rad(135.0)
	var sweep := deg_to_rad(270.0)
	var gauge_color := WARNING if crashed else ACTIVE

	draw_arc(center, radius, start_angle, start_angle + sweep, 64, Color(0.18, 0.28, 0.35), 8.0, true)
	draw_arc(center, radius, start_angle, start_angle + sweep * clampf(speed_kmh / MAX_SPEED_KMH, 0.0, 1.0), 64, gauge_color, 8.0, true)
	for index in 7:
		var angle := start_angle + sweep * index / 6.0
		var outer := center + Vector2(cos(angle), sin(angle)) * 61.0
		var inner := center + Vector2(cos(angle), sin(angle)) * 53.0
		draw_line(inner, outer, Color(0.8, 0.9, 0.95), 2.0, true)
		var label_position := center + Vector2(cos(angle), sin(angle)) * 44.0 + Vector2(-10.0, 5.0)
		draw_string(font, label_position, str(index * 50), HORIZONTAL_ALIGNMENT_CENTER, 20.0, 10, MUTED)
	var needle_angle := start_angle + sweep * clampf(speed_kmh / MAX_SPEED_KMH, 0.0, 1.0)
	draw_line(center, center + Vector2(cos(needle_angle), sin(needle_angle)) * 51.0, gauge_color, 3.0, true)
	draw_circle(center, 5.0, Color(0.9, 0.95, 1.0))
	draw_string(font, Vector2(58.0, 101.0), "%3.0f" % speed_kmh, HORIZONTAL_ALIGNMENT_CENTER, 74.0, 23, Color.WHITE)
	draw_string(font, Vector2(67.0, 120.0), "km/h", HORIZONTAL_ALIGNMENT_CENTER, 56.0, 12, MUTED)

	var vector_center := Vector2(285.0, 108.0)
	var grip_radius := 58.5
	var pixels_per_g := grip_radius / (5.0 if flying else grip_g)
	var vector_g := Vector2(-steering, -longitudinal)
	var magnitude := vector_g.length()
	var vector_color := WARNING if crashed or (not flying and sliding) else ACTIVE
	var mode := "AUTO" if automatic else "MANUELL"

	draw_string(font, Vector2(175.0, 20.0), "STURZVEKTOR · GEHALTEN" if crashed else "KRAFTVEKTOR", HORIZONTAL_ALIGNMENT_CENTER, 220.0, 15, Color.WHITE)
	draw_string(font, Vector2(175.0, 39.0), UiNumbers.display("%s  |a| %.2f g" % [mode, magnitude]), HORIZONTAL_ALIGNMENT_CENTER, 220.0, 12, ACTIVE if automatic else MUTED)
	draw_arc(vector_center, grip_radius, 0.0, TAU, 64, Color(0.32, 0.47, 0.55), 1.5, true)
	draw_line(vector_center + Vector2(-grip_radius, 0.0), vector_center + Vector2(grip_radius, 0.0), Color(0.25, 0.37, 0.44), 1.0, true)
	draw_line(vector_center + Vector2(0.0, -grip_radius), vector_center + Vector2(0.0, grip_radius), Color(0.25, 0.37, 0.44), 1.0, true)
	draw_circle(vector_center, 3.0, Color(0.72, 0.82, 0.88))

	var arrow_end := vector_center + vector_g * pixels_per_g
	if magnitude > 0.001:
		draw_line(vector_center, arrow_end, vector_color, 5.0, true)
		var direction := (arrow_end - vector_center).normalized()
		var perpendicular := Vector2(-direction.y, direction.x)
		var arrow_base := arrow_end - direction * minf(13.0, magnitude * pixels_per_g * 0.65)
		var arrow_head := PackedVector2Array([arrow_end, arrow_base + perpendicular * minf(7.0, magnitude * pixels_per_g * 0.35), arrow_base - perpendicular * minf(7.0, magnitude * pixels_per_g * 0.35)])
		draw_colored_polygon(arrow_head, vector_color)

	draw_string(font, Vector2(vector_center.x - 10.0, vector_center.y - grip_radius + 14.0), "G", HORIZONTAL_ALIGNMENT_CENTER, 20.0, 13, MUTED)
	draw_string(font, Vector2(vector_center.x - 10.0, vector_center.y + grip_radius + 14.0), "B", HORIZONTAL_ALIGNMENT_CENTER, 20.0, 13, MUTED)
	draw_string(font, Vector2(vector_center.x - grip_radius - 22.0, vector_center.y + 5.0), "L", HORIZONTAL_ALIGNMENT_CENTER, 20.0, 13, MUTED)
	draw_string(font, Vector2(vector_center.x + grip_radius + 2.0, vector_center.y + 5.0), "R", HORIZONTAL_ALIGNMENT_CENTER, 20.0, 13, MUTED)
	draw_string(font, Vector2(vector_center.x + 31.0, vector_center.y - grip_radius + 27.0), "5 g" if flying else UiNumbers.display("%.2f g" % grip_g), HORIZONTAL_ALIGNMENT_LEFT, 40.0, 10, MUTED)

	var altitude_x := 395.0
	if flying:
		draw_line(Vector2(390, 16), Vector2(390, 174), Color(0.25, 0.37, 0.44), 1.0)
		_draw_position(400, 190, false)
		return
	draw_line(Vector2(390, 16), Vector2(390, 174), Color(0.25, 0.37, 0.44), 1.0)
	draw_string(font, Vector2(altitude_x, 25), "HÖHE", HORIZONTAL_ALIGNMENT_CENTER, 200, 18, MUTED)
	draw_string(font, Vector2(altitude_x, 65), UiNumbers.display("%.1f m" % relative_altitude), HORIZONTAL_ALIGNMENT_CENTER, 200, 28, ACTIVE if flying else Color.WHITE)
	draw_string(font, Vector2(altitude_x, 88), altitude_reference, HORIZONTAL_ALIGNMENT_CENTER, 200, 16, MUTED)
	draw_line(Vector2(410, 103), Vector2(580, 103), Color(0.25, 0.37, 0.44), 1.0)
	draw_string(font, Vector2(altitude_x, 139), UiNumbers.display("%.1f m" % nhn_altitude), HORIZONTAL_ALIGNMENT_CENTER, 200, 27, Color.WHITE)
	draw_string(font, Vector2(altitude_x, 164), height_datum, HORIZONTAL_ALIGNMENT_CENTER, 200, 18, MUTED)

func _draw_compact() -> void:
	var font := ThemeDB.fallback_font
	var column := size.x / 3.0
	var value_color := WARNING if crashed else ACTIVE
	draw_string(font, Vector2(6, 20), "TEMPO", HORIZONTAL_ALIGNMENT_CENTER, column - 12, 14, MUTED)
	draw_string(font, Vector2(6, 48), "%.0f" % speed_kmh, HORIZONTAL_ALIGNMENT_CENTER, column - 12, 25, value_color)
	draw_string(font, Vector2(6, 70), "km/h", HORIZONTAL_ALIGNMENT_CENTER, column - 12, 14, MUTED)
	draw_string(font, Vector2(column, 20), "KRAFT", HORIZONTAL_ALIGNMENT_CENTER, column, 14, MUTED)
	draw_string(font, Vector2(column, 48), UiNumbers.display("%.2f g" % Vector2(steering, longitudinal).length()), HORIZONTAL_ALIGNMENT_CENTER, column, 20, value_color)
	draw_string(font, Vector2(column, 70), "AUTO" if automatic else "MANUELL", HORIZONTAL_ALIGNMENT_CENTER, column, 12, MUTED)
	for x in [column, column * 2]:
		draw_line(Vector2(x, 10), Vector2(x, 72), Color(0.25, 0.37, 0.44), 1)
	var height_x := column * 2 + 6
	var height_width := column - 12
	if flying:
		_draw_position(height_x, height_width, true)
		return
	draw_string(font, Vector2(height_x, 23), UiNumbers.display("%.1f m" % relative_altitude), HORIZONTAL_ALIGNMENT_CENTER, height_width, 20, ACTIVE if flying else Color.WHITE)
	var short_reference := altitude_reference.replace("Streckenminimum", "Streckenmin.")
	draw_string(font, Vector2(height_x, 43), short_reference, HORIZONTAL_ALIGNMENT_CENTER, height_width, 12, MUTED)
	draw_string(font, Vector2(height_x, 68), UiNumbers.display("%.1f m %s" % [nhn_altitude, height_datum]), HORIZONTAL_ALIGNMENT_CENTER, height_width, 16, Color.WHITE)



func instrument_size(small: bool) -> Vector2:
	compact = small
	return Vector2(420, 82) if small else Vector2(600, 190)

func refresh(vehicle: Vehicle) -> void:
	var display_force: Vector2 = vehicle.driving.crash_vector_g if vehicle.crashed else Vector2(vehicle.driving.longitudinal_strength, vehicle.driving.lateral_strength if vehicle.driving is SingleTrackModel else vehicle.driving.steering_strength)
	if vehicle.flight_mode:
		display_force = vehicle.flight.force_g
	grip_g = vehicle.driving.grip_g if vehicle.driving is SingleTrackModel else vehicle.driving.GRIP_LIMIT / vehicle.driving.GRAVITY
	var slide := maxf(vehicle.driving.front_slide, vehicle.driving.rear_slide) if vehicle.driving is SingleTrackModel else 0.0
	sliding = slide > 0.0
	height_datum = vehicle.route.height_datum
	set_values(vehicle.speed_mps * 3.6, display_force.x, display_force.y, vehicle.auto_steering, vehicle.crashed)
	if vehicle.flight_mode:
		set_flight_position(vehicle.position, vehicle.flight_ground_height, vehicle.heading_yaw)
	else:
		set_altitude(vehicle.position.y - vehicle.ground.ground_height, vehicle.position.y + vehicle.route.height_reference, "über Boden", false)
