extends PanelContainer
## Landspeeder-owned engine display; lifetime follows the vehicle view.
const ElectricDrive = preload("res://physics/electric_drive.gd")
var vehicle: Vehicle
var hud: VehicleHUD
@onready var engine_dashboard = $EngineDashboard

func _ready() -> void:
	UiLayout.bind_hud(self)
	minimum_size_changed.connect(update_layout.call_deferred)
	vehicle.presentation_finished.connect(refresh)
	vehicle.configuration_changed.connect(refresh)
	vehicle.model_status_changed.connect(refresh)
	vehicle.simulation_event.connect(_on_event)
	hud.layout_updated.connect(update_layout)
	refresh()
	update_layout.call_deferred()

func _on_event(_kind: StringName, _lap: int, _seconds: float) -> void:
	refresh()

func refresh() -> void:
	visible = not vehicle.flight_mode
	if not vehicle.ready_to_fly: return
	engine_dashboard.electric = vehicle.engine_model is ElectricDrive
	engine_dashboard.speed_kmh = vehicle.speed_mps * 3.6
	engine_dashboard.set_values(vehicle.engine_model.gear, vehicle.engine_model.rpm, vehicle.crashed, vehicle.automatic_upshift, vehicle.auto_upshift_rpm, vehicle.powertrains[0].auto_downshift_rpm)

func update_layout() -> void:
	var factor := UiLayout.factor
	var extent := UiLayout.extent
	var gauges: Control = hud.get_node("DashboardPanel")
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	engine_dashboard.compact = hud.compact_hud
	var engine_width := gauges.size.x if hud.compact_hud or vehicle.engine_model is ElectricDrive else 495.0
	engine_dashboard.custom_minimum_size = Vector2(engine_width, 64 if hud.compact_hud else 90)
	size = engine_dashboard.custom_minimum_size
	var engine_factor := factor if hud.compact_hud else factor * minf(1, (extent.x - 24) / 495.0)
	scale = Vector2.ONE * engine_factor
	position = Vector2((extent.x * factor - size.x * engine_factor) * 0.5, gauges.position.y - (size.y + 4) * engine_factor)
	engine_dashboard.queue_redraw()
