extends RefCounted
## Read the physical envelope once, including the model offset from the eye origin.
## Also available to vehicles running without a visual instance.
static var cached_bounds := AABB()
static var loaded := false

static func bounds() -> AABB:
	if loaded: return cached_bounds
	var scene = preload("res://extensions/landspeeder/landspeeder.tscn").instantiate()
	var first := true
	for mesh: MeshInstance3D in scene.find_children("*", "MeshInstance3D", true, false):
		var transform := Transform3D.IDENTITY
		var node: Node = mesh
		while node != scene:
			if node is Node3D: transform = node.transform * transform
			node = node.get_parent()
		var box: AABB = transform * mesh.get_aabb()
		cached_bounds = box if first else cached_bounds.merge(box)
		first = false
	scene.free()
	loaded = true
	return cached_bounds
