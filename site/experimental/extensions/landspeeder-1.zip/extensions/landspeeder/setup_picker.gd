extends "res://ui/dialogs/named_picker.gd"

var ground_title := ""
var flight_values := {}
var panels: Array = []
var flight_panels: Array = []
var tuning_draft := {}

func _choose_index(index: int) -> void:
	var id = choice.get_item_metadata(index)
	if id != null:
		menu.vehicles_tab.select_extension_vehicle(id)
	else:
		super(index)

func _refresh_choices() -> void:
	super()
	var vehicles: Array = menu.vehicles_tab.extension_vehicles()
	if vehicles.is_empty(): return
	choice.add_separator("Erweiterungen")
	for definition in vehicles:
		choice.add_item(definition.title)
		var index := choice.item_count - 1
		choice.set_item_metadata(index, definition.id)
		if definition.id == menu.vehicles_tab.extension_vehicle_id: choice.select(index)

func _after_name() -> void:
	ground_title = selected_setup
	menu.simulation_scene_tree.refresh()

func _replace_reference(previous: String, title: String) -> void:
	menu.simulation_scene_tree.replace_reference(previous, title)

func _remove_selected() -> void:
	var fallback: String = SimulationLibrary.vehicle_setups.SINGLE_TRACK if menu.vehicles_tab.ground_model() == 1 else SimulationLibrary.vehicle_setups.CLASSIC
	menu.simulation_scene_tree.remove_vehicle_reference(selected_setup)
	personal_draft.erase(selected_setup)
	ground_title = ""
	_choose_setup(fallback)

func driving_values(draft: Dictionary) -> Dictionary:
	return {"mode": draft.mode, "road_model": draft.road_model, "electric_drive": draft.electric_drive,
		"automatic": draft.automatic, "upshift_rpm": draft.values.upshift_rpm, "downshift_rpm": draft.values.downshift_rpm}

func capture_setup() -> Dictionary:
	var setup := driving_values(menu._draft())
	for panel in panels:
		setup[panel.section] = panel.snapshot()
	return setup

func open_panel(index: int) -> void:
	var panel = panels[index]
	panel.edit_values(tuning_draft[panel.section])
	show_drive(menu.vehicles_tab.snapshot().electric_drive)
	panel.show()

func open_flight_panel(index: int) -> void:
	var panel = flight_panels[index]
	panel.edit_values(flight_values)
	panel.show()

func restore_flight_panels(values: Dictionary) -> void:
	flight_values = values.duplicate()
	for panel in flight_panels:
		panel.editing_values = {}
		panel.apply_values(flight_values)

func _refresh_open_panels() -> void:
	for i in panels.size():
		if panels[i].visible: open_panel(i)
	for i in flight_panels.size():
		if flight_panels[i].visible: open_flight_panel(i)

func restore_panels(values: Dictionary, electric: bool) -> void:
	for panel in panels:
		panel.editing_values = {}
		panel.apply_values(values[panel.section])
	show_drive(electric)

func show_drive(electric: bool) -> void:
	if panels.is_empty(): return
	panels[0].set_electric_drive(electric)
	panels[2].set_electric_drive(electric)

func performance_setup() -> Dictionary:
	var draft: Dictionary = menu.vehicles_tab.snapshot()
	var setup := {"electric_drive": draft.electric_drive, "road_model": draft.road_model, "downshift_rpm": draft.values[&"downshift_rpm"]}
	for panel in [panels[0], panels[2]]:
		setup[panel.section] = tuning_draft[panel.section].duplicate() if menu.visible else panel.snapshot()
	return setup

func _edited_setup() -> Dictionary:
	return _ground_setup()

func _ground_setup() -> Dictionary:
	var setup := driving_values(menu._draft())
	setup.merge(tuning_draft.duplicate(true))
	return setup

func initialize_setups(tuning_panels: Array, has_saved_settings: bool) -> void:
	panels = tuning_panels
	var baseline := driving_values(menu.defaults)
	for panel in panels:
		baseline[panel.section] = panel.defaults.duplicate()
	SimulationLibrary.vehicle_setups.initialize(baseline, capture_setup(), has_saved_settings)
	builtin_names = SimulationLibrary.vehicle_setups.factory
	restore_flight_panels(SimulationLibrary.vehicle_setups.flight_values)
	begin()
	if SimulationLibrary.vehicle_setups.active.is_empty(): return
	var extension_vehicle: StringName = menu.vehicles_tab.extension_vehicle_id
	_choose_setup(SimulationLibrary.vehicle_setups.active)
	menu._apply_vehicle(menu._draft())
	menu.vehicles_tab.extension_vehicle_id = extension_vehicle
	menu.vehicles_tab._show_vehicle_selection()
	_refresh_choices()
	for panel in panels:
		panel.apply_values(tuning_draft[panel.section])

func begin() -> void:
	ground_title = SimulationLibrary.vehicle_setups.active
	flight_values = SimulationLibrary.vehicle_setups.flight_values.duplicate()
	for panel in flight_panels: flight_values.merge(panel.snapshot(), true)
	selected_setup = ground_title
	personal_draft = SimulationLibrary.vehicle_setups.personal.duplicate(true)
	for panel in panels:
		tuning_draft[panel.section] = panel.snapshot()
	_refresh_choices()

func _choose_setup(title: String) -> void:
	menu.vehicles_tab.extension_vehicle_id = &""
	if not menu.original.is_empty() and not ground_title.is_empty() and ground_title != title:
		_store_current()
	selected_setup = title
	var setup: Dictionary = SimulationLibrary.vehicle_setups.factory.get(title, personal_draft.get(title, {}))
	ground_title = title
	var draft: Dictionary = menu._draft()
	for key in ["mode", "road_model", "electric_drive", "automatic"]:
		draft[key] = setup[key]
	for key in ["upshift_rpm", "downshift_rpm"]:
		draft.values[key] = setup[key]
	draft.profiles[int(draft.road_model)] = int(draft.mode)
	for panel in panels:
		tuning_draft[panel.section] = setup[panel.section].duplicate()
	show_drive(draft.electric_drive)
	menu._restore_model_selection(draft)
	menu.set_values(draft.values, draft.automatic, draft.mode)
	_refresh_open_panels()
	_refresh_choices()
	menu.simulation_scene_tree.refresh()

func apply(persist: bool, stay_open: bool) -> void:
	if panels.is_empty(): return
	_store_current()
	selected_setup = ground_title
	_refresh_choices()
	menu.simulation_scene_tree.refresh()
	restore_panels(tuning_draft, menu.vehicles_tab.snapshot().electric_drive)
	restore_flight_panels(flight_values)
	if stay_open: _refresh_open_panels()
	SimulationLibrary.vehicle_setups.active = ground_title
	SimulationLibrary.vehicle_setups.flight_values = flight_values.duplicate()
	menu.vehicle.flight.limits.merge(flight_values, true)
	menu.vehicle.gamepad.flight_settings.merge(flight_values, true)
	SimulationLibrary.vehicle_setups.personal = personal_draft.duplicate(true)
	if persist:
		SimulationLibrary.vehicle_setups.persist()
		SimulationLibrary.vehicle_setups.persist_flight()


func _store_setup(title: String, values: Dictionary) -> String:
	if SimulationLibrary.vehicle_setups.factory.has(title):
		if SimulationLibrary.vehicle_setups.recursive_equal_approx(SimulationLibrary.vehicle_setups.factory[title], values): return title
		var base := title + " · Persönlich"
		title = base
		var number := 2
		while personal_draft.has(title):
			title = "%s (%d)" % [base, number]
			number += 1
	personal_draft[title] = values.duplicate(true)
	return title


func snapshot() -> Dictionary:
	return {"ground": ground_title, "flight_values": flight_values, "personal": personal_draft, "tuning": tuning_draft}

func setup_changed() -> bool:
	var saved: Dictionary = SimulationLibrary.vehicle_setups.factory.get(selected_setup, personal_draft.get(selected_setup, {}))
	return not SimulationLibrary.vehicle_setups.recursive_equal_approx(saved, _edited_setup())

func _store_current() -> void:
	var previous := ground_title
	ground_title = _store_setup(ground_title, _ground_setup())
	if ground_title != previous and menu.simulation_scene_tree.current and menu.simulation_scene_tree.current.vehicle_id == SimulationLibrary.vehicle_id(previous):
		menu.simulation_scene_tree.current.vehicle_id = SimulationLibrary.vehicle_id(ground_title)

func restore(saved: Dictionary, draft: Dictionary) -> void:
	restore_panels(saved.tuning, draft.electric_drive)
	begin()
	restore_flight_panels(saved.flight_values)
