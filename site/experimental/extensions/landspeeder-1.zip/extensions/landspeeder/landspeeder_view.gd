extends VehicleView
var engine_panel: PanelContainer

func _ready() -> void:
	_add_instruments.call_deferred()

func _add_instruments() -> void:
	if not is_inside_tree() or is_queued_for_deletion(): return
	# Remote riders reuse the visual scene without a local vehicle or HUD.
	if not get_parent() is Vehicle: return
	engine_panel = preload("engine_panel.tscn").instantiate()
	engine_panel.vehicle = get_parent()
	engine_panel.hud = get_parent().get_node("HUD")
	var hud = engine_panel.hud
	hud.add_child(engine_panel)
	hud.move_child(engine_panel, hud.game_help.get_index())
	visibility_changed.connect(func(): engine_panel.visible = visible and not get_parent().flight_mode)

func _exit_tree() -> void:
	if is_instance_valid(engine_panel): engine_panel.free()
