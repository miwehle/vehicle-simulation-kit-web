extends "res://ui/dialogs/tuning_panel.gd"

const PerformanceRun := preload("res://extensions/landspeeder/performance_run.gd")
const PARAMETERS := [
	["traction_n", "Maximale Zugkraft", 500, 4000, 0, "%.0f N"],
	["base_speed_kmh", "Konstante Leistung ab", 40, 180, 1, "%.0f km/h"],
	["pc40_peak_ps", "Spitzenleistung am Rad", 50, 180, 1, "%.0f PS"],
]
var pc40
var electric_drive
var picker
var electric := false
var peak := Label.new()
var status := Label.new()
var results := Label.new()
var calculate := Button.new()
var run: PerformanceRun
var requested_setup := {}
var result_setup := {}
var refresh_in := 0.0

func _parameter_target(key: String):
	return pc40 if key == "pc40_peak_ps" else electric_drive

func _ready() -> void:
	save_path = "user://powertrain.cfg"
	section = "powertrain"
	build_panel("Parameter des Antriebsmodells", PARAMETERS, Vector2(36, 96))
	set_electric_drive(false)
	visibility_changed.connect(func():
		refresh_in = 0.0
		if not visible: run = null)

func set_electric_drive(value: bool) -> void:
	electric = value
	slider_rows.traction_n.visible = electric
	slider_rows.base_speed_kmh.visible = electric
	slider_rows.pc40_peak_ps.visible = not electric
	_update_power()
	reset_size.call_deferred()

func _update_readout(_key: String, _label: Label, _value: float) -> void:
	_update_power()

func _update_power() -> void:
	var kw: float = electric_drive.traction_n * electric_drive.base_speed_kmh / 3600.0 if electric else pc40.pc40_peak_ps * 0.73549875
	peak.text = UiNumbers.display("Spitzenleistung am Rad: %.1f kW / %.1f PS" % [kw, kw / 0.73549875])

func _add_details(rows: VBoxContainer) -> void:
	var heading := Label.new()
	heading.text = "Berechnete Fahrleistungen"
	rows.add_child(heading)
	rows.add_child(peak)
	calculate.text = "Fahrleistungen berechnen"
	rows.add_child(calculate)
	calculate.pressed.connect(func():
		requested_setup = picker.performance_setup()
		run = PerformanceRun.new(requested_setup))
	rows.add_child(status)
	rows.add_child(results)

func _process(delta: float) -> void:
	if not visible: return
	refresh_in -= delta
	if run == null and refresh_in > 0: return
	refresh_in = 0.1
	var current: Dictionary = picker.performance_setup()
	if run and current != requested_setup: run = null
	calculate.disabled = run != null
	if run:
		status.show()
		status.text = "Wird berechnet …"
		var deadline := Time.get_ticks_usec() + 1500
		while not run.finished and Time.get_ticks_usec() < deadline:
			run.advance()
		if not run.finished: return
		if run.converged:
			results.text = UiNumbers.display("Höchstgeschwindigkeit: %.1f km/h\n0–100 km/h: %s\n100–200 km/h: %s" % [
				run.top_kmh, _time_text(run.time_100), _time_text(run.time_200 - run.time_100 if run.time_200 >= 0 else -1.0)])
		else:
			results.text = "Testfahrt ohne stabiles Endtempo beendet."
		result_setup = requested_setup
		run = null
		calculate.disabled = false
	status.text = "Setup geändert" if not result_setup.is_empty() and current != result_setup else ""
	status.visible = not status.text.is_empty()
	results.visible = not results.text.is_empty()

func _time_text(seconds: float) -> String:
	return "%.2f s" % seconds if seconds >= 0 else "nicht erreichbar"
