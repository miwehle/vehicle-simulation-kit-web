// Browser picker streams chunks into Godot's persistent user filesystem.
window.VeskiPackageFile = {
    // Godot uses IDBFS at /userfs. Confirm each small file before writing the next.
    // One transaction containing the whole landscape fails in Chrome (InvalidBlob).
    beginSave() { this.saveStartedAt = Date.now(); },
    async waitForSaved(path, bytes) {
        this.saving = true; this.saveError = '';
        try {
            const db = await new Promise((resolve, reject) => {
                const request = indexedDB.open('/userfs');
                request.onsuccess = () => resolve(request.result);
                request.onerror = () => reject(request.error);
            });
            try {
                const deadline = Date.now() + 30000;
                while (true) {
                    const entry = await new Promise((resolve, reject) => {
                        const request = db.transaction('FILE_DATA').objectStore('FILE_DATA').get(path);
                        request.onsuccess = () => resolve(request.result);
                        request.onerror = () => reject(request.error);
                    });
                    if (entry?.contents?.length === bytes && new Date(entry.timestamp).getTime() >= this.saveStartedAt) break;
                    if (Date.now() > deadline) throw new Error('Browserspeicherung konnte nicht bestätigt werden.');
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            } finally { db.close(); }
        } catch (error) { this.saveError = error.message; }
        this.saving = false;
    },
    async choose(callback) {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = '.zip';
        input.addEventListener('cancel', () => callback('cancel'));
        input.addEventListener('change', async () => {
            const file = input.files[0];
            if (!file) return callback('cancel');
            try {
                const storage = await navigator.storage?.estimate();
                if (storage && storage.quota - storage.usage < file.size * 1.2)
                    throw new Error('Nicht genügend freier Browserspeicher für dieses Paket.');
                await navigator.storage?.persist();
                callback('start', file.size);
                if (!this.accepted) return;
                for (let offset = 0; offset < file.size; offset += 1024 * 1024) {
                    const chunk = await file.slice(offset, offset + 1024 * 1024).arrayBuffer();
                    callback('chunk', chunk);
                    if (!this.accepted) return;
                    await new Promise(resolve => setTimeout(resolve, 0));
                }
                callback('done');
            } catch (error) { callback('error', error.message); }
        }, {once: true});
        input.click();
    }
};
