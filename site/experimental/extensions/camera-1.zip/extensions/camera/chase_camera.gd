extends RefCounted
## Camera pose relative to horizontal heading or the complete vehicle attitude.
const SETTINGS := "user://chase-camera.cfg"
var offset := Vector3.ZERO
var angles := Vector2.ZERO # yaw, pitch in degrees
var interior_mode := false
var _before_interior_mode := false
var follow_yaw := true
var follow_pitch := false
var follow_roll := false
var roll := 0.0
var _orientation := Quaternion.IDENTITY
var _orientation_angles := Vector3(INF, INF, INF)
var _before_follow := Vector3.ONE
var _before_roll := 0.0
# Compatibility with the existing settings.
var follow_attitude: bool:
	get: return follow_pitch and follow_roll
	set(value):
		follow_pitch = value
		follow_roll = value
var editing := false
var _key := "@unconfigured"
var _before_offset := Vector3.ZERO
var _before_angles := Vector2.ZERO
var views: Array[Dictionary] = [{}, {}]
var view_index := 0
var _before_view_index := 0
const POSE_FIELDS := ["offset", "angles", "roll", "follow_yaw", "follow_pitch", "follow_roll", "interior_mode"]

func configure(default_offset: Vector3, key: String, default_pitch := NAN, pilot_offset := Vector3.ZERO, pilot_pitch := -7.0) -> void:
	if key == _key: return
	_key = key
	interior_mode = false
	follow_attitude = false
	follow_yaw = true
	roll = 0.0
	offset = default_offset
	var direction := Vector3.UP - offset
	angles = Vector2(rad_to_deg(atan2(-direction.x, -direction.z)), rad_to_deg(atan2(direction.y, Vector2(direction.x, direction.z).length())))
	if is_finite(default_pitch): angles.y = default_pitch
	views = [{"offset": pilot_offset, "angles": Vector2(0, pilot_pitch), "roll": 0.0,
		"follow_yaw": true, "follow_pitch": true, "follow_roll": true, "interior_mode": true}, {}]
	view_index = 0 if default_offset == Vector3.ZERO else 1
	if view_index == 0: restore_pose(views[0])
	else: views[1] = pose()
	var settings := ConfigFile.new()
	if settings.load(SETTINGS) == OK:
		var saved_interior: Variant = settings.get_value(key, "interior_mode", interior_mode)
		if saved_interior is bool: interior_mode = saved_interior
		var saved_follow: Variant = settings.get_value(key, "follow_attitude", follow_attitude)
		if saved_follow is bool: follow_attitude = saved_follow
		for property in ["follow_yaw", "follow_pitch", "follow_roll"]:
			var value: Variant = settings.get_value(key, property, get(property))
			if value is bool: set(property, value)
		var saved_roll: Variant = settings.get_value(key, "roll", 0.0)
		if (saved_roll is float or saved_roll is int) and is_finite(saved_roll): roll = saved_roll
		var saved_offset: Variant = settings.get_value(key, "offset", offset)
		var saved_angles: Variant = settings.get_value(key, "angles", angles)
		if saved_offset is Vector3 and saved_offset.is_finite(): offset = saved_offset
		if saved_angles is Vector2 and saved_angles.is_finite(): angles = saved_angles
		# Legacy settings retain their exact pose; new named views are per vehicle.
		view_index = int(settings.get_value(key, "view_index", 0 if follow_attitude else 1))
		view_index = clampi(view_index, 0, 1)
		# Vehicle defaults are immutable. Only a vehicle without an exterior
		# default may restore the exterior first defined by its user.
		if views[1].is_empty():
			var saved: Variant = settings.get_value(key, "view_1", {})
			if saved is Dictionary and valid_pose(saved): views[1] = saved
	angles.y = clampf(angles.y, -90, 90)

func begin() -> void:
	_before_view_index = view_index
	_before_interior_mode = interior_mode
	_before_follow = Vector3(float(follow_yaw), float(follow_pitch), float(follow_roll))
	_before_roll = roll
	_before_offset = offset
	_before_angles = angles
	editing = true

func finish(accept: bool) -> void:
	if not editing: return
	editing = false
	if not accept:
		view_index = _before_view_index
		interior_mode = _before_interior_mode
		follow_yaw = bool(_before_follow.x)
		follow_pitch = bool(_before_follow.y)
		follow_roll = bool(_before_follow.z)
		roll = _before_roll
		offset = _before_offset
		angles = _before_angles
		return
	if views[view_index].is_empty(): views[view_index] = pose()
	save()

func save() -> void:
	var settings := ConfigFile.new()
	settings.load(SETTINGS)
	for property in ["follow_yaw", "follow_pitch", "follow_roll", "roll"]:
		settings.set_value(_key, property, get(property))
	settings.set_value(_key, "interior_mode", interior_mode)
	settings.set_value(_key, "follow_attitude", follow_attitude)
	settings.set_value(_key, "offset", offset)
	settings.set_value(_key, "angles", angles)
	settings.set_value(_key, "view_index", view_index)
	for index in 2: settings.set_value(_key, "view_" + str(index), views[index])
	settings.save(SETTINGS)

func apply(camera: Camera3D, origin: Vector3, frame: Basis) -> void:
	camera.global_transform = Transform3D(frame * orientation_basis(), origin + frame * offset)

func following_basis(attitude: Basis, heading: float) -> Basis:
	if follow_yaw and follow_pitch and follow_roll: return attitude.orthonormalized()
	var rotation := attitude.orthonormalized().get_euler()
	return Basis.from_euler(Vector3(rotation.x if follow_pitch else 0.0,
		heading if follow_yaw else 0.0, rotation.z if follow_roll else 0.0))

func orientation_basis() -> Basis:
	var values := Vector3(angles.y, angles.x, roll)
	# Numeric fields and presets write Euler angles.
	if values != _orientation_angles:
		_orientation = Quaternion.from_euler(values * PI / 180.0)
		_orientation_angles = values
	return Basis(_orientation)

func move_controls_free(left: Vector2, right: Vector2, vertical: float, delta: float, rolling: float) -> void:
	if not editing: return
	if interior_mode: delta *= 0.1
	orientation_basis()
	var rotation := Vector3(-right.y, -right.x, -rolling) * deg_to_rad(75) * delta
	if not rotation.is_zero_approx():
		# Post-multiply: all three inputs turn around the current camera axes.
		_orientation = (_orientation * Quaternion(rotation.normalized(), rotation.length())).normalized()
		var euler := Basis(_orientation).get_euler() * 180.0 / PI
		angles = Vector2(euler.y, euler.x)
		roll = euler.z
		_orientation_angles = Vector3(angles.y, angles.x, roll)
	# Keep translations independent of the Euler branch change at the poles.
	offset += Basis(_orientation) * Vector3(left.x, 0, left.y) * 10 * delta
	offset.y += vertical * 10 * delta
	offset = offset.limit_length(300)

func pose() -> Dictionary:
	var result := {}
	for property in POSE_FIELDS: result[property] = get(property)
	return result

func restore_pose(value: Dictionary) -> void:
	for property in POSE_FIELDS: set(property, value[property])

func valid_pose(value: Dictionary) -> bool:
	for property in POSE_FIELDS:
		if not value.has(property) or typeof(value[property]) != typeof(get(property)): return false
	return value.offset.is_finite() and value.angles.is_finite() and is_finite(value.roll)

## False means this vehicle has no exterior view yet; keep the current pose for editing.
func select_view(index: int) -> bool:
	view_index = index
	if views[index].is_empty(): return false
	restore_pose(views[index])
	return true

func matches_view(index: int) -> bool:
	return pose() == views[index]
