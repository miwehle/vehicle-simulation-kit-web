extends PanelContainer
## Non-modal camera editor. Settings/help remain independent of flight pause.
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
var vehicle: Vehicle
var menu
var rig
var numbers: Array[Dictionary] = []
var cancel_button: Button
var _releasing := false
var _owns_edit := false

var control_target: Array[Button] = []
var _gamepad_camera := false
var follows: Array[CheckBox] = []
var sensitivity: Array[Button] = []
var views: Array[Button]
var accept_button: Button
var _dragging := false
var _drag_offset := Vector2.ZERO
var _moved := false


func _ready() -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.06, 0.09, 0.92)
	style.set_content_margin_all(12)
	add_theme_stylebox_override("panel", style)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 10)
	add_child(rows)
	_build_controls(rows)
	vehicle.simulation_event.connect(_simulation_event)
	vehicle.model_status_changed.connect(_check_available)
	UiLayout.changed.connect(_place)
	minimum_size_changed.connect(_place.call_deferred)
	UiLayout.bind_hud(self)
	_refresh()
	_place()
	hide()

func _build_controls(rows: VBoxContainer) -> void:
	rows.add_theme_constant_override("separation", 5)
	var header := preload("res://ui/controls/window_header.gd").new("Kamera", close, func(): finish(true))
	header.close_button.tooltip_text = "Schließen; offene Änderungen verwerfen"
	accept_button = header.apply_button
	accept_button.tooltip_text = "Übernehmen"
	cancel_button = Button.new()
	cancel_button.icon = preload("res://ui/icons/undo_icon.svg")
	cancel_button.tooltip_text = "Änderungen verwerfen"
	cancel_button.custom_minimum_size = Vector2(48, 48)
	cancel_button.focus_mode = Control.FOCUS_NONE
	cancel_button.pressed.connect(func(): finish(false))
	header.add_child(cancel_button)
	header.move_child(cancel_button, 2)
	rows.add_child(header)
	header.add_theme_constant_override("separation", 6)
	for button in [accept_button, cancel_button, header.close_button]:
		button.custom_minimum_size = Vector2(32, 32)
		button.add_theme_constant_override("icon_max_width", 24)
		button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.gui_input.connect(_drag_header)
	_heading(rows, "Gamepad steuert")
	control_target = _choices(rows, ["Fahrzeug", "Kamera"], _select_control_target)
	for i in control_target.size():
		var style: StyleBoxFlat = control_target[i].get_theme_stylebox("pressed").duplicate()
		style.bg_color = Color(0.08, 0.4, 0.2, 0.95) if i == 0 else Color(0.65, 0.28, 0.04, 0.95)
		control_target[i].add_theme_stylebox_override("pressed", style)
	_heading(rows, "Position")
	for title in ["Rechts", "Oben", "Hinten"]: _add_number(rows, title, "m", -300, 300)
	_heading(rows, "Orientierung")
	_add_number(rows, "Gier", "°", -180, 180)
	_add_number(rows, "Nick", "°", -90, 90)
	_add_number(rows, "Roll", "°", -180, 180)
	_heading(rows, "Mitbewegen")
	var follow_row := HBoxContainer.new()
	rows.add_child(follow_row)
	for item in [["Gieren", "follow_yaw"], ["Nicken", "follow_pitch"], ["Rollen", "follow_roll"]]:
		var check := CheckBox.new()
		check.text = item[0]
		check.focus_mode = Control.FOCUS_NONE
		check.toggled.connect(func(enabled): _follow(item[1], enabled))
		follow_row.add_child(check)
		follows.append(check)
	_heading(rows, "Einstellung")
	sensitivity = _choices(rows, ["Fein", "Grob"], _sensitivity)
	_heading(rows, "Ansicht")
	views = _choices(rows, ["Pilot", "Außen"], _view)

func _add_number(rows: VBoxContainer, title: String, unit: String, minimum: float, maximum: float) -> void:
	var row := HBoxContainer.new()
	rows.add_child(row)
	var label := Label.new()
	label.text = title
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(label)
	var field := LineEdit.new()
	field.custom_minimum_size.x = 92
	field.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(field)
	var suffix := Label.new()
	suffix.text = unit
	suffix.custom_minimum_size.x = 20
	row.add_child(suffix)
	var source := Range.new()
	source.min_value = minimum
	source.max_value = maximum
	source.step = 0.01 if unit == "m" else 0.1
	row.add_child(source)
	source.hide()
	var refresh := UiNumbers.bind_field(field, source, "%.2f" if unit == "m" else "%.1f", rows)
	source.value_changed.connect(_set_number.bind(numbers.size()))
	field.focus_entered.connect(begin)
	numbers.append({"field": field, "source": source, "refresh": refresh})

func _set_number(value: float, index: int) -> void:
	if not rig.editing: return
	if index < 3:
		rig.offset[index] = value
		rig.offset = rig.offset.limit_length(300)
	elif index == 5:
		rig.roll = -value
	else:
		rig.angles[index - 3] = -value if index == 3 else value
	vehicle.update_camera()
	_refresh()

func _number_has_focus() -> bool:
	return numbers.any(func(number): return number.field.has_focus())

func available() -> bool:
	return vehicle.camera != null and vehicle.vehicle_view != null

func toggle() -> void:
	if visible: close()
	elif available():
		vehicle.update_camera()
		_refresh()
		get_parent().move_child(self, get_parent().game_help.get_index() - 1)
		show()

func close() -> void:
	finish(false)
	hide()

func begin() -> void:
	if not available() or rig.editing or menu.visible or vehicle.get_node("HUD").game_help.overlay.visible: return
	vehicle.update_camera()
	_releasing = false
	# Fold the existing look-key orbit into the editable relative pose.
	rig.offset = Basis(Vector3.UP, deg_to_rad(vehicle.vehicle_camera.look_yaw)) * rig.offset
	rig.angles.x += vehicle.vehicle_camera.look_yaw
	vehicle.vehicle_camera.look_yaw = 0
	if vehicle.vehicle_view.chase_offset == Vector3.ZERO:
		rig.angles.y += vehicle.vehicle_camera.look_pitch - vehicle.vehicle_camera.DEFAULT_PITCH
		vehicle.vehicle_camera.look_pitch = vehicle.vehicle_camera.DEFAULT_PITCH
	rig.begin()
	_owns_edit = true
	_refresh()

func finish(accept: bool, _restore_pause := true) -> void:
	_gamepad_camera = false
	if not _owns_edit: return
	_owns_edit = false
	for number in numbers:
		if number.field.has_focus():
			if not accept: number.refresh.call(number.source.value)
			number.field.release_focus()
	rig.finish(accept)
	_releasing = vehicle.controls_captured
	if _releasing:
		vehicle.keyboard_controls.clear_motion()
		vehicle.flight_keyboard.clear_motion()
		vehicle.gamepad.clear_motion()
	vehicle.update_camera()
	_refresh()

func _simulation_event(kind: StringName, _lap: int, _seconds: float) -> void:
	if kind == &"focus_out" and _owns_edit:
		finish(false, false)
		menu.pause_scene()
	elif kind == &"pause" and not menu._scene_transport_event:
		finish(false, false)

func _check_available() -> void:
	if not available() or (vehicle.registered_model and not vehicle.registered_model.model_ready):
		finish(false, false)
		hide()

func _move_camera(left: Vector2, right: Vector2, vertical: float, delta: float, rolling: float) -> void:
	rig.move_controls_free(left, right, vertical, delta, rolling)

func _key(code: Key) -> float:
	return 1.0 if Input.is_physical_key_pressed(code) else 0.0

func handle_input(event: InputEvent) -> bool:
	if not _gamepad_camera and not _releasing: return false
	if not _owns_edit and not _releasing: return false
	if event is InputEventJoypadMotion: return true
	if event is InputEventJoypadButton:
		if event.pressed and rig.editing:
			if event.button_index == JOY_BUTTON_START:
				finish(false, false)
				menu._show_settings()
		return true
	if event is InputEventKey:
		# Let LineEdit handle text, cursor keys, Enter and Esc through UiNumbers.
		if _number_has_focus(): return false
		if event.pressed and not event.echo and rig.editing:
			match event.keycode:
				KEY_ENTER: finish(true)
				KEY_ESCAPE: finish(false)
				KEY_P: menu._show_settings()
				KEY_F1: menu._show_help()
		return true
	return false

func _refresh() -> void:
	var values := [rig.offset.x, rig.offset.y, rig.offset.z, -rig.angles.x, rig.angles.y, -rig.roll]
	for i in numbers.size():
		var number := numbers[i]
		if not number.field.has_focus():
			number.source.set_value_no_signal(values[i])
			number.refresh.call(number.source.value)
	for i in follows.size(): follows[i].set_pressed_no_signal([rig.follow_yaw, rig.follow_pitch, rig.follow_roll][i])
	sensitivity[0].set_pressed_no_signal(rig.interior_mode)
	sensitivity[1].set_pressed_no_signal(not rig.interior_mode)
	# Highlight a preset only while the complete pose still matches it.
	for i in views.size():
		views[i].set_pressed_no_signal(rig.matches_view(i))
	control_target[0].set_pressed_no_signal(not _gamepad_camera)
	control_target[1].set_pressed_no_signal(_gamepad_camera)
	accept_button.visible = _owns_edit
	cancel_button.visible = _owns_edit
	size.y = 0

func _place() -> void:
	var previous := position
	var room := (UiLayout.extent - Vector2(24, 24)).max(Vector2.ONE)
	var fit := minf(1, minf(room.x / maxf(1, size.x), room.y / maxf(1, size.y)))
	scale = Vector2.ONE * UiLayout.factor * fit
	position = Vector2(12, maxf(12, UiLayout.extent.y - size.y * fit - 16)) * UiLayout.factor
	if _moved:
		position = previous.clamp(Vector2.ZERO, (get_viewport_rect().size - size * scale).max(Vector2.ZERO))

func _process_controls(delta: float) -> void:
	if rig.editing and not _owns_edit: return
	if not _owns_edit and not _releasing: return
	if not vehicle.has_focus or _number_has_focus(): return
	var left := Vector2.ZERO
	var right := Vector2.ZERO
	var vertical := 0.0
	var rolling := 0.0
	var pads := Input.get_connected_joypads()
	var held_button := false
	if not pads.is_empty():
		var pad: int = pads[0]
		rolling = float(Input.is_joy_button_pressed(pad, JOY_BUTTON_RIGHT_SHOULDER)) - float(Input.is_joy_button_pressed(pad, JOY_BUTTON_LEFT_SHOULDER))
		left = GamepadController.stick(Vector2(Input.get_joy_axis(pad, JOY_AXIS_LEFT_X), Input.get_joy_axis(pad, JOY_AXIS_LEFT_Y)), 0.08)
		right = GamepadController.stick(Vector2(Input.get_joy_axis(pad, JOY_AXIS_RIGHT_X), Input.get_joy_axis(pad, JOY_AXIS_RIGHT_Y)), 0.08)
		vertical = Input.get_joy_axis(pad, JOY_AXIS_TRIGGER_RIGHT) - Input.get_joy_axis(pad, JOY_AXIS_TRIGGER_LEFT)
		if absf(vertical) < 0.05: vertical = 0
		held_button = Input.is_joy_button_pressed(pad, JOY_BUTTON_A) or Input.is_joy_button_pressed(pad, JOY_BUTTON_B) or Input.get_joy_axis(pad, JOY_AXIS_TRIGGER_RIGHT) > 0.05 or Input.get_joy_axis(pad, JOY_AXIS_TRIGGER_LEFT) > 0.05
	left += Vector2(_key(KEY_D) - _key(KEY_A), _key(KEY_S) - _key(KEY_W))
	right += Vector2(_key(KEY_RIGHT) - _key(KEY_LEFT), _key(KEY_DOWN) - _key(KEY_UP))
	vertical += _key(KEY_E) - _key(KEY_Q)
	if _releasing:
		if left.is_zero_approx() and right.is_zero_approx() and is_zero_approx(vertical) and not held_button and is_zero_approx(rolling):
			_releasing = false
			vehicle.controls_captured = false
		return
	_move_camera(left.limit_length(), right.limit_length(), clampf(vertical, -1, 1), minf(delta, 0.1), rolling)
	vehicle.update_camera()
	_refresh()

func _heading(rows: VBoxContainer, text: String) -> void:
	var label := Label.new()
	label.text = text
	label.add_theme_color_override("font_color", Color(0.2, 0.75, 0.95))
	rows.add_child(label)

func _choices(rows: VBoxContainer, titles: Array, action: Callable) -> Array[Button]:
	var row := HBoxContainer.new()
	rows.add_child(row)
	var result: Array[Button] = []
	for index in titles.size():
		var button := Button.new()
		button.text = titles[index]
		button.toggle_mode = true
		var selected := StyleBoxFlat.new()
		selected.bg_color = Color(0.08, 0.36, 0.5, 0.9)
		selected.set_content_margin_all(6)
		button.add_theme_stylebox_override("pressed", selected)
		button.focus_mode = Control.FOCUS_NONE
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.pressed.connect(action.bind(index))
		row.add_child(button)
		result.append(button)
	return result

func _follow(property: String, enabled: bool) -> void:
	begin()
	if not _owns_edit: return
	rig.set(property, enabled)
	vehicle.update_camera()
	_refresh()

func _sensitivity(index: int) -> void:
	begin()
	if not _owns_edit: return
	rig.interior_mode = index == 0
	_refresh()

func _view(index: int) -> void:
	begin()
	if not _owns_edit: return
	if not rig.select_view(index): _select_control_target(1)
	vehicle.update_camera()
	_refresh()

func _select_control_target(index: int) -> void:
	if index == 1:
		begin()
		if not _owns_edit: return
	_gamepad_camera = index == 1
	_releasing = false
	vehicle.controls_captured = _gamepad_camera
	vehicle.keyboard_controls.clear_motion()
	vehicle.flight_keyboard.clear_motion()
	vehicle.gamepad.clear_motion()
	vehicle.vehicle_camera.clear_input()
	_refresh()

func _process(delta: float) -> void:
	if _gamepad_camera or _releasing: _process_controls(delta)
	if visible: _refresh()

func _drag_header(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_dragging = event.pressed
		if _dragging: _drag_offset = get_global_mouse_position() - position
		accept_event()
	elif event is InputEventMouseMotion and _dragging:
		_moved = true
		position = get_global_mouse_position() - _drag_offset
		_place()
		accept_event()
