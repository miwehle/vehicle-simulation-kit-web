extends Extension
## Optional camera editor, independent of the active vehicle's model.
var vehicle: Vehicle
var rig = preload("chase_camera.gd").new()
var panel = preload("camera_panel.gd").new()
var button = preload("res://ui/controls/navigation_button.gd").new()
var _registered := false
var _view_key := "@unconfigured"

func register() -> void:
	vehicle = get_parent().get_node("Player")
	var hud := vehicle.get_node("HUD")
	panel.name = "CameraPanel"
	panel.vehicle = vehicle
	panel.menu = hud.get_node("SettingsMenu")
	panel.rig = rig
	_configure()
	if not extension_manager.set_camera_update(self, update_camera, vehicle):
		panel.free()
		button.free()
		return
	if not extension_manager.set_input_handler(self, panel.handle_input, vehicle):
		extension_manager.unregister(self)
		panel.free()
		button.free()
		return
	_registered = true
	extension_manager.add_hud_control(self, panel)
	button.icon = preload("res://ui/icons/camera_icon.svg")
	button.tooltip_text = "Kamera"
	button.activated.connect(panel.toggle)
	extension_manager.add_hud_toolbar_button(self, button)
	observe(panel.menu.interaction_requested, panel.close)
	observe(panel.menu.visibility_changed, _menu_visibility)
	vehicle.update_camera()

func _menu_visibility() -> void:
	if panel.menu.visible: panel.close()

func _configure() -> void:
	var view := vehicle.vehicle_view
	if view == null: return
	var key: String = view.camera_settings_key if not view.camera_settings_key.is_empty() else view.scene_file_path
	if key == _view_key: return
	_view_key = key
	if panel.is_inside_tree(): panel.close()
	vehicle.controls_captured = false
	rig.configure(view.chase_offset, key, view.chase_pitch, view.pilot_offset, view.pilot_pitch)

func update_camera() -> bool:
	if vehicle.vehicle_view == null: return false
	_configure()
	var frame: Basis = rig.following_basis(vehicle.vehicle_view.global_basis, vehicle.heading_yaw)
	rig.apply(vehicle.camera, vehicle.global_position, frame * Basis(Vector3.UP, deg_to_rad(vehicle.vehicle_camera.look_yaw)))
	if vehicle.vehicle_view.chase_offset == Vector3.ZERO:
		vehicle.camera.rotate_object_local(Vector3.RIGHT, deg_to_rad(vehicle.vehicle_camera.look_pitch - vehicle.vehicle_camera.DEFAULT_PITCH))
	return true

func cleanup() -> void:
	if not _registered: return
	if is_instance_valid(panel) and panel.is_inside_tree(): panel.close()
	if not is_instance_valid(vehicle): return
	vehicle.controls_captured = false
	vehicle._reset_controls()
	# Unregister before restoring the ordinary camera; it must not call us again.
	extension_manager.unregister(self)
	if vehicle.is_inside_tree(): vehicle.update_camera()
	if vehicle.camera: vehicle.camera.reset_physics_interpolation()
