extends RefCounted
## One nonblocking pipe for the session. Windows owns the four motor channels.
const COMMAND := r"""
$ErrorActionPreference = 'Stop'
Add-Type -Namespace Grip -Name Hid -MemberDefinition @"
[DllImport("cfgmgr32.dll", CharSet=CharSet.Unicode)] public static extern int CM_Get_Device_Interface_List_SizeW(out int n, ref Guid g, string id, int flags);
[DllImport("cfgmgr32.dll", CharSet=CharSet.Unicode)] public static extern int CM_Get_Device_Interface_ListW(ref Guid g, string id, [Out] char[] list, int n, int flags);
[DllImport("kernel32.dll", CharSet=CharSet.Unicode,SetLastError=true)] public static extern Microsoft.Win32.SafeHandles.SafeFileHandle CreateFileW(string path, uint access, uint share, IntPtr security, uint mode, uint flags, IntPtr template);
"@
function Open-XboxHid {
    $guid=[Guid]'4d1e55b2-f16f-11cf-88cb-001111000030'
    $n=0
    if ([Grip.Hid]::CM_Get_Device_Interface_List_SizeW([ref]$n,[ref]$guid,$null,0) -ne 0) { return }
    $list=New-Object char[] $n
    if ([Grip.Hid]::CM_Get_Device_Interface_ListW([ref]$guid,$null,$list,$n,0) -ne 0) { return }
    $paths=@((-join $list).Split([char]0) | Where-Object { $_ -match '00001812-0000-1000-8000-00805f9b34fb.*VID_045e&PID_0b13&' })
    if ($paths.Count -ne 1) { return }
    $handle=[Grip.Hid]::CreateFileW($paths[0],1073741824,3,[IntPtr]::Zero,3,0,[IntPtr]::Zero)
    if ($handle.IsInvalid) { $handle.Dispose(); return }
    return [IO.FileStream]::new($handle,[IO.FileAccess]::Write,9)
}
function Send-Rumble($stream, [byte]$left, [byte]$right, [byte]$grip, [byte]$duration) {
    $report=[byte[]](3,15,$left,$right,0,$grip,$duration,0,0)
    $stream.Write($report,0,$report.Length)
    $stream.Flush()
}

$null = [Windows.Gaming.Input.Gamepad,Windows.Gaming.Input,ContentType=WindowsRuntime]::Gamepads
$off = [Windows.Gaming.Input.GamepadVibration,Windows.Gaming.Input,ContentType=WindowsRuntime]::new()
$reader = [IO.StreamReader]::new([Console]::OpenStandardInput())
$pad = $null
$hid = $null
function Stop-Output {
    if ($hid) {
        try { Send-Rumble $hid 0 0 0 0 } catch { }
        $hid.Dispose()
    } elseif ($pad) {
        try { $pad.Vibration = $off } catch { }
    }
}
try {
    while ($true) {
        $line = $reader.ReadLineAsync()
        if ($pad -and !$line.Wait(150)) {
            Stop-Output
            $pad = $null
            $hid = $null
        }
        $text = $line.GetAwaiter().GetResult()
        if ($null -eq $text) { break }
        $parts = $text.Split(' ')
        $expired = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() - [long]$parts[0] -gt 150
        if ($expired -or $text.EndsWith(' 0 0 0')) {
            Stop-Output
            $pad = $null
            $hid = $null
            continue
        }
        if (!$pad) {
            # Enumerate the WinRT collection before indexing it in Windows PowerShell.
            $pads = @(foreach ($gamepad in [Windows.Gaming.Input.Gamepad]::Gamepads) { $gamepad })
            if ($pads.Count -ne 1) { continue }
            $pad = $pads[0]
            $raw = [Windows.Gaming.Input.RawGameController,Windows.Gaming.Input,ContentType=WindowsRuntime]::FromGameController($pad)
            if ($raw.IsWireless -and $raw.HardwareVendorId -eq 0x045e -and $raw.HardwareProductId -eq 0x0b13) {
                $hid = Open-XboxHid
            }
        }
        try {
            if ($hid) {
                # Bluetooth Xbox Series controller, output report 3. Refresh at 50 ms.
                Send-Rumble $hid ([math]::Round([int]$parts[1]/10)) ([math]::Round([int]$parts[2]/10)) ([math]::Round([int]$parts[3]/10)) 15
            } else {
                $pulse = [Windows.Gaming.Input.GamepadVibration]::new()
                $pulse.LeftTrigger = [int]$parts[1] / 1000.0
                $pulse.RightTrigger = [int]$parts[2] / 1000.0
                $pulse.RightMotor = [int]$parts[3] / 1000.0
                $pad.Vibration = $pulse
            }
        } catch {
            Stop-Output
            $pad = $null
            $hid = $null
        }
    }
} finally { Stop-Output }
"""
var pipe: Dictionary

func open() -> void:
	var exe := OS.get_environment("SystemRoot").path_join("System32/WindowsPowerShell/v1.0/powershell.exe")
	pipe = OS.execute_with_pipe(exe, ["-NoProfile", "-NonInteractive", "-EncodedCommand", Marshalls.raw_to_base64(COMMAND.to_utf16_buffer())], false)

func play(level: Vector3) -> void:
	if pipe.is_empty(): return
	var stamp := int(Time.get_unix_time_from_system() * 1000)
	pipe.stdio.store_line("%d %d %d %d" % [stamp, roundi(level.x * 1000), roundi(level.y * 1000), roundi(level.z * 1000)])

func close() -> void:
	# EOF releases the motors and ends the helper, including when the game exits.
	pipe.clear()
