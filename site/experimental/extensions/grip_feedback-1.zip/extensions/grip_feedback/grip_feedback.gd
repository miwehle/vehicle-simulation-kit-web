extends "res://extension_system/extension.gd"

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")

const WindowsOutput = preload("res://extensions/grip_feedback/windows_output.gd")
var player
var curve_panel
var browser
var windows: WindowsOutput
var controls := VBoxContainer.new()
# Same channel order as axle_levels(): brake trigger, drive trigger, right grip.
const CHANNEL_LABELS := ["Bremsen · LT", "Beschleunigen · RT", "Kurvenfahrt · rechter Griff"]
var factors: Vector3:
	get: return curve_panel.grip_factors
var device := -1
var next_refresh := 0

func register() -> void:
	process_priority = 10
	player = get_parent().get_node("Player")
	curve_panel = player.get_node("HUD/SettingsMenu").vehicles_tab.curve_panel
	var heading := Label.new()
	heading.text = "Grip Feedback"
	controls.add_child(heading)
	for channel in CHANNEL_LABELS.size():
		_add_strength_control(channel)
	extension_manager.add_dialog_control(self, controls, curve_panel.rows)
	curve_panel.rows.move_child(controls, curve_panel.rows.get_node("Reset").get_index())
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/grip_feedback/browser.js"), true)
		browser = JavaScriptBridge.get_interface("OscherslebenGripFeedback")
	elif OS.get_name() == "Windows" and DisplayServer.get_name() != "headless":
		windows = WindowsOutput.new()
		windows.open()
	observe(Input.joy_connection_changed, _connection_changed)

func _add_strength_control(channel: int) -> void:
	var line := HBoxContainer.new()
	controls.add_child(line)
	var label := Label.new()
	label.text = CHANNEL_LABELS[channel]
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	line.add_child(label)
	var slider := HSlider.new()
	slider.max_value = 2
	slider.step = 0
	slider.value = factors[channel]
	var unit := Label.new()
	unit.text = "×"
	var refresh := UiNumbers.add_slider(line, controls, slider, "%.2f", unit, curve_panel._save)
	slider.value_changed.connect(func(value: float):
		var updated := factors
		updated[channel] = value
		curve_panel.grip_factors = updated)
	observe(curve_panel.grip_factors_changed, func(values: Vector3):
		slider.set_value_no_signal(values[channel])
		refresh.call(slider.value)
		next_refresh = 0)

# Wheel axes: forward and lateral. Output channels: brake, drive, fine handle.
static func axle_levels(force: Vector2, slide: float) -> Vector3:
	var direction := force.normalized()
	return Vector3(maxf(-direction.x, 0), maxf(direction.x, 0), absf(direction.y)) * sqrt(slide)

func motor_levels(levels: Vector3) -> Vector3:
	return (levels * factors).clampf(0.0, 1.0)

func _process(_delta: float) -> void:
	var pad = player.gamepad
	if player.simulation_paused or not player.has_focus or player.flight_mode or player.crashed or not player.ready_to_fly or not pad.armed or not player.keyboard_controls.is_gamepad() or not player.driving is SingleTrackModel:
		_stop()
		return
	if device != -1 and device != pad.device:
		_stop()
	var model = player.driving
	var levels := axle_levels(model.front_tire_force, model.front_slide).max(axle_levels(model.rear_tire_force, model.rear_slide))
	levels = motor_levels(levels)
	if levels.is_zero_approx() or pad.device < 0:
		_stop()
		return
	var now := Time.get_ticks_msec()
	if now < next_refresh: return
	next_refresh = now + 50
	device = pad.device
	_output(device, levels)

func _output(id: int, levels: Vector3) -> void:
	if browser:
		browser.play(id, levels.x, levels.y, levels.z)
	elif windows:
		windows.play(levels if Input.get_connected_joypads().size() == 1 else Vector3.ZERO)
	elif levels.is_zero_approx():
		Input.stop_joy_vibration(id)
	else:
		Input.start_joy_vibration(id, levels.z, 0, 0.15)

func _connection_changed(id: int, connected: bool) -> void:
	if id == device and not connected:
		_stop()

func _stop() -> void:
	if device >= 0:
		_output(device, Vector3.ZERO)
		device = -1
		next_refresh = 0

func cleanup() -> void:
	_stop()
	if windows: windows.close()
