// A trigger-rumble effect drives both triggers and both handles in one command.
globalThis.OscherslebenGripFeedback = {
    play(index, brake, drive, corner) {
        try {
            const actuator = navigator.getGamepads()[index]?.vibrationActuator;
            if (!actuator) return;
            if (!brake && !drive && !corner) {
                actuator.reset().catch(() => {});
                return;
            }
            const triggers = actuator.effects?.includes("trigger-rumble");
            actuator.playEffect(triggers ? "trigger-rumble" : "dual-rumble", {
                duration: 150, weakMagnitude: corner, strongMagnitude: 0,
                leftTrigger: triggers ? brake : 0, rightTrigger: triggers ? drive : 0
            }).catch(() => {});
        } catch { /* Unsupported or disconnected controller. */ }
    }
};
