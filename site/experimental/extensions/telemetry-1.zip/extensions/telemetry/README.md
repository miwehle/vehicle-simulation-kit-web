# Telemetrie

Unter Einstellungen → Erweiterungen „Telemetrie hinzufügen“, danach den Abschnitt „Telemetrie · lokale ZIP-Datei“ öffnen. Aufnahme starten, fahren, im Menü beenden und als Datei speichern. Die Aufnahme startet nie automatisch. Ein HUD-Hinweis kennzeichnet laufende bzw. ungespeicherte Aufnahmen. Eine neue Aufnahme oder Entfernen der Extension überschreibt keine ungespeicherten Daten; „Verwerfen“ benötigt eine Bestätigung.

Der Zielordner wird pro Gerät/Browser gemerkt. Ein lokal synchronisierter Drive-Ordner funktioniert ohne Drive-Anbindung. Browser mit Verzeichniszugriff speichern dessen Handle in IndexedDB und prüfen die Schreibfreigabe vor dem Export. Andere Browser erhalten einen Download; dessen erfolgreichen Abschluss kann die App nicht bestätigen, deshalb bleibt die Aufnahme ungespeichert, bis sie ausdrücklich verworfen wird. Website-Daten löschen entfernt auch den gemerkten Ordner. Nur im RAM vorhandene Aufnahmen gehen beim Schließen verloren; der Browser erhält einen Hinweis auf ungespeicherte Daten.

## Datei und Zeitbasis

Eine ZIP-Datei enthält `metadata.yaml`, `inputs.csv`, `states.csv`, `events.csv`. CSV: UTF-8, Komma, Dezimalpunkt, Kopfzeile; leere Zellen bedeuten unbekannt. Namen tragen UTC-Zeit und eine zufällige Aufnahme-ID. Metadaten enthalten Formatversion, Build, Strecke, tatsächliche Modell-/Eingabeparameter und den Anfangszustand. Im Einstellungsdialog übernommene Konfigurationen werden unter `configuration_changes` nach letztem abgeschlossenem Tick abgelegt; sie gelten für nachfolgende Schritte. Modellparameter und Anfangszustände sind Momentaufnahmen, keine Replay-Garantie.

`tick` bezeichnet den äußeren Simulationsschritt seit Aufnahmebeginn, `time_s` dessen Endzeit. Inputs von Tick N werden in Schritt N angewendet; Zustand N folgt diesem Schritt einschließlich Bodenkontakt. Inputs werden jeden Tick, Zustände jeden dritten Tick erfasst (derzeit 60/20 Hz). Bei Pause/Fokusverlust stehen beide Zähler still; Ereignisse mit gleichem Tick bleiben in Zeilenreihenfolge. Reset setzt die Aufnahme-Uhr nicht zurück. Flugbefehle stehen in eigenen Input-Spalten; Gas/Bremse/Lenkung sind die an das Fahrmodell übergebenen Befehle, `speed_hold` kennzeichnet dessen interne Geschwindigkeitsregelung.

`track_distance_m` in `states.csv` ist derselbe ungerundete Streckenmeterwert wie im HUD: relativ zu Start/Ziel, mit Umlauf bei der Streckenlänge. `track_length_m` steht in den Metadaten. Im Flug bleibt die Spalte leer. Die Spalte ergänzt Formatversion 1; ältere ZIP-Dateien enthalten sie nicht, Leser ordnen Spalten anhand der Kopfzeile zu.

Position/Quaternion beziehen sich auf Godots Weltkoordinaten. Geschwindigkeiten und Beschleunigungen werden aus den akzeptierten Fahrzeugposen je Tick abgeleitet, Winkelgeschwindigkeit in Weltachsen; Beschleunigung wird auf Fahrzeug-vorwärts/links projiziert, ohne Abzug der Gravitation. Nach Reset, Moduswechsel und Fortsetzen bleibt die erste Beschleunigung unbekannt. Einspur-Achskräfte sind die zuletzt berechneten Kräfte im jeweiligen Radkoordinatensystem. Normalkräfte folgen der statischen Lastverteilung des vorhandenen Modells; Reibungsgrenzen berücksichtigen dessen Gleitzustand. Für andere Modelle bleiben diese Spalten leer. Start/Ziel-Ereignisse verwenden die vorhandene Strecken-/Richtungserkennung; Rundenzeiten sind nicht gegen Abkürzungen abgesichert.

## Aufwand und Grenzen

Während der Fahrt: Godot-Signale beobachten und Werte in vorab reservierte Float64-Puffer übernehmen. Standardbudget 32 MiB für Messpuffer, einschließlich 2048 Ereigniszeilen; Metadaten/UI kommen hinzu. Bei vollem Puffer endet die Aufnahme sichtbar. ZIP/CSV/YAML und Dateizugriff erst beim Speichern; dabei ist zusätzlicher temporärer Speicher nötig. Keine Firebase-Übertragung. Die Extension schreibt keinen Fahrzeugzustand.

Tests: `tests/test_recording.gd` prüft Zeitbasis, Snapshots, ZIP und Puffergrenzen; `tests/benchmarks/test_telemetry.gd` prüft Observer-Integration, unveränderten Fahrverlauf und Dateiexport; `tests/test_browser.cjs` prüft gemerkte Ordner, Berechtigungs-/Schreibfehler und Download-Fallback. Diese Tests ersetzen keine Performance-Fahrt auf Notebook und Tablet.

## Lokale Prüfung (11.11.2026)

52 lokale Testdateien bestanden; anschließend aktualisierte Telemetrie-Tests erneut bestanden. Web-Export, exportierter Navigationstest und Telemetrie-Integration gegen das PCK geprüft. Im Browser Aufnahme/Beenden und der Download-Fallback geprüft; heruntergeladene ZIP ist bytegleich zur Quelldatei. YAML und CSV zusätzlich mit Python unabhängig eingelesen. Native Dateiausgabe und gemerkter Browserordner einschließlich Fehlerpfaden automatisiert geprüft; die echte Browser-Ordnerauswahl samt Wiederverwendung nach Neustart ist noch manuell in Chrome zu prüfen.

Eine synthetische Minute mit wechselnden Fahrbefehlen: 3600 Input- und 1200 Zustandszeilen, 513557 Byte unkomprimiert, 157319 Byte ZIP; Export etwa 0,16 s auf diesem Notebook. Acht abwechselnde Headless-Läufe mit/ohne Aufnahme ergaben einen Zusatzaufwand im Bereich weniger Mikrosekunden pro Tick. Das ist keine Aussage über Bildzeiten im Browser oder auf dem Tablet. Vergleichsfahrten dort stehen noch aus.
