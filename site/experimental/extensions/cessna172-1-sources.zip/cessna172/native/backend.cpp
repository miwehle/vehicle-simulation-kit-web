// Thin binding to JSBSim 1.2.4. Flight policy and units live in runtime.gd.
#include <memory>
#include <godot_cpp/classes/ref_counted.hpp>
#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/godot.hpp>
#include <FGFDMExec.h>
using namespace godot;

class VeskiJSBSimBackend : public RefCounted {
    GDCLASS(VeskiJSBSimBackend, RefCounted)
    std::unique_ptr<JSBSim::FGFDMExec> exec;
    String error;
protected:
    static void _bind_methods() {
        ClassDB::bind_method(D_METHOD("open", "directory"), &VeskiJSBSimBackend::open);
        ClassDB::bind_method(D_METHOD("loadModel", "model"), &VeskiJSBSimBackend::loadModel);
        ClassDB::bind_method(D_METHOD("setPropertyValue", "key", "value"), &VeskiJSBSimBackend::setPropertyValue);
        ClassDB::bind_method(D_METHOD("getPropertyValue", "key"), &VeskiJSBSimBackend::getPropertyValue);
        ClassDB::bind_method(D_METHOD("setDt", "dt"), &VeskiJSBSimBackend::setDt);
        ClassDB::bind_method(D_METHOD("runIc"), &VeskiJSBSimBackend::runIc);
        ClassDB::bind_method(D_METHOD("doTrim", "mode"), &VeskiJSBSimBackend::doTrim);
        ClassDB::bind_method(D_METHOD("resetToInitialConditions", "mode"), &VeskiJSBSimBackend::resetToInitialConditions);
        ClassDB::bind_method(D_METHOD("run"), &VeskiJSBSimBackend::run);
        ClassDB::bind_method(D_METHOD("destroy"), &VeskiJSBSimBackend::destroy);
        ClassDB::bind_method(D_METHOD("get_error"), &VeskiJSBSimBackend::get_error);
    }
public:
    bool open(String directory) {
        try {
            error = "";
            exec = std::make_unique<JSBSim::FGFDMExec>();
            exec->SetDebugLevel(0);
            exec->SetRootDir(SGPath(directory.utf8().get_data()));
            exec->SetAircraftPath(SGPath("aircraft"));
            exec->SetEnginePath(SGPath("engine"));
            exec->SetSystemsPath(SGPath("systems"));
            return true;
        } catch (const std::exception &e) { error = e.what(); exec.reset(); return false; }
    }
    bool loadModel(String model) {
        try { return exec && exec->LoadModel(model.utf8().get_data()); }
        catch (const std::exception &e) { error = e.what(); return false; }
    }
    void setPropertyValue(String key, double value) { if (exec) exec->SetPropertyValue(key.utf8().get_data(), value); }
    double getPropertyValue(String key) { return exec ? exec->GetPropertyValue(key.utf8().get_data()) : 0; }
    void setDt(double dt) { if (exec) exec->Setdt(dt); }
    bool runIc() {
        try { return exec && exec->RunIC(); }
        catch (const std::exception &e) { error = e.what(); return false; }
    }
    void doTrim(int mode) {
        try { if (exec) exec->DoTrim(mode); }
        catch (const std::exception &e) { error = e.what(); }
    }
    void resetToInitialConditions(int mode) {
        try { if (exec) exec->ResetToInitialConditions(mode); }
        catch (const std::exception &e) { error = e.what(); }
    }
    bool run() {
        try { return exec && exec->Run(); }
        catch (const std::exception &e) { error = e.what(); return false; }
    }
    void destroy() { exec.reset(); }
    String get_error() const { return error; }
};

static void initialize(ModuleInitializationLevel level) {
    if (level == MODULE_INITIALIZATION_LEVEL_SCENE) ClassDB::register_class<VeskiJSBSimBackend>();
}
static void terminate(ModuleInitializationLevel) {}
extern "C" GDExtensionBool GDE_EXPORT veski_jsbsim_init(
        GDExtensionInterfaceGetProcAddress get_proc, GDExtensionClassLibraryPtr library,
        GDExtensionInitialization *initialization) {
    GDExtensionBinding::InitObject init(get_proc, library, initialization);
    init.register_initializer(initialize);
    init.register_terminator(terminate);
    init.set_minimum_library_initialization_level(MODULE_INITIALIZATION_LEVEL_SCENE);
    return init.init();
}
