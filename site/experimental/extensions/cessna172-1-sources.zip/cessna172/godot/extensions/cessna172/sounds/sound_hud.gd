extends PanelContainer
## Optional live mixer; closing it does not stop aircraft audio.
signal shown_changed(shown: bool)
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
const AircraftModel = preload("../jsbsim_model.gd")
var audio: Node3D
var sliders := {}
var header := Label.new()
var close_button := Button.new()
var reset_button := Button.new()
var _dragging := false
var _offset := Vector2.ZERO
var placement := Vector2(1, 0.2)

func _ready() -> void:
	name = "CessnaSound"
	hide()
	custom_minimum_size.x = 320
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.06, 0.09, 0.94)
	style.set_content_margin_all(10)
	style.set_corner_radius_all(6)
	add_theme_stylebox_override("panel", style)
	var rows := VBoxContainer.new()
	add_child(rows)
	var top := HBoxContainer.new()
	rows.add_child(top)
	header.text = "Cessna · Sound"
	header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.mouse_filter = Control.MOUSE_FILTER_STOP
	header.mouse_default_cursor_shape = Control.CURSOR_MOVE
	header.gui_input.connect(_begin_drag)
	top.add_child(header)
	close_button.text = "×"
	close_button.pressed.connect(func(): set_shown(false))
	top.add_child(close_button)
	for key in {"engine": "Motor", "stall": "Überziehwarnung", "wind": "Wind"}:
		var row := HBoxContainer.new()
		rows.add_child(row)
		var label := Label.new()
		label.text = {"engine": "Motor", "stall": "Überziehwarnung", "wind": "Wind"}[key]
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var slider := HSlider.new()
		slider.max_value = 100
		slider.value = audio.levels[key] * 100
		var unit := Label.new()
		unit.text = "%"
		UiNumbers.add_slider(row, rows, slider, "%.0f", unit, audio.save)
		row.get_node("Value").focus_entered.connect(audio.vehicle.flight_keyboard.clear_motion)
		slider.value_changed.connect(func(value): audio.set_level(key, value / 100))
		sliders[key] = slider
	reset_button.text = "Standard wiederherstellen"
	reset_button.tooltip_text = "Alle Lautstärken auf 100 % der C172P-Referenzabstimmung setzen."
	reset_button.pressed.connect(func():
		for key in sliders: sliders[key].value = audio.DEFAULT_LEVELS[key] * 100
		audio.save())
	rows.add_child(reset_button)
	UiLayout.changed.connect(_place)
	resized.connect(_place)
	UiLayout.bind_hud(self)
	_place.call_deferred()

func _process(_delta: float) -> void:
	visible = audio.hud_shown and audio.vehicle.registered_model is AircraftModel
	if not visible: _dragging = false

func set_shown(shown: bool) -> void:
	audio.hud_shown = shown
	audio.save()
	_process(0)
	shown_changed.emit(shown)

func _place() -> void:
	if not is_inside_tree(): return
	var room := (get_viewport_rect().size - Vector2(16, 16)).max(Vector2.ONE)
	scale = Vector2.ONE * minf(UiLayout.factor, minf(room.x / maxf(1, size.x), room.y / maxf(1, size.y)))
	position = Vector2(8, 8) + (room - size * scale) * placement

func _begin_drag(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_dragging = true
		_offset = header.get_global_transform_with_canvas() * event.position - position
		accept_event()

func _input(event: InputEvent) -> void:
	if not _dragging: return
	if event is InputEventMouseMotion:
		var space := (get_viewport_rect().size - Vector2(16, 16) - size * scale).max(Vector2.ZERO)
		position = (event.position - _offset).clamp(Vector2(8, 8), Vector2(8, 8) + space)
		placement = (position - Vector2(8, 8)) / space.max(Vector2.ONE)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		_dragging = false
		get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: _dragging = false
