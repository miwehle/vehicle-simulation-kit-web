extends VBoxContainer
## Describes the aircraft supplied by a JSBSim extension.
const View = preload("cessna_view.gd")
var choice: OptionButton
var player: Node

func build(menu, sections: Dictionary) -> void:
	add_theme_constant_override("separation", 14)
	for title in sections:
		menu.add_section(self, title)
		var description: Label = menu.make_label(sections[title], 20)
		description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		add_child(description)
	View.load_choice()
	player = menu.get_parent().get_parent()
	menu.add_section(self, "3D-Darstellung")
	var labels: Array[String] = ["Einfach · Prototyp", "Detailliert · C172P"]
	choice = menu.add_option_button(self, labels)
	discard()

func changed() -> bool:
	return (choice.selected == 1) != View.detailed

func apply(persist: bool) -> void:
	if changed():
		View.detailed = choice.selected == 1
		if player.vehicle_view != null and player.vehicle_view.get_script() == View:
			player.vehicle_view.set_detailed(View.detailed)
	if persist: View.save_choice()

func discard() -> void:
	choice.select(1 if View.detailed else 0)

func add_sound_control(menu, hud) -> void:
	menu.add_section(self, "Sound")
	var toggle := CheckButton.new()
	toggle.name = "SoundHudToggle"
	toggle.text = "Sound-HUD anzeigen"
	toggle.button_pressed = hud.audio.hud_shown
	toggle.toggled.connect(hud.set_shown)
	hud.shown_changed.connect(toggle.set_pressed_no_signal)
	add_child(toggle)

func add_flight_data_control(menu, hud) -> void:
	menu.add_section(self, "Flugdaten")
	var toggle := CheckButton.new()
	toggle.name = "FlightDataToggle"
	toggle.text = "Flugdaten anzeigen"
	toggle.button_pressed = hud.shown
	toggle.toggled.connect(hud.set_shown)
	hud.shown_changed.connect(toggle.set_pressed_no_signal)
	add_child(toggle)
