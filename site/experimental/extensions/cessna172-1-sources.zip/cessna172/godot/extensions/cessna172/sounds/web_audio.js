// VeSKi intentionally uses the Dummy Godot audio driver on Web.
// Decode the original WAVs once, then update six looped positional sources.
globalThis.VeskiCessnaAudio = {
  start(raw) {
    const context = new AudioContext({latencyHint: 'interactive'});
    const master = context.createGain();
    master.gain.value = 0;
    const analyser = context.createAnalyser();
    master.connect(analyser); analyser.connect(context.destination);
    const voices = {};
    let disposed = false, paused = true;
    const button = document.createElement('button');
    button.textContent = 'Cessna · Ton einschalten';
    button.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:10000;padding:14px;font:18px system-ui;color:white;background:#193747;border:2px solid #66cfff;border-radius:8px;display:none';
    document.body.appendChild(button);
    function display() {button.style.display = !paused && context.state !== 'running' ? 'block' : 'none';}
    function resume() {
      if (!disposed && !paused && context.state === 'suspended') context.resume().then(display).catch(e => {api.error = String(e);});
    }
    const events = ['pointerdown', 'keydown', 'touchend'];
    events.forEach(name => window.addEventListener(name, resume, true));
    context.onstatechange = display;
    const api = {
      error: '',
      ready: false,
      update(rawState) {
        if (disposed) return;
        const state = JSON.parse(rawState);
        paused = state.paused;
        master.gain.value = paused ? 0 : 1;
        const listener = context.listener;
        listener.setPosition(...state.position);
        listener.setOrientation(...state.forward, ...state.up);
        for (const [id, value] of Object.entries(state.voices)) {
          const voice = voices[id];
          if (!voice) continue;
          voice.source.playbackRate.value = value.pitch;
          voice.gain.gain.value = value.gain;
          voice.panner.setPosition(...value.position);
        }
        if (paused) api.pause(); else resume();
        display();
      },
      pause() {
        paused = true; master.gain.value = 0; display();
        if (context.state === 'running') context.suspend().catch(e => {api.error = String(e);});
      },
      peak() {
        const data = new Float32Array(analyser.fftSize);
        analyser.getFloatTimeDomainData(data);
        return data.reduce((peak, value) => Math.max(peak, Math.abs(value)), 0);
      },
      dispose() {
        disposed = true;
        master.gain.value = 0;
        events.forEach(name => window.removeEventListener(name, resume, true));
        context.onstatechange = null;
        button.remove();
        Object.values(voices).forEach(voice => {voice.source.stop(); voice.source.disconnect(); voice.gain.disconnect(); voice.panner.disconnect();});
        context.close();
      }
    };
    (async () => {
      const buffers = {};
      for (const [id, encoded] of Object.entries(JSON.parse(raw))) {
        const bytes = Uint8Array.from(atob(encoded), c => c.charCodeAt(0));
        buffers[id] = await context.decodeAudioData(bytes.buffer);
      }
      if (disposed) return;
      for (const id of ['engine', 'idle', 'starter', 'stall', 'wind_left', 'wind_right']) {
        const source = context.createBufferSource();
        source.buffer = buffers[id.startsWith('wind') ? 'wind' : id];
        source.loop = true;
        const gain = context.createGain(); gain.gain.value = 0;
        const panner = context.createPanner();
        panner.panningModel = 'equalpower'; panner.distanceModel = 'inverse';
        panner.refDistance = 20; panner.rolloffFactor = id === 'stall' ? 0 : 1;
        source.connect(gain); gain.connect(panner); panner.connect(master);
        source.start(0, id === 'wind_right' ? 4.2 : 0);
        voices[id] = {source, gain, panner};
      }
      api.ready = true;
    })().catch(e => {if (!disposed) {api.error = String(e); console.error('Cessna audio:', e);}});
    return api;
  }
};
