extends "res://extension_system/extension.gd"
## Registers the C172P model and its vehicle panel.
const AircraftModel = preload("jsbsim_model.gd")
const MODEL_ID: StringName = &"cessna172.flight"
const VEHICLE_ID: StringName = &"cessna172"
var _dpad_held: Dictionary = {}
var _dpad_device := -1
var vehicle: Vehicle
var removal_hint := AcceptDialog.new()

func register() -> void:
	removal_hint.title = "Cessna-Erweiterung entfernen"
	add_child(removal_hint)
	if not extension_manager.add_vehicle_model(self, MODEL_ID, func(): return preload("jsbsim_model.gd").new()):
		push_error("Cessna model ID is already registered.")
		return
	var definition = preload("res://physics/vehicle_configuration.gd").new()
	definition.title = "Cessna 172P · JSBSim"
	definition.model_id = MODEL_ID
	definition.category = "Flugzeuge"
	definition.instruments_script = preload("dashboard.gd")
	definition.visual_scene = preload("cessna_view.tscn")
	definition.extension_id = "cessna172"
	if not extension_manager.add_vehicle(self, VEHICLE_ID, definition):
		extension_manager.unregister(self)
		push_error("Cessna vehicle could not be registered.")
		return
	var menu = get_parent().get_node("Player/HUD/SettingsMenu")
	vehicle = menu.get_parent().get_parent()
	var audio = preload("sounds/aircraft_audio.gd").new()
	audio.name = "AircraftAudio"
	audio.vehicle = menu.get_parent().get_parent()
	add_child(audio)
	var sound_hud = preload("sounds/sound_hud.gd").new()
	sound_hud.audio = audio
	extension_manager.add_hud_control(self, sound_hud)
	var panel = preload("jsbsim_aircraft_panel.gd").new()
	panel.build(menu, {
		"Flugdynamik": "Cessna 172P · JSBSim",
		"Antrieb": "Kolbenmotor mit Propeller · Teil des JSBSim-Flugzeugmodells",
		"Fahrwerk / Bodenkontakt": "Festes Dreibeinfahrwerk · Teil des JSBSim-Flugzeugmodells",
		"3D-Darstellung": "Einfacher Flugzeugkörper aus dem Flugprototyp"
	})
	panel.add_sound_control(menu, sound_hud)
	var flight_data = preload("flight_data_hud.gd").new()
	flight_data.vehicle = audio.vehicle
	extension_manager.add_hud_control(self, flight_data)
	panel.add_flight_data_control(menu, flight_data)
	panel.add_child(menu.make_label("Getrimmter Start in der Luft. Pfeile: Ruder · Q/E: Seitenruder · W/S: Gas. Gamepad und weitere Bedienung: F1.", 20))
	extension_manager.add_dialog_control(self, panel, menu.vehicles_tab.model_content, {
		"changed": panel.changed, "apply": panel.apply, "discard": panel.discard})
	menu.vehicles_tab.add_model_panel(MODEL_ID, panel)
	var sixpack = preload("sixpack/sixpack_hud.gd").new()
	sixpack.vehicle = menu.get_parent().get_parent()
	extension_manager.add_hud_control(self, sixpack)
func can_remove() -> bool:
	var scenes = get_parent().get_node("Player/HUD/SettingsMenu").simulation_scene_tree
	var names: PackedStringArray = []
	for scene in scenes.records:
		if scene.vehicle_id == VEHICLE_ID: names.append(scene.title)
	if names.is_empty(): return true
	removal_hint.dialog_text = "Die Cessna wird noch in folgenden Szenen verwendet:\n%s\n\nBitte zuerst das Fahrzeug aus diesen Szenen entfernen oder die Szenen löschen." % "\n".join(names)
	removal_hint.popup_centered()
	return false

func _input(event: InputEvent) -> void:
	if not event is InputEventJoypadButton: return
	if not event.pressed:
		if event.device == _dpad_device: _dpad_held.erase(event.button_index)
		return
	var start_pressed: bool = event.button_index == JOY_BUTTON_X
	if not is_instance_valid(vehicle) or not vehicle.registered_model is AircraftModel: return
	if not vehicle.registered_model.model_ready or vehicle.simulation_paused or vehicle.simulation_stopped or not vehicle.has_focus or vehicle.controls_captured: return
	var runtime = vehicle.registered_model.runtime
	if start_pressed:
		if get_viewport().gui_get_focus_owner() is LineEdit: return
		runtime.start_engine()
		get_viewport().set_input_as_handled()
		return
	if event.button_index not in [JOY_BUTTON_DPAD_UP, JOY_BUTTON_DPAD_DOWN, JOY_BUTTON_DPAD_LEFT, JOY_BUTTON_DPAD_RIGHT]: return
	if event.device != _dpad_device: _dpad_held.clear()
	_dpad_device = event.device
	_dpad_held[event.button_index] = 0.0
	_adjust_dpad(event.button_index, 1)
	get_viewport().set_input_as_handled()

func _adjust_dpad(button: int, steps: int) -> void:
	var runtime = vehicle.registered_model.runtime
	if button in [JOY_BUTTON_DPAD_UP, JOY_BUTTON_DPAD_DOWN]:
		var degrees: float = AircraftModel.trim_degrees(runtime.pitch_trim)
		degrees += steps * (-0.05 if button == JOY_BUTTON_DPAD_UP else 0.05)
		runtime.set_pitch_trim(AircraftModel.trim_normalized(clampf(degrees, -22.0, 19.0)))
	else:
		runtime.set_mixture(runtime.mixture + steps * (0.01 if button == JOY_BUTTON_DPAD_LEFT else -0.01))

func _process(delta: float) -> void:
	if _dpad_held.is_empty(): return
	if not is_instance_valid(vehicle) or not vehicle.registered_model is AircraftModel or not vehicle.registered_model.model_ready or vehicle.simulation_paused or vehicle.simulation_stopped or not vehicle.has_focus or vehicle.controls_captured:
		_dpad_held.clear()
		return
	for button: int in _dpad_held.keys():
		if not Input.is_joy_button_pressed(_dpad_device, button):
			_dpad_held.erase(button)
			continue
		var rate := 4.0 if button in [JOY_BUTTON_DPAD_UP, JOY_BUTTON_DPAD_DOWN] else 10.0
		var held: float = _dpad_held[button]
		var previous := maxi(0, int(floor((held - 2.0) * rate + 0.000001)))
		held += delta
		_dpad_held[button] = held
		var repeats := maxi(0, int(floor((held - 2.0) * rate + 0.000001))) - previous
		if repeats > 0: _adjust_dpad(button, repeats)
