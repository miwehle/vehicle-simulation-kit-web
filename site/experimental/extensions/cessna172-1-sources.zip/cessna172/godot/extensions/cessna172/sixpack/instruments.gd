extends SubViewport
## One small unlit viewport for the seven original C172P instrument meshes.
const ASSETS := "res://extensions/cessna172/sixpack/"
var rig: Dictionary = {}
var parts: Dictionary = {}
var pitch_origin := Vector3.ZERO

func _ready() -> void:
	own_world_3d = true
	transparent_bg = true
	handle_input_locally = false
	render_target_update_mode = SubViewport.UPDATE_DISABLED
	msaa_3d = Viewport.MSAA_2X
	var document := GLTFDocument.new()
	var data := GLTFState.new()
	if document.append_from_buffer(FileAccess.get_file_as_bytes(ASSETS + "instruments.glb"), "", data) != OK:
		push_error("C172P-Instrumente konnten nicht geladen werden.")
		return
	var model := document.generate_scene(data)
	add_child(model)
	for node in model.find_children("*", "MeshInstance3D", true, false):
		for surface in node.mesh.get_surface_count():
			var material: StandardMaterial3D = node.mesh.surface_get_material(surface)
			material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			material.cull_mode = BaseMaterial3D.CULL_DISABLED
			if node.name.begins_with("tc_") or node.name.begins_with("hi_"):
				material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 0.18
	camera.near = 0.01
	camera.position.z = 1
	add_child(camera)
	rig = JSON.parse_string(FileAccess.get_file_as_string(ASSETS + "rig.json"))
	for key in rig: parts[key] = model.find_child(key, true, false)
	pitch_origin = parts.AI_Pitch.position

func display(values: Dictionary) -> void:
	if parts.is_empty() or values.is_empty(): return
	_rotate("asi_Needle", values.indicated_kts)
	_rotate("AI_Roll", values.roll_deg)
	_rotate("AI_Pitch", values.roll_deg)
	# Translate in the rotating card's local vertical, as in the source XML.
	parts.AI_Pitch.position = pitch_origin + parts.AI_Pitch.basis * Vector3(0, clampf(-values.pitch_deg * 0.0007, -0.01575, 0.01575), 0)
	for needle in ["alt_Needle100", "alt_Needle1000", "alt_Needle10000"]:
		_rotate(needle, values.pressure_altitude_ft)
	_rotate("tc_Airplane", clampf(values.turn_rate, -2.5, 2.5))
	_rotate("tc_Ball", clampf(values.slip, -9.3 / 5.729, 9.3 / 5.729))
	_rotate("hi_Face", values.heading_deg)
	_rotate("VSI_PointerCentre", values.climb_fpm)
	_rotate("VSI_PointerTip", values.climb_fpm)
	_rotate("RPM_PointerCentre", values.propeller_rpm)
	_rotate("RPM_PointerTip", values.propeller_rpm)
	render_target_update_mode = SubViewport.UPDATE_ONCE

func _rotate(key: String, value: float) -> void:
	var specification: Dictionary = rig[key]
	var table: Array = specification.table
	var angle := value * float(specification.factor)
	if not table.is_empty():
		angle = table.back()[1]
		if value <= table[0][0]: angle = table[0][1]
		else:
			for index in range(1, table.size()):
				if value <= table[index][0]:
					var a: Array = table[index - 1]
					var b: Array = table[index]
					angle = lerpf(a[1], b[1], (value - a[0]) / (b[0] - a[0]))
					break
	parts[key].rotation.z = -deg_to_rad(angle)
