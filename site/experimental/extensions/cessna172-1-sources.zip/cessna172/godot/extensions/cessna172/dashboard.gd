extends "res://ui/instruments/dashboard.gd"
## Simple flight instruments when the optional Sixpack is not replacing them.
const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
const MUTED := Color(0.48, 0.62, 0.72)
var values: Dictionary = {}
var compact := false

func instrument_size(small: bool) -> Vector2:
	compact = small
	return Vector2(420, 82) if small else Vector2(600, 190)

func refresh(vehicle: Vehicle) -> void:
	values = vehicle.registered_model.flight_instruments()
	queue_redraw()

func _draw() -> void:
	if values.is_empty(): return
	var rows := [
		["FLUGTEMPO (TAS)", "%.0f km/h" % (values.speed_mps * 3.6)],
		["HÖHE (%s)" % values.get("height_datum", "MSL"), "%.0f m" % values.altitude_m],
		["KURS", "%03d°" % (int(round(values.heading_deg)) % 360)],
		["QUERLAGE", "%.1f°" % values.roll_deg],
		["LÄNGSNEIGUNG", "%.1f°" % values.pitch_deg],
		["GAS", "%.0f %%" % (values.throttle * 100)],
	]
	var column := size.x / 3.0
	var height := size.y / 2.0
	for i in rows.size():
		var x := (i % 3) * column
		var y := int(i / 3) * height
		draw_string(ThemeDB.fallback_font, Vector2(x, y + (12 if compact else 24)), rows[i][0], HORIZONTAL_ALIGNMENT_CENTER, column, 9 if compact else 13, MUTED)
		draw_string(ThemeDB.fallback_font, Vector2(x, y + (32 if compact else 60)), UiNumbers.display(rows[i][1]), HORIZONTAL_ALIGNMENT_CENTER, column, 16 if compact else 25, Color.WHITE)
