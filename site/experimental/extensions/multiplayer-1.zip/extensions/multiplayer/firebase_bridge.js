/* Loaded from the Godot resource pack. No Firebase work before explicit join.
 * JSON strings are the sole boundary to GDScript. Public web config is not a secret.
 */
(() => {
  if (window.OscherslebenMultiplayer) return;
  const sdkRoot = 'https://www.gstatic.com/firebasejs/13.1.0/';
  let api, auth, db, ownRef, disconnectTask, initialization;
  let generation = 0, stops = [], connected = false, pending = false;
  let offset = 0, nickname = '', callback = null, lastTimestamp = 0;
  let sent = 0, received = 0;
  const backgroundTimeoutMs = 60_000;
  let session = null, backgroundTimer = null, backgroundDisconnected = false;
  const emit = (event) => { if (callback) callback(JSON.stringify(event)); };
  const status = (message, state) => { emit({type: 'status', message}); if (state) emit({type: 'connection', state}); };
  const token = () => Array.from(crypto.getRandomValues(new Uint8Array(16)), n => n.toString(16).padStart(2, '0')).join('');
  const now = () => Date.now() + offset;
  async function initialize(config) {
    if (!initialization) initialization = initializeOnce(config).catch(error => {
      initialization = null;
      throw error;
    });
    return initialization;
  }
  async function initializeOnce(config) {
    if (!config.apiKey || !config.databaseURL) throw new Error('Firebase ist noch nicht eingerichtet.');
    const [appApi, authApi, databaseApi] = await Promise.all([
      import(sdkRoot + 'firebase-app.js'), import(sdkRoot + 'firebase-auth.js'), import(sdkRoot + 'firebase-database.js')
    ]);
    api = {...authApi, ...databaseApi};
    if (!db) {
      const app = appApi.initializeApp(config, 'oschersleben-multiplayer');
      auth = api.initializeAuth(app, {persistence: api.inMemoryPersistence});
      db = api.getDatabase(app);
    }
    await api.signInAnonymously(auth);
  }
  function disconnect() {
    ++generation;
    connected = false;
    pending = false;
    stops.forEach(stop => stop()); stops = [];
    const oldRef = ownRef, oldTask = disconnectTask;
    ownRef = null; disconnectTask = null;
    if (db) api.goOffline(db); // discard the connection before any new session
    // Server-side onDisconnect removes presence; do not queue offline removals.
    if (oldRef && oldTask) { /* intentionally leave onDisconnect armed */ }
    emit({type: 'clear'});
    status('Nicht verbunden', 'idle');
  }
  function leave() {
    session = null;
    backgroundDisconnected = false;
    clearTimeout(backgroundTimer); backgroundTimer = null;
    disconnect();
  }
  function suspendInBackground() {
    clearTimeout(backgroundTimer); backgroundTimer = null;
    if (!session || backgroundDisconnected) return;
    backgroundDisconnected = true;
    disconnect();
    status('Im Hintergrund getrennt – verbindet beim Zurückkommen', 'suspended');
  }
  function visibilityChanged() {
    clearTimeout(backgroundTimer); backgroundTimer = null;
    if (!session) return;
    if (document.hidden) {
      if (!backgroundDisconnected) backgroundTimer = setTimeout(suspendInBackground, backgroundTimeoutMs);
    } else if (backgroundDisconnected) {
      const saved = session;
      join(saved.configJson, saved.room, saved.nick);
    }
  }

  // A browser may freeze a hidden page before its timer runs. Disconnect on
  // lifecycle events too, and restore a page returned from the back/forward cache.
  function lifecycle(add) {
    const method = add ? 'addEventListener' : 'removeEventListener';
    document[method]('visibilitychange', visibilityChanged);
    document[method]('freeze', suspendInBackground);
    window[method]('pagehide', suspendInBackground);
    window[method]('pageshow', visibilityChanged);
    document[method]('resume', visibilityChanged);
  }
  async function join(configJson, room, nick) {
    leave();
    const epoch = generation;
    try {
      if (!/^[a-f0-9]{32}$/.test(room)) throw new Error('Bitte einen gültigen Einladungslink oder Raumcode verwenden.');
      nickname = nick.trim().slice(0, 24) || 'Fahrer';
      session = {configJson, room, nick: nickname};
      visibilityChanged();
      status('Verbinde …', 'connecting');
      await initialize(JSON.parse(configJson));
      if (epoch !== generation) return;
      api.goOnline(db);
      ownRef = api.ref(db, `rooms/${room}/riders/${auth.currentUser.uid}`);
      const ridersRef = api.ref(db, `rooms/${room}/riders`);
      const fail = (error) => { if (epoch === generation) { connected = false; status('Verbindungsfehler: ' + error.message, 'error'); } };
      stops.push(api.onValue(api.ref(db, '.info/serverTimeOffset'), s => { offset = s.val() || 0; }));
      stops.push(api.onValue(api.ref(db, '.info/connected'), async s => {
        if (epoch !== generation) return;
        connected = false;
        if (!s.val()) { status('Verbindung unterbrochen – warte …', 'reconnecting'); return; }
        try {
          const task = api.onDisconnect(ownRef);
          await task.remove();
          if (epoch !== generation) return;
          disconnectTask = task; connected = true; pending = false;
          status('Verbunden', 'connected');
        } catch (error) { fail(error); }
      }, fail));
      const receive = s => {
        if (epoch !== generation || s.key === auth.currentUser.uid) return;
        const state = s.val();
        const age = Math.max(0, now() - state.t);
        if (age > 3000) return;
        received += new TextEncoder().encode(JSON.stringify(state)).length;
        emit({type: 'state', id: s.key, state, age});
      };
      stops.push(api.onChildAdded(ridersRef, receive, fail));
      stops.push(api.onChildChanged(ridersRef, receive, fail));
      stops.push(api.onChildRemoved(ridersRef, s => { if (epoch === generation) emit({type: 'remove', id: s.key}); }, fail));
      const url = new URL(location.href); url.hash = 'room=' + room;
      emit({type: 'room', room, link: url.href});
    } catch (error) {
      if (epoch === generation) { leave(); status(error.message); }
    }
  }
  function send(json) {
    if (!connected || pending || !ownRef || document.hidden) return;
    const capturedAt = now(); // Fresh snapshot passed synchronously by the vehicle; no send queue.
    const state = JSON.parse(json);
    state.nick = nickname;
    state.t = Math.max(Math.round(capturedAt), lastTimestamp + 1); lastTimestamp = state.t;
    const epoch = generation;
    pending = true; // at most one write outstanding; never build a motion backlog
    sent += new TextEncoder().encode(JSON.stringify(state)).length;
    api.set(ownRef, state).catch(error => {
      if (epoch === generation) status('Senden fehlgeschlagen: ' + error.message);
    }).finally(() => { if (epoch === generation) pending = false; });
  }
  window.OscherslebenMultiplayer = {
    bind(fn) { callback = fn; lifecycle(!!fn); },
    dispose() { callback = null; lifecycle(false); leave(); sent = 0; received = 0; lastTimestamp = 0; },
    join, leave, send, newRoom: token,
    initialRoom() { return new URLSearchParams(location.hash.slice(1)).get('room') || ''; },
    stats() { return JSON.stringify({sent, received}); }
  };
})();
