extends "res://extension_system/extension.gd"
## Observe the player's existing controller snapshot after its regular update.
const SAMPLE_MS := 200
const WINDOW_MS := 60000
const POST_MS := 5000
const COLORS := {"green": Color("#65df97"), "yellow": Color("#ffd04a"), "red": Color("#fc665c")}
var player
var browser: JavaScriptObject
const WINDOWS_PREF := "user://gamepad_monitor_battery.cfg"
const WindowsBattery = preload("res://extensions/gamepad_monitor/windows_battery.gd")
var windows_battery: WindowsBattery
var windows_enabled := false
var battery_button: Button
var badge := PanelContainer.new()
var caption := Label.new()
var lamp := Control.new()
var options := VBoxContainer.new()
var details := Label.new()
var last_report := ""
var history: Array[Dictionary] = []
var events: Array[Dictionary] = []
var next_sample := 0
var pending_until := -1
var marked_at := ""
var reason := ""
var state := ""
var battery := -1
var last_device := -1
var last_loss := -WINDOW_MS * 2
var unstable_until := -1
var build := ""
var scene := ""
var applied_steering: Variant = null
var applied_at := -1000
var changed_at := 0
var reminder_at := 0
var acknowledged := false
var battery_message := ""
var pulse: Tween
var active_pad := false
var badge_placement := Vector2(-1, -1)
var dragging_badge := false
var drag_offset := Vector2.ZERO

func register() -> void:
	player = get_parent().get_node("Player")
	process_priority = 10
	build = player.get_node("HUD/SettingsMenu").info_tab.build_version()
	scene = get_parent().scene_file_path
	observe(player.simulation_step_started, _ground_input)
	if OS.has_feature("web"):
		JavaScriptBridge.eval(FileAccess.get_file_as_string("res://extensions/gamepad_monitor/browser.js"), true)
		browser = JavaScriptBridge.get_interface("OscherslebenGamepadMonitor")
	elif OS.get_name() == "Windows":
		windows_battery = WindowsBattery.new()
		windows_enabled = FileAccess.file_exists(WINDOWS_PREF)
	extension_manager.add_hud_control(self, badge)
	badge.mouse_filter = Control.MOUSE_FILTER_STOP
	badge.mouse_default_cursor_shape = Control.CURSOR_MOVE
	badge.gui_input.connect(_begin_badge_drag)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.add_child(row)
	row.add_child(caption)
	row.add_child(lamp)
	lamp.custom_minimum_size = Vector2(16, 18)
	lamp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lamp.draw.connect(func(): lamp.draw_circle(Vector2(7, lamp.size.y / 2), 5, Color.WHITE, true, -1.0, true))
	caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	caption.add_theme_font_size_override("font_size", 15)
	UiLayout.bind_hud(badge)
	var menu = player.get_node("HUD/SettingsMenu")
	extension_manager.add_dialog_control(self, options)
	var heading := Label.new()
	heading.text = "Gamepad Monitor"
	options.add_child(heading)
	battery_button = menu.add_action_button(options, "Batteriewarnung aktivieren", _choose_battery)
	menu.add_action_button(options, "Warnung quittieren", func(): acknowledged = true)
	menu.add_action_button(options, "Störung markieren (F8)", func(): mark("manual"))
	menu.add_action_button(options, "Letzte Störung ansehen", _show_report)
	options.add_child(details)
	details.text = "Fehlt der Xbox-Controller in der Geräteauswahl, seine Kopplungstaste kurz gedrückt halten."
	if windows_battery:
		_update_windows_option()
	elif not browser:
		battery_button.disabled = true
		details.text = "Batteriestand auf dieser Plattform nicht verfügbar."
	details.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	observe(Input.joy_connection_changed, _connection_changed)

func _choose_battery() -> void:
	if windows_battery:
		windows_enabled = not windows_enabled
		if windows_enabled:
			var setting := FileAccess.open(WINDOWS_PREF, FileAccess.WRITE)
			if setting: setting.store_line("enabled")
		elif FileAccess.file_exists(WINDOWS_PREF):
			DirAccess.remove_absolute(WINDOWS_PREF)
		windows_battery.clear()
		windows_battery.message = ""
		battery_message = ""
		_update_windows_option()
	elif not browser:
		return
	elif Input.get_connected_joypads().size() != 1:
		details.text = "Für die Zuordnung genau einen Controller verbinden."
	else:
		browser.read(true, Input.get_joy_name(Input.get_connected_joypads()[0]))

func _update_windows_option() -> void:
	battery_button.text = "Batteriewarnung deaktivieren" if windows_enabled else "Batteriewarnung aktivieren"
	details.text = "Batteriestand wird über Windows abgefragt." if windows_enabled else "Batteriestand über Windows abfragen."

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT: dragging_badge = false
	if what in [NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_APPLICATION_FOCUS_IN] and is_node_ready():
		_event("focus_gained" if what == NOTIFICATION_APPLICATION_FOCUS_IN else "focus_lost")

func _event(kind: String, device := -1) -> void:
	var now := Time.get_ticks_msec()
	while not events.is_empty() and (events.size() >= 256 or events[0].tick_ms < now - WINDOW_MS - POST_MS):
		events.pop_front()
	events.append({"tick_ms": now, "event": kind, "device": device})

func _connection_changed(device: int, connected: bool) -> void:
	_event("connected" if connected else "disconnected", device)
	if browser: browser.forgetSample()
	if windows_battery: windows_battery.clear()
	if not connected and device == last_device and active_pad:
		var now := Time.get_ticks_msec()
		if now - last_loss < WINDOW_MS: unstable_until = now + WINDOW_MS
		last_loss = now
		mark("controller_disconnected")
		_status("lost", "Gamepad getrennt", "red")
		player._pause_simulation()

func _begin_badge_drag(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		dragging_badge = true
		drag_offset = badge.get_global_transform_with_canvas() * event.position - badge.position
		badge.accept_event()

func _input(event: InputEvent) -> void:
	if dragging_badge:
		if event is InputEventMouseMotion:
			var room := (get_viewport().get_visible_rect().size - badge.size * badge.scale).max(Vector2.ZERO)
			badge.position = (event.position - drag_offset).clamp(Vector2.ZERO, room)
			badge_placement = badge.position / room.max(Vector2.ONE)
			get_viewport().set_input_as_handled()
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
			dragging_badge = false
			get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F8:
		mark("manual")
		get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	var now := Time.get_ticks_msec()
	if now < next_sample: return
	next_sample = now + SAMPLE_MS
	active_pad = player.keyboard_controls.is_gamepad()
	last_device = player.gamepad.device
	var unique_pad := Input.get_connected_joypads().size() == 1
	battery = -1
	if browser and unique_pad and last_device >= 0:
		browser.read(false, Input.get_joy_name(last_device))
		battery = int(browser.percent())
	var message := str(browser.message) if browser else ""
	if windows_battery and windows_enabled:
		if unique_pad and last_device >= 0:
			windows_battery.sample(now, Input.get_joy_name(last_device))
			battery = windows_battery.percent
			message = windows_battery.message
		else:
			windows_battery.clear()
			message = "Für die Windows-Abfrage genau ein Gamepad verbinden."
	if not message.is_empty() and message != battery_message:
		battery_message = message
		details.text = battery_message
	_refresh_indicator(now)
	var toolbar: Control = player.get_node("HUD").game_help.toolbar
	var extent := get_viewport().get_visible_rect().size
	badge.scale = Vector2.ONE * UiLayout.factor
	badge.reset_size()
	var edge_y := toolbar.position.y + (toolbar.size.y + 6) * UiLayout.factor
	var look_pad: Control = player.get_node("HUD").game_help.look_pad
	if look_pad.visible:
		edge_y = maxf(edge_y, look_pad.position.y + (look_pad.size.y + 4) * UiLayout.factor)
	caption.modulate = COLORS["yellow"] if state not in ["ok", "inactive"] and now - changed_at < 4000 else Color.WHITE
	if badge_placement.x < 0:
		badge.position = Vector2(extent.x - (badge.size.x + 12) * UiLayout.factor, edge_y)
	else:
		badge.position = (extent - badge.size * badge.scale).max(Vector2.ZERO) * badge_placement
	if state not in ["ok", "inactive"] and not acknowledged and now >= reminder_at:
		_pulse()
		reminder_at = now + 30000
	_record_sample(now)
	if pending_until >= 0 and now >= pending_until: _finish_report()

func _refresh_indicator(now: int) -> void:
	if not active_pad: _status("inactive", "Gamepad inaktiv", "yellow")
	elif last_device < 0: _status("lost", "Gamepad getrennt", "red")
	elif now < unstable_until: _status("unstable", "Gamepad instabil", "yellow")
	elif windows_enabled and windows_battery.reading.get("transport") == "usb": _status("ok", "Gamepad OK · USB", "green")
	elif battery < 0 and windows_enabled: _status("unknown", "Akkustand unklar", "yellow")
	elif battery < 0: _status("unknown", "Batteriewarnung aus", "yellow")
	elif battery <= 30: _status("low", "Gamepad-Akku %d %%" % battery, "yellow")
	else: _status("ok", "Gamepad-Akku %d %%" % battery, "green")

func _status(code: String, text: String, color: String) -> void:
	if windows_enabled and windows_battery and code in ["ok", "low", "unknown"] and windows_battery.reading.get("transport") == "wireless":
		text = windows_battery.source_label()
	caption.text = " " + text
	if state == code: return
	state = code
	_event(code, last_device)
	changed_at = Time.get_ticks_msec()
	acknowledged = false
	reminder_at = changed_at + 30000
	lamp.modulate = COLORS[color]
	if pulse: pulse.kill()
	lamp.self_modulate.a = 1.0
	if code not in ["ok", "inactive"]:
		_pulse()
		if browser: browser.beep()
		if code == "lost" and pending_until < 0: mark("controller_unavailable")

func _pulse() -> void:
	if pulse: pulse.kill()
	pulse = create_tween().set_loops(3)
	pulse.tween_property(lamp, "self_modulate:a", 0.35, 0.35)
	pulse.tween_property(lamp, "self_modulate:a", 1.0, 0.35)

func _ground_input(_dt: float, input: Vector3, _hold: bool, _flight_input: Vector2, _target: float) -> void:
	if player.flight_mode: return
	applied_steering = input.z
	applied_at = Time.get_ticks_msec()

func _record_sample(now: int) -> void:
	var cutoff := (pending_until - POST_MS if pending_until >= 0 else now) - WINDOW_MS
	while not history.is_empty() and history[0].tick_ms < cutoff:
		history.pop_front()
	var pad = player.gamepad
	history.append({
		"tick_ms": now, "state": state, "device": pad.device, "name": Input.get_joy_name(pad.device) if pad.device >= 0 else "",
		"stick_x": snappedf(pad.raw_steering.x, 0.001), "steering": snappedf(pad.steering.x, 0.001),
		"vehicle_steering": applied_steering if now - applied_at < SAMPLE_MS else null,
		"armed": pad.armed, "focused": player.has_focus, "paused": player.simulation_paused,
		"battery_percent": battery if battery >= 0 else null,
		"battery_read_utc": str(browser.timestamp()) if browser and battery >= 0 else "",
	})

	if windows_enabled and not windows_battery.reading.is_empty():
		history.back()["windows_reading"] = windows_battery.reading
		history.back()["battery_read_utc"] = windows_battery.timestamp

func mark(cause: String) -> void:
	_event(cause, last_device)
	if pending_until >= 0: return
	var now := Time.get_ticks_msec()
	marked_at = Time.get_datetime_string_from_system(true) + ".%03dZ" % (int(Time.get_unix_time_from_system() * 1000) % 1000)
	pending_until = now + POST_MS
	reason = cause
	details.text = "Störung markiert · Bericht wird ergänzt."

func _finish_report() -> void:
	var lines := PackedStringArray(["time_utc: " + JSON.stringify(marked_at), "reason: " + reason,
		"marker_tick_ms: %d" % (pending_until - POST_MS), "scene: " + JSON.stringify(scene), "build: " + JSON.stringify(build), "events:"])
	for event in events:
		if event.tick_ms >= pending_until - POST_MS - WINDOW_MS: lines.append("  - " + JSON.stringify(event))
	lines.append("samples:")
	for sample in history: lines.append("  - " + JSON.stringify(sample))
	last_report = "\n".join(lines) + "\n"
	pending_until = -1
	if browser: browser.save(last_report, marked_at)
	details.text = "Störungsbericht verfügbar."

func _show_report() -> void:
	if browser: browser.showReport()
	elif last_report.is_empty(): details.text = "Noch kein Störungsbericht vorhanden."
	else:
		DisplayServer.clipboard_set(last_report)
		details.text = "YAML in die Zwischenablage kopiert."

func cleanup() -> void:
	if pending_until >= 0: _finish_report()
	if browser: browser.dispose()
	if windows_battery: windows_battery.clear()
