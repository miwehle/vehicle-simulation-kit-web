extends RefCounted
## Windows Bluetooth battery property with an optional WinRT capacity cross-check.
const INTERVAL_MS := 60000
const TIMEOUT_MS := 15000
const COMMAND := r"""
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try {
    $report = $null
    $bluetooth = $null
    $transport = 'unknown'
    $raw = $null
    $pads = @()
    try {
        $null = [Windows.Gaming.Input.Gamepad,Windows.Gaming.Input,ContentType=WindowsRuntime]::Gamepads
        Start-Sleep -Milliseconds 350
        $pads = @(foreach ($pad in [Windows.Gaming.Input.Gamepad]::Gamepads) { $pad })
        if ($pads.Count -gt 1) { Write-Output '{}'; return }
        if ($pads.Count -eq 1) {
            $pad = $pads[0]
            $raw = [Windows.Gaming.Input.RawGameController,Windows.Gaming.Input,ContentType=WindowsRuntime]::FromGameController($pad)
            $r = $pad.TryGetBatteryReport()
            if ($null -ne $r.RemainingCapacityInMilliwattHours -and
                $r.FullChargeCapacityInMilliwattHours -gt 0 -and $r.RemainingCapacityInMilliwattHours -ge 0 -and
                $r.RemainingCapacityInMilliwattHours -le $r.FullChargeCapacityInMilliwattHours) {
                $report = [int][Math]::Round(100.0 * $r.RemainingCapacityInMilliwattHours / $r.FullChargeCapacityInMilliwattHours)
            }
        }
    } catch { } # Bluetooth properties can still be available without a WinRT report.
    $bt = @()
    if ($raw) {
        $model = 'VID_{0:X4}&PID_{1:X4}' -f $raw.HardwareVendorId,$raw.HardwareProductId
        if ($raw.IsWireless) {
            $transport = 'wireless'
            $hid = @(Get-PnpDevice -PresentOnly -Class HIDClass | Where-Object { $_.InstanceId -like ('HID\*' + $model + '*') })
            if ($hid.Count -eq 1 -and $hid[0].InstanceId -match '&([0-9A-F]{12})&') {
                $address = $Matches[1]
                $bt = @(Get-PnpDevice -PresentOnly -Class Bluetooth | Where-Object { $_.InstanceId -like ('BTHLE\DEV_' + $address + '\*') })
            }
        } elseif (Get-PnpDevice -PresentOnly -InstanceId ('USB\' + $model + '\*') -ErrorAction SilentlyContinue) {
            $transport = 'usb'
        }
    }
    if ($bt.Count -eq 0 -and $AllowXboxFallback -and (!$raw -or ($raw.IsWireless -and $raw.HardwareVendorId -eq 0x045e))) {
        # Godot confirmed exactly one active Xbox gamepad before starting this query.
        $bt = @(Get-PnpDevice -PresentOnly -Class Bluetooth -FriendlyName 'Xbox Wireless Controller' -ErrorAction SilentlyContinue)
        if ($bt.Count -eq 1) { $transport = 'wireless' }
    }
    if ($bt.Count -eq 1) {
        $v = (Get-PnpDeviceProperty -InstanceId $bt[0].InstanceId -KeyName '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2' -ErrorAction SilentlyContinue).Data
        if ($null -ne $v -and $v -ge 0 -and $v -le 100) { $bluetooth = [int]$v }
    }
    @{transport=$transport; gamepad_report=$report; bluetooth_property=$bluetooth} | ConvertTo-Json -Compress
} catch {
    Write-Output '{}'
}
"""
var reading := {}
var percent := -1
var timestamp := ""
var message := ""
var next_read := 0
var deadline := 0
var process := {}

func clear() -> void:
	if not process.is_empty() and OS.is_process_running(process.pid):
		OS.kill(process.pid)
	process.clear()
	reading = {}
	percent = -1
	timestamp = ""
	next_read = 0

func sample(now: int, device_name := "") -> void:
	if not process.is_empty():
		if not OS.is_process_running(process.pid):
			var result: String = process.stdio.get_as_text().strip_edges()
			process.clear()
			apply_result(result)
		elif now >= deadline:
			clear()
			next_read = now + INTERVAL_MS
			message = "Windows-Abfrage: Zeitlimit erreicht."
		return
	if now < next_read: return
	next_read = now + INTERVAL_MS
	deadline = now + TIMEOUT_MS
	var exe := OS.get_environment("SystemRoot").path_join("System32/WindowsPowerShell/v1.0/powershell.exe")
	var allow_xbox := device_name.to_lower().contains("xbox")
	var command := "$AllowXboxFallback = %s\n" % ("$true" if allow_xbox else "$false") + COMMAND
	process = OS.execute_with_pipe(exe, ["-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", Marshalls.raw_to_base64(command.to_utf16_buffer())], false)
	if process.is_empty():
		reading = {}
		percent = -1
		timestamp = ""
		message = "Windows-Batterieabfrage nicht verfügbar."



func apply_result(result: String) -> void:
	var data = JSON.parse_string(result) if result.begins_with("{") else {}
	reading = data if data is Dictionary else {}
	timestamp = Time.get_datetime_string_from_system(true) + "Z" if not reading.is_empty() else ""
	percent = -1
	if reading.get("transport") == "usb":
		message = "USB-Verbindung am PC bestätigt."
		return
	var report = reading.get("gamepad_report")
	var bluetooth = reading.get("bluetooth_property")
	message = "Akkustand unklar · Gamepadbericht: %s · Bluetooth: %s" % [_format(report), _format(bluetooth)]
	if reading.get("transport") != "wireless" or not _valid_percent(bluetooth):
		return
	if report != null and (not _valid_percent(report) or absf(report - bluetooth) > 20 or (report <= 30) != (bluetooth <= 30)):
		return
	percent = int(bluetooth) if report == null else mini(int(report), int(bluetooth))
	message = "Windows meldet %d %%" % percent

func _valid_percent(value: Variant) -> bool:
	return (value is int or value is float) and is_finite(float(value)) and value >= 0 and value <= 100

func source_label() -> String:
	return "Bluetooth: %s · WinRT: %s" % [_format(reading.get("bluetooth_property")), _format(reading.get("gamepad_report"))]

func _format(value: Variant) -> String:
	return "%d %%" % int(value) if _valid_percent(value) else "unbekannt"
