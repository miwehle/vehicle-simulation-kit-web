// Each scene owns one session. Only the latest report survives scene changes in RAM.
globalThis.OscherslebenGamepadMonitor = (() => {
  const key = "oschersleben.gamepad-monitor.device";
  let device, disposed = false, busy = false, lastRead = 0, attemptedAt = 0;
  let value = null, audio, dialog, gamepadName = "", generation = 0;
  const freshFor = 120000;
  const session = {
    message: "",
    percent() { return value !== null && Date.now() - lastRead < freshFor ? value : -1; },
    timestamp() { return lastRead ? new Date(lastRead).toISOString() : ""; },
    async read(choose, activeName) {
      if (disposed || busy || (!choose && Date.now() - attemptedAt < 60000)) return;
      if (!navigator.bluetooth) {
        session.message = "Batteriefreigabe in diesem Browser nicht verfügbar.";
        return;
      }
      const token = generation;
      attemptedAt = Date.now();
      busy = true;
      const timeout = setTimeout(() => {
        session.message = "Abfrage dauert länger · Steuerung bleibt verfügbar.";
      }, 12000);
      try {
        if (choose) {
          const selected = await navigator.bluetooth.requestDevice({
            acceptAllDevices: true, optionalServices: ["battery_service"]
          });
          if (disposed || token !== generation) return;
          if (device && device !== selected) device.gatt.disconnect();
          device = selected;
          value = null;
          lastRead = 0;
          gamepadName = activeName;
          try { localStorage.setItem(key, JSON.stringify({id: device.id, name: activeName})); } catch {}
        } else if (!device) {
          let saved;
          try { saved = JSON.parse(localStorage.getItem(key)); } catch {}
          if (!saved || saved.name !== activeName || !navigator.bluetooth.getDevices) return;
          const id = saved.id;
          gamepadName = saved.name;
          device = (await navigator.bluetooth.getDevices()).find(item => item.id === id);
        }
        if (!device || disposed || gamepadName !== activeName || generation !== token) return;
        const server = await device.gatt.connect();
        if (disposed) { server.disconnect(); return; }
        const service = await server.getPrimaryService("battery_service");
        const characteristic = await service.getCharacteristic("battery_level");
        const reading = await characteristic.readValue();
        if (disposed || token !== generation) return;
        const percent = reading.getUint8(0);
        if (percent > 100) throw Error("Ungültiger Prozentwert");
        value = percent;
        lastRead = Date.now();
        session.message = "Gelesen: " + percent + " % · " + device.name;
      } catch (error) {
        session.message = error.name === "NotFoundError" ? "Gerät oder Batteriedienst nicht ausgewählt bzw. gefunden." : "Batterieabfrage fehlgeschlagen.";
      } finally {
        clearTimeout(timeout);
        busy = false;
      }
    },
    forgetSample() { generation++; value = null; lastRead = 0; attemptedAt = 0; },
    beep() {
      try {
        audio ||= new AudioContext();
        if (audio.state === "suspended") audio.resume().catch(() => {});
        const tone = audio.createOscillator(), gain = audio.createGain();
        const now = audio.currentTime;
        tone.frequency.value = 620;
        gain.gain.setValueAtTime(0.06, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
        tone.connect(gain).connect(audio.destination);
        tone.start(now); tone.stop(now + 0.17);
      } catch {}
    },
    dispose() {
      disposed = true;
      dialog?.close();
      device?.gatt?.disconnect();
      audio?.close().catch(() => {});
    }
  };
  // Limit persisted incidents and serialize all writes, including writes after a scene change.
  const archive = globalThis.oscherslebenGamepadReports ||= createArchive();
  function createArchive() {
    let database, writing = false, pending = null;
    const reports = {last: null, status: ""};
    function open() {
      if (!database) database = new Promise((resolve, reject) => {
        const request = indexedDB.open("oschersleben-gamepad-monitor", 1);
        request.onupgradeneeded = () => request.result.createObjectStore("reports", {keyPath:"time"});
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      }).catch(error => { database = null; throw error; });
      return database;
    }
    reports.save = (yaml, time) => {
      reports.last = pending = {time, yaml};
      reports.status = "Nur in dieser Sitzung verfügbar";
      void flush();
    };
    async function flush() {
      if (writing) return;
      writing = true;
      try {
        while (pending) {
          const report = pending;
          pending = null;
          for (let attempt = 0; attempt < 3; attempt++) {
            try {
              const db = await open();
              await new Promise((resolve, reject) => {
                const tx = db.transaction("reports", "readwrite");
                tx.oncomplete = resolve;
                tx.onabort = () => reject(tx.error);
                const store = tx.objectStore("reports");
                store.put(report);
                let count = 0;
                const cursor = store.openKeyCursor(null, "prev");
                cursor.onsuccess = () => {
                  const row = cursor.result;
                  if (row) { if (++count > 20) store.delete(row.primaryKey); row.continue(); }
                };
              });
              if (reports.last === report) reports.status = "Lokal gespeichert";
              break;
            } catch {
              if (pending || attempt === 2) break;
              await new Promise(done => setTimeout(done, 1000 * (attempt + 1)));
            }
          }
        }
      } finally { writing = false; }
    }
    reports.latest = async () => {
      if (reports.last) return reports.last;
      const db = await open();
      return new Promise((resolve, reject) => {
        const request = db.transaction("reports").objectStore("reports").openCursor(null, "prev");
        request.onsuccess = () => resolve(request.result?.value);
        request.onerror = () => reject(request.error);
      });
    };
    return reports;
  }
  session.save = archive.save;
  session.showReport = async () => {
    dialog?.close();
    const box = document.createElement("dialog");
    dialog = box;
    box.style.cssText = "width:min(42rem,90vw);max-height:80vh;color:#eee;background:#20252c;padding:1rem";
    const title = document.createElement("strong");
    title.textContent = "Letzte Gamepad-Störung";
    const body = document.createElement("pre");
    body.style.cssText = "max-height:48vh;overflow:auto;user-select:text";
    body.textContent = "Bericht wird geladen …";
    function button(text, action) {
      const b = document.createElement("button");
      b.textContent = text; b.onclick = action; box.append(b);
      return b;
    }
    box.append(title, body);
    button("Schließen", () => box.close());
    box.onclose = () => box.remove();
    document.body.append(box); box.showModal();
    try {
      const report = await archive.latest();
      if (!box.open) return;
      if (!report) { body.textContent = "Noch kein Störungsbericht vorhanden."; return; }
      body.textContent = report.yaml;
      title.textContent += " · " + (archive.last === report ? archive.status : "Lokal gespeichert");
      button("YAML kopieren", async () => {
        try { await navigator.clipboard.writeText(report.yaml); }
        catch { const r = document.createRange(); r.selectNodeContents(body); getSelection().removeAllRanges(); getSelection().addRange(r); }
      });
      button("YAML herunterladen", () => {
        const link = document.createElement("a");
        const url = URL.createObjectURL(new Blob([report.yaml], {type:"application/yaml"}));
        link.href = url; link.download = "gamepad-" + report.time.replace(/:/g, "-") + ".yaml";
        link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      });
    } catch { body.textContent = "Lokaler Speicher nicht verfügbar."; }
  };
  return session;
})()
