/* Local-only, bounded history. Each point combines two completed 500 ms buckets.
 * Intervals are assigned by their endpoint; missing samples are gaps, not zero load.
 */
(() => {
  const limits = [18,25,1000/30,50,100,Infinity];
  const labels = ['≤ 18','> 18–25','> 25–33','> 33–50','> 50–100','> 100'];
  const colors = ['#58d5ad','#79baff','#c79cf0','#f5c15b','#ff9472','#ff72b0'];
  class FrameTimeline {
    constructor() {
      this.enabled = false;
      this.current = new Uint32Array(6);
      this.previous = new Uint32Array(6);
      this.history = Array.from({length:61},()=>new Float32Array(6));
      this.reset(0);
    }
    reset(now) {
      this.current.fill(0); this.previous.fill(0);
      this.history.forEach(point=>point.fill(NaN));
      this.start = now; this.next = now+500; this.head = 0; this.count = 0;
      if(this.enabled && this.canvas) this.draw();
    }
    setVisible(value, now) {
      if(this.enabled === value) return;
      this.enabled = value;
      if(value && !this.panel) this.mount();
      if(this.panel) this.panel.style.display = value ? 'block' : 'none';
      this.reset(now);
    }
    sample(now, ms) {
      if(!this.enabled) return;
      // Bound catch-up after suspended execution. Background transitions reset too.
      if(now-this.next>30000) this.reset(now);
      let changed = false;
      while(now>=this.next) {
        if(this.next-this.start>=1000) {
          let total = 0;
          for(let i=0;i<6;i++) total += this.current[i]+this.previous[i];
          const point = this.history[this.head];
          for(let i=0;i<6;i++) point[i] = total ? 100*(this.current[i]+this.previous[i])/total : NaN;
          this.head = (this.head+1)%61; this.count = Math.min(61,this.count+1);
        }
        this.previous.set(this.current); this.current.fill(0);
        this.next += 500; changed = true;
      }
      let category = 0;
      while(ms>limits[category]) category++;
      this.current[category]++;
      if(changed) this.draw();
    }
    mount() {
      this.panel = document.createElement('div');
      this.panel.style.cssText = 'position:fixed;left:10px;top:10px;z-index:9000;background:rgb(16 33 43 / var(--hud-background-opacity, 0.2));color:white;padding:8px;border-radius:8px;font:12px system-ui;pointer-events:none;box-sizing:border-box;width:min(286px,calc(100vw - 20px))';
      const title = document.createElement('div');
      title.textContent = 'Zeitverlauf · Framezeit (ms)';
      title.style.cssText = 'font-size:14px;font-weight:600';
      this.canvas = document.createElement('canvas');
      this.canvas.style.cssText = 'display:block;width:100%;height:150px';
      this.canvas.setAttribute('role','img');
      this.canvas.setAttribute('aria-label','Anteile der sechs Framezeitklassen in Prozent über die letzten 30 Sekunden; Framezeit in Millisekunden');
      const legend = document.createElement('div');
      legend.style.cssText = 'display:grid;grid-template-columns:repeat(3,1fr);gap:4px 8px;font-size:11px';
      labels.forEach((label,i)=>{
        const item = document.createElement('span');
        const swatch = document.createElement('span');
        swatch.textContent = '━ '; swatch.style.color = colors[i];
        item.append(swatch,document.createTextNode(label)); legend.appendChild(item);
      });
      const foot = document.createElement('div');
      foot.style.cssText = 'font-size:11px;color:#bdd3df;margin-top:6px';
      foot.textContent = '1-s-Fenster · alle '+window.OscherslebenUiNumber(0.5,1)+' s · keine Hardware-Auslastung';
      this.panel.append(title,this.canvas,legend,foot); document.body.appendChild(this.panel);
      this.disposeDrag = window.OscherslebenOverlayDrag(this.panel,'oschersleben.diagnostics.timeline.position');
      this.context = this.canvas.getContext('2d');
      this.observer = new ResizeObserver(()=>{if(this.enabled) this.draw();});
      this.observer.observe(this.canvas);
    }
    draw() {
      const ctx = this.context;
      if(!ctx) return;
      const width = this.canvas.clientWidth, height = 150;
      if(!width) return;
      const dpr = Math.min(window.devicePixelRatio || 1,2);
      if(this.canvas.width!==Math.round(width*dpr) || this.canvas.height!==Math.round(height*dpr)) {
        this.canvas.width = Math.round(width*dpr); this.canvas.height = Math.round(height*dpr);
      }
      ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,width,height);
      const left = 34, right = width-8, top = 21, bottom = 126;
      ctx.font = '11px system-ui'; ctx.fillStyle = '#dce9f1'; ctx.textAlign = 'left';
      ctx.fillText('Anteil (%)',0,12);
      for(const value of [0,50,100]) {
        const y = bottom-value/100*(bottom-top);
        ctx.strokeStyle = '#47606e'; ctx.lineWidth = .5;
        ctx.beginPath(); ctx.moveTo(left,y); ctx.lineTo(right,y); ctx.stroke();
        ctx.textAlign = 'right'; ctx.fillText(String(value),left-5,y+4);
      }
      for(const age of [30,20,10,0]) {
        const x = right-age/30*(right-left);
        ctx.textAlign = age===30?'left':age===0?'right':'center';
        ctx.fillText(age ? '−'+age+' s' : 'Jetzt',x,145);
      }
      for(let series=0;series<6;series++) {
        ctx.strokeStyle = colors[series]; ctx.lineWidth = 1.5; ctx.beginPath();
        let connected = false;
        for(let i=0;i<this.count;i++) {
          const value = this.history[(this.head-this.count+i+61)%61][series];
          if(!Number.isFinite(value)) {connected=false;continue;}
          const x = right-(this.count-1-i)/60*(right-left), y = bottom-value/100*(bottom-top);
          if(connected) ctx.lineTo(x,y); else ctx.moveTo(x,y);
          connected = true;
        }
        ctx.stroke();
      }
      if(this.count<2) {
        ctx.textAlign = 'center'; ctx.fillStyle = '#dce9f1';
        ctx.fillText('Sammle Framezeiten …',(left+right)/2,75);
      }
    }
    dispose() {
      if(this.observer) this.observer.disconnect();
      if(this.disposeDrag) this.disposeDrag();
      if(this.panel) this.panel.remove();
    }
  }
  if(typeof module!=='undefined' && module.exports) module.exports = FrameTimeline;
  else window.OscherslebenFrameTimeline = FrameTimeline;
})();
