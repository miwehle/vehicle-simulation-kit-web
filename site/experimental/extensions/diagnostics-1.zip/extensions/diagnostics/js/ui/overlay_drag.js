/* Explicit edit mode prevents steering touches from moving the diagnostics. */
window.OscherslebenOverlayDrag = function(panel, key = 'oschersleben.diagnostics.position') {
  const button = document.createElement('button');
  function showLock(editable) {
    const label = editable ? 'Position fixieren' : 'Verschieben erlauben';
    button.title = label; button.setAttribute('aria-label',label);
    button.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" style="pointer-events:none"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="'+(editable ? 'M8 10V6a4 4 0 0 1 8 0' : 'M8 10V6a4 4 0 0 1 8 0v4')+'"/><path d="M12 14v3"/></svg>';
  }
  showLock(false);
  button.type = 'button';
  button.style.cssText = 'display:block;margin:0 0 6px auto;padding:5px;width:32px;height:32px;font:12px system-ui;color:#bdeaff;background:#233c49;border:1px solid #60808f;border-radius:4px;pointer-events:auto;touch-action:none';
  button.setAttribute('aria-pressed','false');
  panel.prepend(button);
  let editable = false, drag = null, position = null;
  try {
    const saved = JSON.parse(localStorage.getItem(key));
    if(saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) position = saved;
  } catch (_) {}
  function place() {
    if(!position || !panel.offsetWidth) return;
    position.x = Math.max(0,Math.min(position.x,innerWidth-panel.offsetWidth));
    position.y = Math.max(0,Math.min(position.y,innerHeight-panel.offsetHeight));
    panel.style.left = position.x+'px'; panel.style.top = position.y+'px';
    panel.style.bottom = 'auto';
  }
  function save() {
    try {localStorage.setItem(key,JSON.stringify(position));} catch (_) {}
  }
  button.addEventListener('pointerdown',event=>event.stopPropagation());
  button.addEventListener('pointerup',event=>event.stopPropagation());
  button.addEventListener('click',event=>{
    event.stopPropagation(); editable = !editable;
    if(drag) {
      const id = drag.id; drag = null;
      if(panel.hasPointerCapture(id)) panel.releasePointerCapture(id);
      save();
    }
    showLock(editable);
    button.setAttribute('aria-pressed',String(editable));
    panel.style.pointerEvents = editable ? 'auto' : 'none';
    panel.style.touchAction = 'none';
    panel.style.cursor = editable ? 'move' : '';
    panel.style.outline = editable ? '2px dashed #67cfff' : '';
  });
  function down(event) {
    if(!editable || event.target===button || drag || event.button!==0) return;
    event.preventDefault(); event.stopPropagation();
    const rect = panel.getBoundingClientRect();
    drag = {id:event.pointerId,x:event.clientX-rect.left,y:event.clientY-rect.top};
    panel.setPointerCapture(event.pointerId);
  }
  function move(event) {
    if(!drag || event.pointerId!==drag.id) return;
    event.preventDefault(); event.stopPropagation();
    position = {x:event.clientX-drag.x,y:event.clientY-drag.y}; place();
  }
  function up(event) {
    if(!drag || event.pointerId!==drag.id) return;
    event.stopPropagation(); drag = null; save();
    if(panel.hasPointerCapture(event.pointerId)) panel.releasePointerCapture(event.pointerId);
  }
  panel.addEventListener('pointerdown',down);
  panel.addEventListener('pointermove',move);
  panel.addEventListener('pointerup',up);
  panel.addEventListener('pointercancel',up);
  panel.addEventListener('lostpointercapture',up);
  const observer = new ResizeObserver(place); observer.observe(panel);
  window.addEventListener('resize',place);
  return () => {observer.disconnect();window.removeEventListener('resize',place);};
};
