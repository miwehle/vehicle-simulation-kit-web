/* Browser display only; measurement and recording stay in performance.js. */
window.OscherslebenFrameHistogram = function () {
  const panel = document.createElement('div');
  panel.style.cssText = 'position:fixed;left:10px;bottom:10px;z-index:9000;background:rgb(16 33 43 / var(--hud-background-opacity, 0.2));color:white;padding:8px;border-radius:8px;font:13px system-ui;pointer-events:none;display:none;box-sizing:border-box;width:min(286px,calc(100vw - 20px));white-space:pre-line';
  const heading = document.createElement('div');
  heading.textContent = 'Framezeit (ms)';
  heading.style.cssText = 'font:600 16px system-ui;margin:0 0 8px';
  const values = document.createElement('div');
  values.style.cssText = 'font:600 22px system-ui;margin:2px 0 14px';
  values.textContent = 'EMA –';
  const caption = document.createElement('div');
  caption.textContent = 'P95'; caption.style.cssText = 'font:11px system-ui;color:#bdd3df';
  const meter = document.createElement('div');
  meter.style.cssText = 'height:8px;background:linear-gradient(to right,#48bd76 0 33.3333%,#e9ba48 33.3333% 66.6667%,#e35b52 66.6667% 100%);position:relative;margin:6px 0';
  const marker = document.createElement('span');
  marker.style.cssText = 'position:absolute;top:-3px;width:3px;height:14px;background:white;transform:translateX(-50%);display:none';
  if(!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) marker.style.transition='left 0.2s linear';
  meter.appendChild(marker);
  const scale = document.createElement('div');
  scale.style.cssText = 'position:relative;height:14px;font:11px system-ui;color:#bdd3df';
  const scaleLabels = ['left:0','left:33.3333%;transform:translateX(-50%)','left:66.6667%;transform:translateX(-50%)','right:0'].map((style,i)=>{
    const label = document.createElement('span'); label.style.cssText='position:absolute;'+style;
    label.textContent=String(10+i*10)+(i===3?' ms':'');
    scale.appendChild(label); return label;
  });
  panel.append(heading,values,caption,meter,scale); document.body.appendChild(panel);
  const chart = document.createElement('div');
  chart.style.cssText = 'display:flex;gap:4px;height:86px;margin-top:20px;white-space:normal';
  const labels = ['17','25','33','50','100','>100'];
  const bars = labels.map(labelText => {
    const column = document.createElement('div');
    column.style.cssText = 'flex:1;min-width:0;display:flex;flex-direction:column;justify-content:flex-end;text-align:center;font-size:11px';
    const percent = document.createElement('div');
    const bar = document.createElement('div');
    bar.style.cssText = 'background:#67cfff;min-height:1px';
    const label = document.createElement('div'); label.textContent = labelText;
    column.append(percent,bar,label); chart.appendChild(column);
    return {percent,bar};
  });
  const legend = document.createElement('div');
  legend.style.cssText = 'font-size:11px;color:#bdd3df;margin-top:4px';
  legend.textContent = 'Letzte 10 s';
  panel.append(chart,legend);
  const disposeDrag = window.OscherslebenOverlayDrag(panel);
  return {
    setVisible(visible) { panel.style.display=visible?'block':'none'; },
    reset(preserveMotionHistory=false) {
      if(!preserveMotionHistory) values.textContent='EMA –';
      marker.style.display='none';
    },
    update(stats, counts, ema) {
      marker.style.left=Math.min(100,Math.max(0,100*(stats.p95-10)/30))+'%';
      marker.style.display=stats.n?'block':'none';
      values.textContent=ema!==null?'EMA '+window.OscherslebenUiNumber(ema,1):'EMA –';
      bars.forEach((item,i)=>{
        const share=stats.n?counts[i]/stats.n:0;
        item.percent.textContent=Math.round(share*100)+'%';
        item.bar.style.height=(share*55)+'px';
      });
    },
    dispose() { disposeDrag();panel.remove(); }
  };
};
