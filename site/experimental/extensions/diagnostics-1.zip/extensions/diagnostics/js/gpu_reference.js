/* Fixed offscreen workload v2. Change VERSION when changing the workload.
 * Elapsed GPU queries only: no wall-clock fallback and no gl.finish(). */
(() => {
  const VERSION = 'webgl2-fragment-v2';
  const PASSES = 128;
  const wait = () => new Promise(resolve => setTimeout(resolve, 10));
  function stats(samples) {
    const sorted = [...samples].sort((a, b) => a - b);
    return {samples_us: samples, median_us: sorted[Math.floor(sorted.length / 2)],
      spread: sorted.at(-1) / sorted[0]};
  }
  async function sample() {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 512;
    const gl = canvas.getContext('webgl2', {antialias: false, depth: false, stencil: false});
    const ext = gl?.getExtension('EXT_disjoint_timer_query_webgl2');
    const result = {version: VERSION, resolution: [512, 512], passes: PASSES, iterations: 32, warmups: 30};
    const debug = gl?.getExtension('WEBGL_debug_renderer_info');
    result.renderer = gl ? gl.getParameter(debug ? debug.UNMASKED_RENDERER_WEBGL : gl.RENDERER) : null;
    let hidden = document.hidden, query = null;
    const visibility = () => { hidden ||= document.hidden; };
    const shaders = [];
    let program = null;
    document.addEventListener('visibilitychange', visibility);
    function valid() {
      if (hidden || document.hidden) throw Error('hidden');
      if (gl.isContextLost()) throw Error('context_lost');
      if (gl.getParameter(ext.GPU_DISJOINT_EXT)) throw Error('disjoint');
    }
    try {
      if (!ext) return {...result, status: 'unsupported'};
      valid();
      function shader(type, source) {
        const s = gl.createShader(type); shaders.push(s);
        gl.shaderSource(s, source); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error('shader_compile_failed');
        return s;
      }
      program = gl.createProgram();
      gl.attachShader(program, shader(gl.VERTEX_SHADER, `#version 300 es
        void main() {
          vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
          gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
        }`));
      gl.attachShader(program, shader(gl.FRAGMENT_SHADER, `#version 300 es
        precision highp float;
        uniform float seed;
        out vec4 color;
        void main() {
          vec2 p = gl_FragCoord.xy / 512.0 + vec2(seed);
          for (int i = 0; i < 32; i++)
            p = fract(vec2(p.x * p.y + 0.137, p.x + p.y * 0.731) * 1.917);
          color = vec4(p, fract(p.x + p.y), 1.0);
        }`));
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('shader_link_failed');
      gl.useProgram(program); gl.viewport(0, 0, 512, 512);
      // Blending makes every pass contribute; the driver cannot discard earlier passes.
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
      const seed = gl.getUniformLocation(program, 'seed');
      const samples = [];
      const totalDeadline = performance.now() + 20000;
      for (let repeat = 0; repeat < 39; repeat++) {
        valid();
        query = gl.createQuery();
        if (!query) throw Error('query_unavailable');
        gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.beginQuery(ext.TIME_ELAPSED_EXT, query);
        for (let pass = 0; pass < PASSES; pass++) {
          gl.uniform1f(seed, (pass % 8) / 32);
          gl.drawArrays(gl.TRIANGLES, 0, 3);
        }
        gl.endQuery(ext.TIME_ELAPSED_EXT); gl.flush();
        const deadline = performance.now() + 5000;
        // WebGL query availability requires returning to the browser event loop.
        do {
          await wait(); valid();
          if (performance.now() > deadline || performance.now() > totalDeadline) throw Error('timeout');
        } while (!gl.getQueryParameter(query, gl.QUERY_RESULT_AVAILABLE));
        const us = gl.getQueryParameter(query, gl.QUERY_RESULT) / 1000;
        gl.deleteQuery(query); query = null;
        if (!Number.isFinite(us) || us <= 0) throw Error('invalid_time');
        if (repeat >= 30) samples.push(us); // Thirty warmups, nine measured batches.
      }
      valid();
      return {...result, status: 'ok', ...stats(samples)};
    } catch (error) {
      return {...result, status: error.message};
    } finally {
      document.removeEventListener('visibilitychange', visibility);
      if (query) gl.deleteQuery(query);
      if (program) gl.deleteProgram(program);
      for (const s of shaders) gl.deleteShader(s);
      gl?.getExtension('WEBGL_lose_context')?.loseContext();
    }
  }
  window.VehicleGpuReference = {sample};
})();
