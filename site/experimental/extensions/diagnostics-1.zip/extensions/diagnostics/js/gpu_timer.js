/* WebGL2 elapsed queries bracket Godot's render pass. Never wait for the GPU.
 * Godot's GLES timestamp profiler does not provide GPU timestamps on Web. */
(() => {
  class GpuTimer {
    constructor(onSample, getContext) {
      this.onSample=onSample;
      this.getContext=getContext || (()=>document.querySelector('canvas')?.getContext('webgl2'));
      this.gl=null;this.ext=null;this.pending=[];this.current=null;
      this.status='unchecked';this.next=0;
    }
    begin(now) {
      if(now<this.next) return false;
      this.next=now+250;
      if(this.status==='unavailable') return false;
      if(!this.gl) {
        this.gl=this.getContext();
        this.ext=this.gl?.getExtension('EXT_disjoint_timer_query_webgl2');
        if(!this.ext) {this.status='unavailable';return false;}
        this.status='waiting';
      }
      const gl=this.gl, ext=this.ext;
      if(gl.isContextLost()) {this.reset();this.gl=null;this.ext=null;this.status='context_lost';return false;}
      if(gl.getParameter(ext.GPU_DISJOINT_EXT)) {
        this.reset();this.status='disjoint';return false;
      }
      // Read only completed queries; results are nanoseconds, not CPU wall time.
      while(this.pending.length && gl.getQueryParameter(this.pending[0].query,gl.QUERY_RESULT_AVAILABLE)) {
        const item=this.pending.shift();
        const ms=gl.getQueryParameter(item.query,gl.QUERY_RESULT)/1e6;
        gl.deleteQuery(item.query);
        if(Number.isFinite(ms) && ms>0) {this.status='ready';this.onSample(ms,item.time);}
      }
      if(this.pending.length && now-this.pending[0].time>5000) {this.reset();this.status='timeout';}
      // Do not interfere with another profiler, or grow an unbounded query queue.
      if(this.current || this.pending.length>=4 || gl.getQuery(ext.TIME_ELAPSED_EXT,gl.CURRENT_QUERY)) return false;
      const query=gl.createQuery();
      if(!query) {this.status='unavailable';return false;}
      gl.beginQuery(ext.TIME_ELAPSED_EXT,query);
      this.current={query,time:now};return true;
    }
    end() {
      if(!this.current) return;
      this.gl.endQuery(this.ext.TIME_ELAPSED_EXT);
      this.pending.push(this.current);this.current=null;
    }
    reset() {
      if(this.current) {this.end();}
      if(this.gl) for(const item of this.pending) this.gl.deleteQuery(item.query);
      this.pending=[];
      if(this.status==='ready') this.status='waiting';
    }
  }
  if(typeof module!=='undefined') module.exports=GpuTimer;
  else window.OscherslebenGpuTimer=GpuTimer;
})();
