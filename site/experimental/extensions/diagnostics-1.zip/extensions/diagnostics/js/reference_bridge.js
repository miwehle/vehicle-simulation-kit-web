/* DOM progress remains visible while Godot's rendering and scene tree are paused. */
(() => {
  let panel, hidden = false, gpu, generation = 0;
  const visibility = () => { hidden ||= document.hidden; };
  window.VehicleReferenceBridge = {
    done: false,
    begin() {
      hidden = document.hidden; this.done = false; gpu = null;
      document.addEventListener('visibilitychange', visibility);
      panel = document.createElement('div');
      panel.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#19212a;color:white;display:grid;place-items:center;font:22px system-ui;text-align:center;padding:24px';
      panel.textContent = 'CPU-Referenzmessung läuft … Bitte im Vordergrund bleiben.';
      (document.fullscreenElement || document.body).appendChild(panel);
    },
    startGpu() {
      panel.textContent = 'GPU-Referenzmessung läuft … Bitte im Vordergrund bleiben.';
      const current = ++generation;
      window.VehicleGpuReference.sample().then(value => {
        if (current === generation) { gpu = value; this.done = true; }
      }).catch(() => {
        if (current === generation) { gpu = {status: 'error'}; this.done = true; }
      });
    },
    finish(cpuJson) {
      const cpu = JSON.parse(cpuJson);
      if (hidden || document.hidden) { cpu.status = 'hidden'; gpu.status = 'hidden'; }
      const result = JSON.stringify({utc: Date.now(), cpu, gpu});
      this.dispose(); return result;
    },
    dispose() {
      generation++; document.removeEventListener('visibilitychange', visibility);
      panel?.remove(); panel = null;
    },
  };
})();
