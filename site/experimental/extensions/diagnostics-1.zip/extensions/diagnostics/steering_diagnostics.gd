extends PanelContainer

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
## Local, frame-sampled stick diagnostics. Does not change input or send data.
var pad
var trigger_mode := false
var brake_mode := false
var values := Label.new()
var result := Label.new()
var measure := Button.new()
var meter := RawMeter.new()
var remaining := 0.0
var peak_x := 0.0
var peak_radius := 0.0
var samples := 0
var measurement_device := -1
var measurement_right := true
var position_file := 'user://steering_diagnostics_position.cfg'
var move_button := Button.new()
var dragging := false
var drag_offset := Vector2.ZERO

class RawMeter extends Control:
	var raw := 0.0
	var dead_zone := 0.03
	var trigger_mode := false
	func _draw():
		var middle := 0.0 if trigger_mode else size.x / 2.0
		if trigger_mode:
			draw_rect(Rect2(0, 4, size.x, 20), Color('#263643'))
			draw_rect(Rect2(0, 4, size.x * dead_zone / 0.10, 20), Color('#425968'))
			var x := clampf(raw / 0.10, 0, 1) * size.x
			draw_line(Vector2(x, 2), Vector2(x, 26), Color('#28c7f4'), 3)
			return
		draw_rect(Rect2(0, 4, size.x, 20), Color('#263643'))
		var half_zone := minf(dead_zone / 0.10, 1.0) * middle
		draw_rect(Rect2(middle - half_zone, 4, half_zone * 2, 20), Color('#425968'))
		draw_line(Vector2(middle, 0), Vector2(middle, 28), Color.WHITE, 1)
		var x := middle + clampf(raw / 0.10, -1, 1) * middle
		draw_line(Vector2(x, 2), Vector2(x, 26), Color('#28c7f4'), 3)

func _ready():
	UiLayout.bind_hud.call_deferred(self)
	if brake_mode: trigger_mode = true
	if trigger_mode: position_file = 'user://throttle_diagnostics_position.cfg'
	if brake_mode: position_file = 'user://brake_diagnostics_position.cfg'
	meter.trigger_mode = trigger_mode
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	position = Vector2(get_viewport_rect().size.x - 400, 420 if trigger_mode else 90)
	if brake_mode: position.x = 20
	var saved := ConfigFile.new()
	if saved.load(position_file) == OK:
		var value = saved.get_value('panel', 'position', position)
		if value is Vector2 and value.is_finite(): position = value
	get_viewport().size_changed.connect(_clamp_position)
	resized.connect(_clamp_position)
	visibility_changed.connect(func(): dragging = false)
	custom_minimum_size.x = 380
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.025, 0.045, 0.065, 0.96)
	style.set_content_margin_all(12)
	add_theme_stylebox_override('panel', style)
	var rows := VBoxContainer.new()
	add_child(rows)
	move_button.toggle_mode = true
	move_button.icon = preload('res://ui/icons/lock_icon.svg')
	move_button.tooltip_text = 'Verschieben erlauben'
	move_button.custom_minimum_size = Vector2(32, 32)
	move_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	move_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	move_button.toggled.connect(func(editable):
		dragging = false
		move_button.icon = preload('res://ui/icons/unlock_icon.svg') if editable else preload('res://ui/icons/lock_icon.svg')
		move_button.tooltip_text = 'Position fixieren' if editable else 'Verschieben erlauben'
		mouse_default_cursor_shape = Control.CURSOR_MOVE if editable else Control.CURSOR_ARROW)
	rows.add_child(move_button)
	rows.add_child(values)
	meter.custom_minimum_size = Vector2(340, 30)
	rows.add_child(meter)
	var legend := Label.new()
	legend.text = 'Rohwert: −10 %  |  Mitte  |  +10 %\nGrau: Totzone · rechts positiv'
	if trigger_mode: legend.text = 'Rohwert: 0 % bis 10 % (vergrößert)\nGrau: Gas-Totzone'
	if brake_mode: legend.text = 'Rohwert: 0 % bis 10 % (vergrößert)\nGrau: Brems-Totzone'
	rows.add_child(legend)
	measure.text = 'Ruhe messen · 10 s'
	measure.pressed.connect(start_measurement)
	rows.add_child(measure)
	result.text = 'Trigger loslassen; nach Drücken wiederholen.' if trigger_mode else 'Stick loslassen; nach Ausschlägen wiederholen.'
	rows.add_child(result)
	for label in [values, legend, result]:
		label.add_theme_font_size_override('font_size', 16)
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rows.mouse_filter = Control.MOUSE_FILTER_PASS
	meter.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hide()
	_clamp_position.call_deferred()

func _clamp_position():
	if not is_inside_tree(): return
	var limit := (get_viewport_rect().size - size).max(Vector2.ZERO)
	position = position.clamp(Vector2.ZERO, limit)

func _gui_input(event: InputEvent):
	if not move_button.button_pressed: return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		dragging = event.pressed
		if dragging:
			drag_offset = event.position
		elif not SimulationLibrary.temporary:
			var saved := ConfigFile.new()
			saved.set_value('panel', 'position', position)
			saved.save(position_file)
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		position += event.position - drag_offset
		_clamp_position()
		accept_event()

func start_measurement():
	if pad == null or pad.device < 0: return
	remaining = 10.0
	peak_x = 0
	peak_radius = 0
	samples = 0
	measurement_device = pad.device
	measurement_right = pad.steer_right

func sample(raw: Vector2, delta: float, valid: bool):
	if remaining <= 0: return
	if not valid:
		remaining = 0
		result.text = 'Messung abgebrochen – erneut starten.'
		return
	peak_x = maxf(peak_x, absf(raw.x))
	peak_radius = maxf(peak_radius, raw.length())
	samples += 1
	remaining = maxf(0, remaining - delta)
	result.text = UiNumbers.display(('%s loslassen · noch %.1f s' % ['Trigger' if trigger_mode else 'Stick', remaining]) if remaining > 0 else ('Maximum: seitlich %.2f %% · radial %.2f %%\n%d Messwerte; keine automatische Kalibrierung.' % [peak_x * 100, peak_radius * 100, samples]))

	if trigger_mode and remaining == 0:
		result.text = UiNumbers.display('Letzte Ruhemessung: Maximum %.2f %%\n%d Messwerte; keine automatische Kalibrierung.' % [peak_x * 100, samples])

func refresh(delta: float, active: bool, focused: bool, output_active: bool):
	if not visible: return
	var connected: bool = pad.device >= 0 and active
	measure.disabled = not connected or not focused or remaining > 0
	values.text = UiNumbers.display(('%s Stick · Lenk-Totzone %.0f %%\nRoh X: %+.2f %% · Y: %+.2f %%\nLenkbefehl: %+.2f %% %s' % [
		'Rechter' if pad.steer_right else 'Linker', pad.STEERING_DEAD_ZONE * 100,
		pad.raw_steering.x * 100, pad.raw_steering.y * 100,
		pad.steering.x * 100 if output_active and pad.armed else 0.0,
		'' if output_active and pad.armed else '(inaktiv)']) if connected else 'Kein aktives Gamepad')
	meter.raw = pad.raw_steering.x if connected else 0.0
	meter.dead_zone = pad.STEERING_DEAD_ZONE
	var trigger_raw: float = pad.raw_brake if brake_mode else pad.raw_throttle
	if trigger_mode:
		var command: float = pad.brake if brake_mode else pad.throttle
		var dead_zone: float = (pad.BRAKE_DEAD_ZONE if pad.driving else 0.05) if brake_mode else (pad.THROTTLE_DEAD_ZONE if pad.driving else 0.05)
		values.text = UiNumbers.display(('%s · Totzone %.0f %%\nRohwert: %.2f %%\n%s: %.2f %% %s' % ['Brems-Trigger (LT/L2)' if brake_mode else 'Gas-Trigger (RT/R2)', dead_zone * 100, trigger_raw * 100, 'Bremsbefehl' if brake_mode else 'Gasbefehl', command * 100 if output_active and pad.armed else 0.0, '' if output_active and pad.armed else '(inaktiv)']) if connected else 'Kein aktives Gamepad')
		meter.raw = trigger_raw if connected else 0.0
		meter.dead_zone = dead_zone
	meter.queue_redraw()
	sample(Vector2(trigger_raw, 0) if trigger_mode else pad.raw_steering, delta, connected and focused and pad.device == measurement_device and (trigger_mode or pad.steer_right == measurement_right))
