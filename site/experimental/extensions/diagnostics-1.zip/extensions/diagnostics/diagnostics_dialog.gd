extends "res://ui/dialogs/dialog_panel.gd"

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
## Changes remain a draft until the user applies them; recording belongs to diagnostics.
signal apply_requested(display: bool, performance_recording: bool, ground_recording: bool, target: int, device: String, timeline: bool, minimal_enabled: bool)
var display_option: CheckBox
var performance_option: CheckBox
var ground_option: CheckBox
var timeline_option: CheckBox
var minimal_option: CheckBox
var minimal_result_label: Label
var minimal_copy: Button
var target_option: OptionButton
var status_label: Label
var device_name: LineEdit
var environment_label: Label
var details_button: Button
var details: VBoxContainer
const TARGETS := [30, 60, 90, 120]

func _ready() -> void:
	var rows := build("DIAGNOSE", hide, _apply)
	add_header_separator()
	rows.add_theme_constant_override("separation", 12)
	var display_rows := _section(rows, "ANZEIGEN")
	display_option = _check(display_rows, "Framezeiten – Wert und Histogramm")
	timeline_option = _check(display_rows, "Framezeiten – Zeitverlauf")

	var recording_rows := _section(rows, "AUFZEICHNEN")
	_heading(recording_rows, "Cloud")
	performance_option = _check(recording_rows, "Leistung")
	_hint(recording_rows, "Beim Starten und Stoppen kurze Referenzmessung; die Fahrt bleibt dabei pausiert.")
	var target_margin := MarginContainer.new()
	target_margin.add_theme_constant_override("margin_left", 24)
	recording_rows.add_child(target_margin)
	var target_rows := VBoxContainer.new()
	target_rows.add_theme_constant_override("separation", 6)
	target_margin.add_child(target_rows)
	_text(target_rows, "Ziel-Framezeit")
	target_option = add_option_button(target_rows)
	target_option.fit_to_longest_item = false
	target_option.clip_text = true
	for fps in TARGETS:
		target_option.add_item(UiNumbers.display("%.1f ms (%d FPS)" % [1000.0 / fps, fps]))
	_hint(target_rows, "Vergleichswert, keine FPS-Begrenzung.")
	ground_option = _check(recording_rows, "Bodenprobleme")
	_text(recording_rows, "Gerätename")
	device_name = LineEdit.new()
	device_name.placeholder_text = "Notebook oder Tablet"
	device_name.max_length = 80
	device_name.custom_minimum_size.y = 48
	device_name.add_theme_font_size_override("font_size", 20)
	recording_rows.add_child(device_name)

	recording_rows.add_child(HSeparator.new())
	_heading(recording_rows, "Lokal")
	minimal_option = _check(recording_rows, "Minimalmessung")
	_hint(recording_rows, "Ohne Anzeige und ohne Upload.")
	minimal_result_label = _text(recording_rows, "")
	minimal_copy = add_action_button(recording_rows, "Ergebnis kopieren", func(): DisplayServer.clipboard_set(minimal_result_label.text))
	update_minimal_result(null)

	details_button = add_action_button(rows, "Details zur Diagnose")
	details_button.icon = preload("res://ui/icons/expand_icon.svg")
	details_button.toggle_mode = true
	details_button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	details = VBoxContainer.new()
	details.add_theme_constant_override("separation", 12)
	details.hide()
	rows.add_child(details)
	details_button.toggled.connect(func(expanded: bool):
		details.visible = expanded
		details_button.icon = preload("res://ui/icons/collapse_icon.svg") if expanded else preload("res://ui/icons/expand_icon.svg"))
	environment_label = _text(details, "")
	_text(details, "Alle Optionen sind unabhängig. Änderungen werden erst mit Übernehmen aktiviert. Zum Stoppen einer Aufnahme die entsprechende Option abwählen und übernehmen.")
	_text(details, "Gerätename: optional und lokal gespeichert; während einer Cloud-Aufnahme gesperrt. Die Geräteart für den P-Check wird automatisch ermittelt; unsichere Erkennung bleibt unbekannt. Akku und Ladezustand werden, soweit verfügbar, automatisch ergänzt. Temperatur und Drosselung werden nicht gemessen.")
	_text(details, "Die Startzeit wird immer lokal gemessen und bei aktivierter Cloud-Leistung einmal pro App-Start übertragen, auch bei späterer Aktivierung.")
	_text(details, "Leistung: 30-Sekunden-Blöcke mit Runde, Rundenzeit und Geschwindigkeit. Fahren, Stillstand (unter 1 km/h), Flug, Pause und Hintergrund werden getrennt. Ein Rundenwechsel beginnt einen neuen Block; Versand einmal pro Minute. Cloud-Aufnahmen enden spätestens nach 55 Minuten.")
	_text(details, "Referenzmessung: CPU und, falls im Browser verfügbar, GPU werden vor und nach der Leistungsaufnahme gemessen. Dabei stehen Fahrt und Streckendarstellung still; diese Zeit zählt nicht zu den Fahrdaten. Bitte im Vordergrund bleiben. Die Messung wärmt das Gerät auf; das Verhalten direkt nach Standby muss separat geprüft werden.")
	_text(details, "Bodenprobleme: Bei einem Fehler werden die letzten fünf Sekunden der Fahrt und die Bodenmessungen in Firebase gespeichert. Maximal 20 Ereignisse pro Aufnahme; ähnliche Stopps werden zusammengefasst.")
	_text(details, "Minimalmessung: ohne laufende Anzeige und ohne Versand. Pausen und Hintergrund zählen nicht mit. Das Ergebnis bleibt bis zur nächsten Minimalmessung erhalten und kann kopiert werden.")
	_text(details, UiNumbers.display("Der Zeitverlauf bleibt lokal und zeigt die letzten 30 Sekunden. Framezeiten zeigen Regelmäßigkeit, keine Hardware-Auslastung. CPU misst nur Fahrcontroller, Kamera und HUD. Der Zielwert ist ein Vergleichsmaßstab, keine Begrenzung. P95-Ampel: feste Skala 10.0–40.0 ms; Grün bis 20.0 ms, Gelb bis 30.0 ms, darüber Rot. Sie ist unabhängig vom Zielwert."))
	_text(details, "Aufnahmen sind nach jedem Laden aus. Ungesendete Daten können beim Schließen der App verloren gehen.")
	rows.add_child(HSeparator.new())
	_hint(rows, "✓ übernimmt · × verwirft Änderungen.")
	_hint(rows, "Laufende Aufnahmen bleiben bei × aktiv.")
	status_label = _text(rows, "")
	status_label.add_theme_color_override("font_color", Color(0.2, 0.78, 1.0))
	minimum_size_changed.connect(_place.call_deferred)
	UiLayout.changed.connect(_place)
	_place.call_deferred()
	hide()

func _section(parent: VBoxContainer, title: String) -> VBoxContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.08, 0.11, 0.8)
	style.border_color = Color(0.25, 0.38, 0.48)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.set_content_margin_all(12)
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	panel.add_child(rows)
	var label := _heading(rows, title)
	label.add_theme_color_override("font_color", Color(0.4, 0.75, 1.0))
	return rows

func _heading(rows: VBoxContainer, text: String) -> Label:
	var label := _text(rows, text)
	label.add_theme_font_size_override("font_size", 22)
	return label

func _hint(rows: VBoxContainer, text: String) -> void:
	var label := _text(rows, text)
	label.add_theme_font_size_override("font_size", 18)
	label.add_theme_color_override("font_color", Color(0.68, 0.76, 0.84))

func _check(rows: VBoxContainer, text: String) -> CheckBox:
	var option := CheckBox.new()
	option.text = text
	option.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	style_action_button(option)
	option.add_theme_icon_override("unchecked", preload("res://ui/icons/checkbox_off_icon.svg"))
	option.add_theme_icon_override("checked", preload("res://ui/icons/checkbox_on_icon.svg"))
	option.add_theme_constant_override("h_separation", 12)
	rows.add_child(option)
	return option

func _text(rows: VBoxContainer, text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 20)
	label.add_theme_color_override("font_color", Color.WHITE)
	rows.add_child(label)
	return label

func _place() -> void:
	UiLayout.place_window(self, Vector2(860, 760))

func open(state: Dictionary) -> void:
	display_option.button_pressed = state.display
	performance_option.button_pressed = state.performance
	ground_option.button_pressed = state.ground
	timeline_option.button_pressed = state.get("timeline", false)
	minimal_option.button_pressed = state.get("minimal_enabled", false)
	update_minimal_result(state.get("minimal_result"))
	target_option.select(TARGETS.find(int(state.target)))
	status_label.text = state.status
	device_name.text = state.get("device_name", "")
	device_name.editable = not state.performance and not state.ground
	environment_label.text = state.get("environment", "Browserangabe nicht verfügbar")
	details_button.button_pressed = false
	scroll.scroll_vertical = 0
	show()
	_place()

func _apply() -> void:
	apply_requested.emit(display_option.button_pressed, performance_option.button_pressed,
		ground_option.button_pressed, TARGETS[target_option.selected], device_name.text, timeline_option.button_pressed, minimal_option.button_pressed)

func update_minimal_result(result) -> void:
	minimal_result_label.visible = result != null
	minimal_copy.visible = result != null
	if result == null:
		return
	if int(result.count) == 0:
		minimal_result_label.text = "Minimalmessung: keine Framezeiten erfasst."
		return
	minimal_result_label.text = UiNumbers.display("Minimalmessung beendet\nMessdauer: %.1f s · %d Frameabstände\nMittelwert: %.1f ms\nP95: %.1f ms\nÜber 50 ms: %d" % [result.duration_ms / 1000.0, result.count, result.mean_ms, result.p95_ms, result.over50])
	if result.get("limit", false):
		minimal_result_label.text += "\nSpeichergrenze erreicht (65.536 Werte)."

func show_minimal_result() -> void:
	scroll.ensure_control_visible.call_deferred(minimal_result_label)

func _input(event: InputEvent) -> void:
	if visible and event.is_action_pressed("ui_cancel"):
		hide()
		get_viewport().set_input_as_handled()

func _unhandled_key_input(_event: InputEvent) -> void:
	if visible:
		get_viewport().set_input_as_handled()
