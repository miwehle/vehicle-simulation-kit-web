extends ColorRect
signal throttle_enabled_changed(enabled: bool)
signal brake_enabled_changed(enabled: bool)
signal closed
signal enabled_changed(enabled: bool)

var panel = preload("res://ui/dialogs/dialog_panel.gd").new()
var enabled := CheckBox.new()
var throttle_enabled := CheckBox.new()
var brake_enabled := CheckBox.new()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	color = Color(0, 0, 0, 0.65)
	add_child(panel)
	var content: VBoxContainer = panel.build("GAMEPAD-DIAGNOSE" if OS.has_feature("web") else "DIAGNOSE (LOKAL)", close)
	enabled.text = "Lenkdiagnose anzeigen"
	enabled.custom_minimum_size.y = 48
	content.add_child(enabled)
	enabled.toggled.connect(func(value): enabled_changed.emit(value))
	throttle_enabled.text = "Gasdiagnose anzeigen"
	throttle_enabled.custom_minimum_size.y = 48
	content.add_child(throttle_enabled)
	throttle_enabled.toggled.connect(func(value): throttle_enabled_changed.emit(value))
	brake_enabled.text = "Bremsdiagnose anzeigen"
	brake_enabled.custom_minimum_size.y = 48
	content.add_child(brake_enabled)
	brake_enabled.toggled.connect(func(value): brake_enabled_changed.emit(value))
	UiLayout.changed.connect(_place)
	resized.connect(_place)
	hide()

func _place() -> void:
	UiLayout.place_window(panel, Vector2(440, 290))

func open(is_enabled: bool, gas_enabled := false, braking_enabled := false) -> void:
	enabled.set_pressed_no_signal(is_enabled)
	throttle_enabled.set_pressed_no_signal(gas_enabled)
	brake_enabled.set_pressed_no_signal(braking_enabled)
	show()
	_place()
	enabled.grab_focus()

func close() -> void:
	hide()
	closed.emit()
