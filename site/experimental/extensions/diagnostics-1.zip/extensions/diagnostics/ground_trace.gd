extends RefCounted
## Bounded local prehistory; only a failed ground query becomes an upload event.
const SAMPLE_INTERVAL_MS := 100
const HISTORY_MS := 5000
const CAPACITY := 51
var samples: Array = []
var next_index := 0
var last_tick_ms := -1
var last_sample_ms := -1
var reported: Dictionary = {}
var last_report_ms := -10000

func clear_history() -> void:
	samples.clear()
	next_index = 0
	last_tick_ms = -1
	last_sample_ms = -1

func record(now: int, position: Vector3, yaw: float, speed: float, input: Vector3) -> void:
	if last_tick_ms >= 0 and now - last_tick_ms > 250:
		clear_history()
	last_tick_ms = now
	if last_sample_ms >= 0 and now - last_sample_ms < SAMPLE_INTERVAL_MS:
		return
	last_sample_ms = now
	var sample := [now, snappedf(position.x, 0.01), snappedf(position.y, 0.01),
		snappedf(position.z, 0.01), snappedf(yaw, 0.001), snappedf(speed, 0.01),
		snappedf(input.x, 0.01), snappedf(input.y, 0.01), snappedf(input.z, 0.01)]
	if samples.size() < CAPACITY:
		samples.append(sample)
	else:
		samples[next_index] = sample
	next_index = (next_index + 1) % CAPACITY

func failure(now: int, position: Vector3, speed: float, query: Dictionary, context: String) -> Dictionary:
	var key := "%d:%d:%s" % [roundi(position.x / 2), roundi(position.z / 2), query.get("reason", "unknown")]
	if reported.has(key) or now - last_report_ms < 10000 or reported.size() >= 20:
		return {}
	reported[key] = true
	last_report_ms = now
	var history: Array = []
	for index in samples.size():
		var sample: Array = samples[(next_index + index) % samples.size()] if samples.size() == CAPACITY else samples[index]
		if now - int(sample[0]) <= HISTORY_MS:
			var copy := sample.duplicate()
			copy[0] = int(copy[0]) - now
			history.append(copy)
	return {"kind": "ground_failure", "schema": 1, "context": context,
		"position": [position.x, position.y, position.z], "speed_mps": speed,
		"query": query, "sample_interval_ms": SAMPLE_INTERVAL_MS,
		"columns": ["dt_ms", "x", "y", "z", "yaw", "speed_mps", "throttle", "brake", "steering"],
		"history": history}
