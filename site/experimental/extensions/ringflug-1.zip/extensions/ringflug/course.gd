extends "res://extension_system/extension.gd"

const UiNumbers = preload("res://ui/controls/ui_numbers.gd")
const Target = preload("res://extensions/ringflug/target.gd")
const COURSE := "res://extensions/ringflug/parcours.csv"
const Csv = preload("res://extensions/ringflug/course_csv.gd")
const BELL := "res://extensions/ringflug/bell.wav"
var prefs_path := "user://ringparcours.cfg"
@onready var player: Vehicle = $"../Player"
var shape := {"diameter": 10.0, "tube": 0.38}
var rows: VBoxContainer
var inputs := {}
var prefs := ConfigFile.new()
var active_csv := ""
var bell := AudioStreamPlayer.new()
var browser_bell: JavaScriptObject
var picker := FileDialog.new()
var browser_callback: JavaScriptObject
var report := Label.new()
var feedback := Label.new()
var targets: Array[Target] = []
var shadows: Array[MeshInstance3D] = []
var scored := {}
var previous := Vector3.ZERO
var start: Transform3D
var running := false
var armed := false
var check_station_in := 0.0
var elapsed := 0.0
var best := INF
var last := ""
var needs_reload := true
var pending_csv := ""

func register() -> void:
	var saved := prefs.load(prefs_path) == OK
	if saved:
		for key in shape: shape[key] = prefs.get_value("shape", key, shape[key])
		shape.diameter = prefs.get_value("shape", "diameter", prefs.get_value("ring", "diameter", shape.diameter))
	active_csv = prefs.get_value("course", "csv", "") if saved else ""
	if active_csv.is_empty(): active_csv = FileAccess.get_file_as_string(COURSE)
	elif not prefs.has_section_key("course", "pylon_sides"): active_csv = Csv.migrate_saved(active_csv)
	var menu = player.get_node("HUD/SettingsMenu")
	rows = VBoxContainer.new()
	extension_manager.add_dialog_section(self, rows, "Ringparcours", {
		"changed": _has_changes, "apply": _apply_edits, "discard": _discard_edits})
	inputs.diameter = _dimension_input(rows, "Ring-Innendurchmesser", shape.diameter, 2, 40)
	inputs.tube = _dimension_input(rows, "Ring-Rohrdurchmesser", shape.tube, 0.05, 2)
	menu.add_action_button(rows, "Parcours laden …", _choose_file)
	rows.add_child(feedback)
	picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	picker.access = FileDialog.ACCESS_FILESYSTEM
	picker.use_native_dialog = true
	picker.add_filter("*.csv", "Parcours")
	add_child(picker)
	picker.file_selected.connect(func(path):
		var file := FileAccess.open(path, FileAccess.READ)
		if file: _stage_csv(file.get_as_text())
		else: feedback.text = "Datei konnte nicht gelesen werden.")
	var bytes := FileAccess.get_file_as_bytes(BELL)
	if OS.has_feature("web"):
		browser_callback = JavaScriptBridge.create_callback(_browser_file)
		browser_bell = JavaScriptBridge.create_object("Audio", "data:audio/wav;base64," + Marshalls.raw_to_base64(bytes))
	else:
		bell.stream = AudioStreamWAV.load_from_buffer(bytes)
	add_child(bell)
	extension_manager.add_hud_status_control(self, report)
	observe(RenderQuality.changed, _show_shadows)

func _apply_edits(persist: bool) -> void:
	if not is_inside_tree(): return
	if not pending_csv.is_empty():
		_import_csv(pending_csv, persist)
		pending_csv = ""
	_save_shape(persist)

func _discard_edits() -> void:
	pending_csv = ""
	feedback.text = ""
	for key in inputs: inputs[key].value = shape[key]

func cleanup() -> void:
	bell.stop()
	if browser_bell: browser_bell.pause()

func _dimension_input(rows: VBoxContainer, caption: String, value: float, low: float, high: float) -> HSlider:
	var row := HBoxContainer.new()
	rows.add_child(row)
	var label := Label.new()
	label.text = caption
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(label)
	var slider := HSlider.new()
	slider.min_value = low
	slider.max_value = high
	slider.step = 0.01
	slider.value = value
	slider.custom_minimum_size.y = 48
	var unit := Label.new()
	unit.text = "m"
	UiNumbers.add_slider(row, rows, slider, "%.2f", unit)
	return slider

func _frame(meters: float) -> Transform3D:
	var station: float = player.route.start_distance + meters
	var forward: Vector3 = player.route.forward(station)
	forward.y = 0
	var axes := Basis.looking_at(forward.normalized(), Vector3.UP)
	var center: Vector3 = player.route.sample(station)
	center.y -= player.route.ROAD_CLEARANCE
	var ray := PhysicsRayQueryParameters3D.create(center + Vector3.UP * 10, center - Vector3.UP * 10, 1)
	var hit := player.get_world_3d().direct_space_state.intersect_ray(ray)
	if not hit.is_empty():
		center = hit.position
		axes = Basis.looking_at(forward.slide(hit.normal).normalized(), hit.normal)
	return Transform3D(axes, center)

func _choose_file() -> void:
	if OS.has_feature("web"):
		JavaScriptBridge.eval("""window.chooseRingCourse = (callback) => {
			const input = document.createElement('input');
			input.type = 'file'; input.accept = '.csv,text/csv';
			input.onchange = async () => {
				try { callback(await input.files[0].text()); } catch (_) { callback(null); }
			};
			input.click();
		}""")
		JavaScriptBridge.get_interface("window").chooseRingCourse(browser_callback)
	else:
		picker.popup_centered_ratio(0.7)

func _browser_file(args: Array) -> void:
	if args.size() == 1 and args[0] is String: _stage_csv(args[0])
	else: feedback.text = "Datei konnte nicht gelesen werden."

func _has_changes() -> bool:
	for key in inputs:
		if not is_equal_approx(inputs[key].value, shape[key]): return true
	return not pending_csv.is_empty() and pending_csv != active_csv

func _stage_csv(content: String) -> void:
	var result := Csv.parse(content, player.route.length)
	if result.targets.is_empty():
		feedback.text = "\n".join(result.errors) if not result.errors.is_empty() else "Keine Ziele gefunden."
		return
	pending_csv = content
	feedback.text = "%d Ziele zum Übernehmen" % result.targets.size()

func _import_csv(content: String, persist := true) -> void:
	var result := Csv.parse(content, player.route.length)
	if result.targets.is_empty():
		feedback.text = "\n".join(result.errors) if not result.errors.is_empty() else "Keine Ziele gefunden."
		return
	var updated := ConfigFile.new()
	updated.parse(prefs.encode_to_text())
	updated.set_value("course", "csv", content)
	updated.set_value("course", "pylon_sides", true)
	if persist and not SimulationLibrary.temporary and updated.save(prefs_path) != OK:
		feedback.text = "Parcours konnte nicht gespeichert werden."
		return
	prefs = updated
	active_csv = content
	needs_reload = true

func _save_shape(persist := true) -> void:
	for key in inputs:
		if inputs[key].value != shape[key]:
			shape[key] = inputs[key].value
			prefs.set_value("shape", key, shape[key])
			needs_reload = true
	if persist and not SimulationLibrary.temporary and (needs_reload or prefs.has_section("shape") or prefs.has_section("course")) and prefs.save(prefs_path) != OK: feedback.text = "Maße konnten nicht gespeichert werden."

func _reload() -> void:
	needs_reload = false
	var result := Csv.parse(active_csv, player.route.length)
	var specs: Array = result.targets
	if specs.is_empty():
		feedback.text = "Keine gültigen Ziele."
		return
	for target in targets: target.queue_free()
	targets.clear()
	shadows.clear()
	for spec in specs:
		var target := Target.new()
		add_child(target)
		target.transform = _frame(spec.station)
		if spec.ring:
			target.position.y += spec.value
			target.rotation = Vector3(0, target.rotation.y, 0)
		target.build(spec, shape)
		targets.append(target)
		if spec.ring:
			var shadow := target.add_shadow(-get_parent().get_node("BaseEnvironment").terrain.get_node("Sun").global_basis.z, player.get_world_3d().direct_space_state)
			if shadow: shadows.append(shadow)
	_show_shadows()
	start = _frame(0).affine_inverse()
	previous = player.global_position
	_reset_round()
	best = INF
	last = ""
	result.errors.insert(0, "%d Ziele geladen." % targets.size())
	feedback.text = "\n".join(result.errors)
	_display()

func _show_shadows() -> void:
	for shadow in shadows: shadow.visible = RenderQuality.snapshot().get("shadows", "off") == "lightmaps"

func _reset_round() -> void:
	running = false
	armed = false
	elapsed = 0
	scored.clear()

func _physics_process(delta: float) -> void:
	if not player.ready_to_fly: return
	if needs_reload: _reload()
	var pos: Vector3 = player.global_position
	var a := previous
	previous = pos
	if targets.is_empty() or player.simulation_paused or not player.has_focus: return
	if a.distance_to(pos) > 8:
		_reset_round()
		_display()
		return
	var before := start * a
	var after := start * pos
	# A start on the grid and a forward crossing both begin a timed lap.
	var crosses := before.z >= 0 and after.z < 0 and absf(lerpf(before.x, after.x, before.z / (before.z - after.z))) < 12
	if not running:
		if not crosses and not (absf(after.x) < 10 and absf(after.z) < 5 and after.z < before.z): return
		running = true
	elapsed += delta
	# Arm the finish on the opposite half of the circuit, including in flight.
	if not armed:
		check_station_in -= delta
		if check_station_in <= 0:
			check_station_in = 0.5
			var station: float = player.route.nearest_distance(pos, 0, 0, true) if player.flight_mode else player.distance
			var progress := fposmod(station - player.route.start_distance, player.route.length) / float(player.route.length)
			armed = progress > 0.35 and progress < 0.65
	for target in targets:
		if not scored.has(target) and target.crossed(a, pos, player.flight_mode):
			scored[target] = true
			target.flash()
			if browser_bell:
				browser_bell.currentTime = 0
				browser_bell.play()
			else: bell.play()
	if armed and crosses:
		var result := elapsed - 2 * scored.size()
		best = minf(best, result)
		last = "Letzte %.1f s  ·  Beste %.1f s" % [result, best]
		elapsed = 0
		scored.clear()
		armed = false
	_display()

func _display() -> void:
	var caption := "0/%d Punkte  ·  Start/Ziel anfahren" % targets.size()
	if running:
		caption = "Parcours  %.1f s  ·  %d/%d Punkte" % [elapsed, scored.size(), targets.size()]
	if not last.is_empty(): caption += "\n" + last
	report.text = UiNumbers.display(caption)
