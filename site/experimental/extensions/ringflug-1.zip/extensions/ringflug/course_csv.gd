extends RefCounted

static func parse(content: String, track_length: float) -> Dictionary:
	var specs := []
	var errors := PackedStringArray()
	var line := 0
	for raw in content.trim_prefix("\uFEFF").split("\n"):
		line += 1
		var text := raw.strip_edges()
		if text.is_empty() or text.begins_with("#"): continue
		var cells := text.split(";")
		var kind := cells[0].strip_edges().to_lower()
		var spec := _target(kind, cells, track_length)
		if spec.is_empty():
			var label: String = {"r": "Ring", "f": "Feld"}.get(kind, "Ziel")
			errors.append("%s fehlerhaft: Zeile %d" % [label, line])
		else:
			specs.append(spec)
	return {"targets": specs, "errors": errors}

static func _target(kind: String, cells: PackedStringArray, track_length: float) -> Dictionary:
	if cells.size() != 3 or kind not in ["r", "f"]: return {}
	var station := cells[1].strip_edges().replace(",", ".")
	var meters := station.to_float()
	if not station.is_valid_float() or not is_finite(meters) or meters < 0 or meters >= track_length: return {}
	if kind == "f":
		var side := cells[2].strip_edges().to_lower()
		if side not in ["l", "r"]: return {}
		return {"ring": false, "station": meters, "side": -1 if side == "l" else 1}
	var value := cells[2].strip_edges().replace(",", ".")
	if not value.is_valid_float() or not is_finite(value.to_float()): return {}
	if value.to_float() <= 0: return {}
	return {"ring": true, "station": meters, "value": value.to_float()}

# Imported courses saved before pylons had no side or a signed offset.
static func migrate_saved(content: String) -> String:
	var lines := content.split("\n")
	for i in lines.size():
		var cells := lines[i].strip_edges().split(";")
		if cells[0].strip_edges().to_lower() != "f": continue
		if cells.size() == 2:
			lines[i] += ";r"
		elif cells.size() == 3:
			var offset := cells[2].strip_edges().replace(",", ".")
			if offset.is_valid_float():
				cells[2] = "l" if offset.to_float() < 0 else "r"
				lines[i] = ";".join(cells)
	return "\n".join(lines)
