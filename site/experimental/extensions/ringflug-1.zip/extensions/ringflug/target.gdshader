shader_type spatial;
render_mode diffuse_burley;
uniform float hit : hint_range(0.0, 1.0) = 0.0;
uniform bool ring = true;
varying vec3 local;
void vertex() {
	local = VERTEX;
}
void fragment() {
	float segment = atan(local.z, local.x) * (8.0 / PI);
	float white_band = (step(-0.14,local.y) - step(-0.035,local.y)) + (step(0.10,local.y) - step(0.19,local.y));
	vec3 stripe = mix(vec3(0.91), vec3(0.94, 0.22, 0.025), ring ? step(0.5, fract(segment)) : 1.0 - white_band);
	ALBEDO = mix(stripe, vec3(0.15, 0.98, 0.22), hit);
	EMISSION = 0.38 * ALBEDO + hit * vec3(0.08, 0.55, 0.12);
	ROUGHNESS = 0.88;
}
