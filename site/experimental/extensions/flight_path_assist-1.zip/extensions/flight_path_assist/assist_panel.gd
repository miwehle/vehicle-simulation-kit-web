extends "res://ui/dialogs/tuning_panel.gd"
## Two compact HUD panels for the shared exploration-flight configuration.
var controls: Dictionary
var other_parameters := false
const RATE_PARAMETERS := [
	["steering_rate", "Fein (Y): Horizontal", 0.05, 720.0, 0.05, "%.2f °/s"],
	["vertical_steering_rate", "Fein (Y): Vertikal", 0.05, 720.0, 0.05, "%.2f °/s"],
	["turn_deg_s", "Mitte (LB): Horizontal", 1.0, 120.0, 0.1, "%.1f °/s"],
	["pitch_rate_deg_s", "Mitte (LB): Vertikal", 1.0, 180.0, 0.1, "%.1f °/s"],
	["fast_horizontal_rate", "Schnell (LB): Horizontal", 0.05, 720.0, 0.05, "%.2f °/s"],
	["fast_vertical_rate", "Schnell (LB): Vertikal", 0.05, 720.0, 0.05, "%.2f °/s"],
]
const OTHER_PARAMETERS := [
	["pitch_deg", "Max. Steig-/Sinkwinkel", 1.0, 90.0, 0.1, "%.1f °"],
	["dead_zone_percent", "Stick-Totzone", 0.0, 20.0, 0.5, "%.1f %%"],
	["horizontal_exponent", "Lenkprogression horiz.", 1.0, 4.0, 0.1, "%.1f"],
	["vertical_exponent", "Lenkprogression vert.", 1.0, 4.0, 0.1, "%.1f"],
	["hold_entry_seconds", "Halten (Y): Übergangszeit", 0.0, 2.0, 0.05, "%.2f s"],
]

func _ready() -> void:
	section = "flight_assist_other" if other_parameters else "flight_assist_rates"
	save_path = "user://" + section + "_panel.cfg"
	build_panel("Weitere Flugparameter" if other_parameters else "Winkelgeschwindigkeiten", OTHER_PARAMETERS if other_parameters else RATE_PARAMETERS, Vector2(620, 112) if other_parameters else Vector2(20, 112))
	defaults = SimulationLibrary.vehicle_setups.default_flight_values()

func _parameter_target(key: String):
	return controls if key in ["dead_zone_percent", "horizontal_exponent", "vertical_exponent"] else model

func _save() -> void:
	# Only panel placement belongs here; control values belong to the shared exploration-flight configuration.
	if SimulationLibrary.temporary: return
	var config := ConfigFile.new()
	config.set_value("panel", "position", preferred_position)
	config.save(save_path)
